document.addEventListener('DOMContentLoaded', () => {
    lucide.createIcons();

    // Cache all DOM refs once
    const $ = id => document.getElementById(id);
    const contentDiv = $('content');
    const searchInput = $('searchInput');
    const langText = $('lang-text');
    const themeIcon = $('theme-icon');
    const tocContainer = $('toc');
    const searchNav = $('search-nav');
    const searchNavText = $('search-nav-text');
    const dropdownMenu = $('filterDropdownMenu');
    const filterSelectText = $('filterSelectText');

    let currentTheme = localStorage.getItem('theme') || 'light';
    let currentLang = localStorage.getItem('lang') || 'en';
    let fullMarkdownText = '';
    let parsedSections = [];  // Cache: [{header, headerLower, md, html}]
    let highlights = [];
    let currentHighlightIndex = -1;
    let osInstance = null;

    // Initialize custom scrollbar (may load after DOMContentLoaded due to defer)
    function initScrollbar() {
        if (window.OverlayScrollbarsGlobal) {
            osInstance = OverlayScrollbarsGlobal.OverlayScrollbars(document.body, {
                scrollbars: { autoHide: 'never', theme: 'os-theme-custom' }
            });
        } else {
            setTimeout(initScrollbar, 50);
        }
    }
    initScrollbar();

    // Apply theme immediately
    const setTheme = t => {
        document.documentElement.setAttribute('data-theme', t);
        document.documentElement.setAttribute('data-bs-theme', t);
        const hljsTheme = $('hljs-theme');
        if (hljsTheme) {
            hljsTheme.href = t === 'dark' 
                ? 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/vs2015.min.css' 
                : 'https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/vs.min.css';
        }
    };
    setTheme(currentTheme);
    if (langText) langText.textContent = currentLang.toUpperCase();
    updateThemeIcon();
    loadContent(currentLang);

    // --- Event listeners ---
    $('themeToggle').addEventListener('click', () => {
        currentTheme = currentTheme === 'light' ? 'dark' : 'light';
        setTheme(currentTheme);
        localStorage.setItem('theme', currentTheme);
        updateThemeIcon();
    });

    $('langToggle').addEventListener('click', () => {
        currentLang = currentLang === 'en' ? 'cz' : 'en';
        langText.textContent = currentLang.toUpperCase();
        loadContent(currentLang);
    });

    searchInput.addEventListener('input', () => searchNav.classList.remove('show'));
    searchInput.addEventListener('input', debounce(filterContent, 250));

    $('search-nav-up').addEventListener('click', () => scrollToHighlight(currentHighlightIndex - 1));
    $('search-nav-down').addEventListener('click', () => scrollToHighlight(currentHighlightIndex + 1));

    // --- Core functions ---
    function loadContent(lang) {
        contentDiv.innerHTML = '<div class="text-center mt-5"><div class="spinner-border text-secondary" role="status"></div></div>';
        try {
            fullMarkdownText = window[`doc_${lang}`];
            if (!fullMarkdownText) throw new Error('Documentation data not loaded from JS file');

            // Split into sections and pre-parse each one
            const rawSections = fullMarkdownText.split(/(?=^# )/m);
            parsedSections = rawSections.map(md => {
                const headerMatch = md.match(/^# +(.*)/);
                return {
                    md,
                    html: marked.parse(md),
                    header: headerMatch ? headerMatch[1].trim() : '',
                    headerLower: headerMatch ? headerMatch[1].trim().toLowerCase() : ''
                };
            });

            extractCategories();
            filterContent();
        } catch (error) {
            contentDiv.innerHTML = `<div class="alert alert-danger">${error.message}</div>`;
            fullMarkdownText = '';
            parsedSections = [];
            tocContainer.innerHTML = '';
        }
    }

    function extractCategories() {
        const cats = [...new Set(parsedSections.map(s => s.header).filter(Boolean))].sort();
        const allLabel = currentLang === 'cz' ? 'Všechny kategorie' : 'All Categories';

        // Build menu with DocumentFragment
        const frag = document.createDocumentFragment();
        const allLi = document.createElement('li');
        allLi.innerHTML = `<a class="dropdown-item active" href="#" data-value="">${allLabel}</a>`;
        frag.appendChild(allLi);

        cats.forEach(cat => {
            const li = document.createElement('li');
            const a = document.createElement('a');
            a.className = 'dropdown-item';
            a.href = '#';
            a.dataset.value = cat.toLowerCase();
            a.textContent = formatCategoryName(cat);
            li.appendChild(a);
            frag.appendChild(li);
        });

        dropdownMenu.innerHTML = '';
        dropdownMenu.appendChild(frag);

        // Single delegated listener instead of one per item
        dropdownMenu.onclick = e => {
            const item = e.target.closest('.dropdown-item');
            if (!item) return;
            e.preventDefault();
            dropdownMenu.querySelectorAll('.dropdown-item').forEach(i => i.classList.remove('active'));
            item.classList.add('active');
            filterSelectText.textContent = item.textContent;
            filterContent();
        };
    }

    function formatCategoryName(raw) {
        let c = raw.trim();
        if (c.includes('COMPREHENSIVE TECHNICAL')) return currentLang === 'cz' ? 'Přehled Projektu' : 'Project Overview';
        return c.replace(/^[\d.]+\s*/, '').split(/[(\-–]/)[0].trim();
    }

    function filterContent() {
        const query = searchInput.value.toLowerCase();
        const activeItem = dropdownMenu.querySelector('.dropdown-item.active');
        const category = activeItem ? activeItem.dataset.value : '';

        // Filter from pre-parsed cache — no re-parsing needed
        const matched = parsedSections.filter(s => {
            if (category && s.headerLower !== category) return false;
            if (query && !s.md.toLowerCase().includes(query)) return false;
            return true;
        });

        if (matched.length === 0) {
            contentDiv.innerHTML = '<p class="text-muted text-center py-5">No matching results found.</p>';
            tocContainer.innerHTML = '';
            return;
        }

        // Join pre-parsed HTML — this is the big perf win
        contentDiv.innerHTML = matched.map(s => s.html).join('');
        generateTOC();

        if (window.hljs) {
            contentDiv.querySelectorAll('pre code').forEach(block => {
                hljs.highlightElement(block);
            });
        }

        if (query.trim()) highlightSearchTerm(query.trim());
    }

    function generateTOC() {
        const headings = contentDiv.querySelectorAll('h1, h2, h3');
        if (headings.length === 0) {
            tocContainer.innerHTML = '<p class="text-muted small">No headings found.</p>';
            return;
        }

        const frag = document.createDocumentFragment();
        const wrap = document.createElement('div');
        wrap.className = 'd-flex flex-column gap-1';

        headings.forEach((h, i) => {
            if (!h.id) h.id = h.textContent.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || `heading-${i}`;
            const a = document.createElement('a');
            a.href = `#${h.id}`;
            a.textContent = h.textContent;
            a.className = `toc-link toc-${h.tagName.toLowerCase()}`;
            a.addEventListener('click', () => {
                const inst = bootstrap.Offcanvas.getInstance($('tocOffcanvas'));
                if (inst) inst.hide();
            });
            wrap.appendChild(a);
        });

        frag.appendChild(wrap);
        tocContainer.innerHTML = '';
        tocContainer.appendChild(frag);
    }

    function highlightSearchTerm(term) {
        highlights = [];
        currentHighlightIndex = -1;
        if (!term) { searchNav.classList.remove('show'); return; }

        const escaped = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const regex = new RegExp(`(${escaped})`, 'gi');

        // Walk DOM tree and wrap matches in <mark>
        (function walk(node) {
            if (node.nodeType === 3) {
                if (regex.test(node.nodeValue)) {
                    const span = document.createElement('span');
                    span.innerHTML = node.nodeValue.replace(regex, '<mark class="highlight">$&</mark>');
                    node.parentNode.replaceChild(span, node);
                }
            } else if (node.nodeType === 1 && !/^(SCRIPT|STYLE|MARK)$/.test(node.nodeName)) {
                for (let i = node.childNodes.length - 1; i >= 0; i--) walk(node.childNodes[i]);
            }
        })(contentDiv);

        highlights = contentDiv.querySelectorAll('mark.highlight');
        highlights.length > 0 ? (searchNav.classList.add('show'), scrollToHighlight(0)) : searchNav.classList.remove('show');
    }

    function scrollToHighlight(index) {
        if (highlights.length === 0) return;
        if (currentHighlightIndex >= 0 && currentHighlightIndex < highlights.length) {
            highlights[currentHighlightIndex].classList.remove('active-highlight');
        }
        currentHighlightIndex = ((index % highlights.length) + highlights.length) % highlights.length;
        const el = highlights[currentHighlightIndex];
        el.classList.add('active-highlight');
        
        const viewport = osInstance ? osInstance.elements().viewport : window;
        const currentScroll = osInstance ? viewport.scrollTop : window.scrollY;
        const y = el.getBoundingClientRect().top + currentScroll - 120;
        
        viewport.scrollTo({ top: y, behavior: 'smooth' });
        
        searchNavText.textContent = `${currentHighlightIndex + 1} / ${highlights.length}`;
    }

    function updateThemeIcon() {
        const icon = $('theme-icon') || document.querySelector('[data-lucide="sun"], [data-lucide="moon"]');
        if (icon) icon.setAttribute('data-lucide', currentTheme === 'dark' ? 'sun' : 'moon');
        lucide.createIcons();
    }

    function debounce(fn, ms) {
        let t;
        return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
    }
});
