window.doc_cz = function() {/*!
<center>

# KOMPLEXNÍ TECHNICKÁ DOKUMENTACE

### Creative Hill College, Zlín

<br>
<hr style="width: 150px; border: 1px solid #2b5797; margin: auto;"/>
<br>

**Rok:** 2025/2026  
*Určeno pro budoucí vývojáře a studenty*

</center>

<div style="page-break-after: always;"></div>


<div style='page-break-before: always;'></div><br><br><br>

# 1. Architektura a Jádro Systému
Tato dokumentace poskytuje kompletní, hluboký a detailní přehled o všech vlastních C# skriptech vytvořených pro tento VR PC simulátor. Je navržena tak, aby budoucím studentům, kteří převezmou vývoj, poskytla jasný návod, jak jednotlivé systémy fungují pod kapotou, jak jsou propojeny, jak je konfigurovat v Unity Editoru a jak psát nový kód v souladu se stávající architekturou.

## 1.1 Sestavovací a Socketový Systém (Zoltr)
Systém vkládání a odebírání součástek je založen na interakci mezi komponentami `zoltr_socket` (zásuvky napevno umístěné ve scéně, např. patice CPU na desce, PCI-E sloty, SATA porty) a `zoltr_socketItem` (pohyblivé předměty, které hráč zvedá). Komunikace probíhá následovně:
1. **Detekce přiblížení (Hover)**: `zoltr_socketItem` využívá fyzikální trigger a při vstupu do kolize se socketem prověří kompatibilitu (`socket_type`). Pokud typ souhlasí a nejsou porušena pravidla závislostí (`dependencyRules`), skript vytvoří holografický náhled (`CreateGhost`) na cílové pozici socketu.
2. **Uchycení (Snap)**: V momentě, kdy hráč uvolní stisk (XR Grab `selectExited`), součástka přejde do stavu přichycení. Její Rigidbody se přepne na Kinematic, vypne se gravitace, transform se plynule přesune a vyrovná na kotevní bod socketu a socket je označen jako obsazený (`used = true`).
3. **Pnutí a Vytržení (Unsnap)**: Pokud je povoleno odebírání (`allowUnsnap`), stisk součástky ve slotu nevyvolá okamžité odpojení. Skript začne měřit vzdálenost mezi ovladačem hráče a kotevním bodem socketu (`pullDelta`). Jakmile hráč táhne ruku pryč, skript aktivuje procedurální třas součástky (`maxShakeIntensity`) a zvuk skřípání. Pokud tah překročí limit `neededPullForceForUnsnap`, součástka se vytrhne ze socketu, Rigidbody získá zpět gravitaci a vrstvy (layers) se obnoví.

## 1.2 Pokročilá Kabelová Fyzika (Verlet-XPBD)
Kabelový simulátor (`zoltr_cable`) řeší ohebná tělesa bez nutnosti použití standardních ohebných kloubů (Joints) v Unity, které jsou ve VR nestabilní a náchylné k explozivnímu chování. Simulace využívá **Position-Based Dynamics**:
- **Verletova Integrace**: Částice kabelu si pamatují svou předchozí pozici a z rozdílu mezi současnou a minulou pozicí odvozují rychlost. To zaručuje stabilitu i při extrémním napnutí.
- **Projekce Vazeb (Constraints)**: V každém snímku se ve smyčce (`substeps`) aplikují vazby na délku segmentů a tuhost ohybu (`bendingStiffness`). Částice jsou posouvány tak, aby splňovaly fyzikální meze.
- **Kolize a Průvěs**: Kolize s okolními stoly a počítačem jsou počítány pomocí Sweep testů, které zabraňují propadávání částic kabelu skrze tenké stěny.
- **Vykreslení přes Kosti (Bones)**: Pokud je kabel navržen jako 3D model s kostrou, skript v metodě `LateUpdate` rotuje a přesouvá kosti importovaného FBX tak, aby přesně kopírovaly pozice fyzikálních částic simulace. Výsledkem je naprosto plynulý, deformovatelný 3D kabel.

<div style='page-break-before: always;'></div>

# 2. Detailní Katalog Všech Vlastních Skriptů

<div style='page-break-before: always;'></div>

# Hlavní Herní a UI Skripty (Assets/Scripts/)
---

## Třída / Skript: `BobAndRotate`
- **Relativní cesta k souboru:** `Assets/Scripts/BobAndRotate.cs`

### 1. Účel a role v projektu
Zajišťuje plynulý levitační pohyb objektu (nahoru a dolů ve tvaru sinusovky) a jeho současnou rotaci kolem zvolené osy. Používá se především pro vizuální zvýraznění sběratelských a důležitých předmětů (např. instalační diskety, klíče nebo drobné součástky), aby je hráč v prostoru snadno lokalizoval.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript v metodě `Update` vypočítává novou pozici objektu pomocí goniometrické funkce `Mathf.Sin(Time.time * bobSpeed) * bobHeight`. Tato hodnota se přičítá k výchozí pozici objektu, což zaručuje plynulý periodický ohyb bez trhání. Rotace je prováděna přímým voláním metody `transform.Rotate` s rychlostí `rotateSpeed * Time.deltaTime` kolem osy Y.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `bobHeight` | `float` | Rozsah výšky vznášení objektu ve vzduchu. |
| `bobSpeed` | `float` | Rychlost vertikálního vznášení objektu v čase. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zde můžete jemně doladit vizuální chování levitace. Pro drobné předměty se doporučuje `bobHeight` nastavit na `0.02` (2 cm posun) a `bobSpeed` na `2.0`. Pokud chcete, aby se předmět pouze otáčel, nastavte `bobHeight` na `0`.
- **Vazby na ostatní prvky ve scéně:** Umístěte skript přímo na model předmětu. Pokud má předmět fyzikální Rigidbody, ujistěte se, že je nastaveno jako Kinematic, jinak bude fyzika kolidovat s matematickým pohybem skriptu.

========================================

## Třída / Skript: `CanvasAlwaysOnTop`
- **Relativní cesta k souboru:** `Assets/Scripts/CanvasAlwaysOnTop.cs`

### 1. Účel a role v projektu
Otáčí World-Space plátno (Canvas) s textem nebo grafikou tak, aby bylo v každém okamžiku natočeno čelem k očím hráče (kameře). Tento efekt (billboarding) je klíčový pro VR rozhraní, protože texty vznášející se v prostoru zůstávají čitelné ze všech úhlů pohledu a nepropadají se vizuálně do šikmých deformací.

### 2. Jak skript funguje (Logika a vnitřní fungování)
V každém snímku (metoda `LateUpdate` nebo `Update`) skript vyhledá pozici kamery hráče. Spočítá vektor směru od plátna ke kameře a otočí transform pomocí metody `transform.LookAt` nebo přímým přiřazením rotace `Quaternion.LookRotation`. Pokud je aktivní zámek osy Y, je rotace omezena pouze na otáčení kolem svislé osy, takže se plátno nenaklání nahoru a dolů.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ApplyAlwaysOnTop` | `void` | `` | Upravuje materiály a shadery pro vykreslení plátna před všemi 3D objekty. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `lockY` na `true`, pokud chcete, aby se panel otáčel pouze doleva a doprava (vhodné pro stojící panely). Pokud panel volně visí ve vzduchu, nechte `lockY` vypnuté, aby se natočil i při pohledu shora/zdola.
- **Vazby na ostatní prvky ve scéně:** Přiřaďte skript na objekt typu Canvas nastavený na Render Mode: World Space. Skript si při spuštění automaticky najde hlavní kameru scény.

========================================

## Třída / Skript: `CanvasGroupHoverFade`
- **Relativní cesta k souboru:** `Assets/Scripts/CanvasGroupHoverFade.cs`

### 1. Účel a role v projektu
Implementuje hladké mizení a objevování UI panelů (Canvas Group) na základě interakce ukazatele (hover). Když hráč zamíří paprskem ovladače na panel, panel se plynule rozsvítí (fade-in), a když paprsek uhne, panel opět zmizí (fade-out).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript implementuje rozhraní Unity EventSystem pro detekci najetí a sjetí kurzoru (`IPointerEnterHandler`, `IPointerExitHandler`). Na základě redistribution těchto událostí mění cílovou hodnotu průhlednosti (target alpha). V metodě `Update` pak lineárně interpoluje (`Mathf.MoveTowards` nebo `Mathf.Lerp`) aktuální hodnotu `alpha` na komponentě `CanvasGroup` směrem k cílové hodnotě.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `fadeSpeed` | `float` | Rychlost stmívání a rozsvěcování UI panelu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Spustí postupné prolínání viditelnosti (fade-in) při najetí ukazatele na UI. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Spustí postupné mizení viditelnosti (fade-out) při opuštění UI ukazatelem. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Upravte rychlost přechodu pomocí `fadeSpeed`. Hodnota `hoverAlpha` určuje, jak moc bude panel viditelný při najetí (standardně `1.0` pro plnou viditelnost), `defaultAlpha` určuje stav v nečinnosti (`0.0` pro úplné skrytí).
- **Vazby na ostatní prvky ve scéně:** Vyžaduje přítomnost komponenty `CanvasGroup` na stejném GameObjectu. Musí být přítomen také collider, aby mohl XR Ray Interactor detekovat najetí paprsku.

========================================

## Třída / Skript: `DynamicIconPan`
- **Relativní cesta k souboru:** `Assets/Scripts/DynamicIconPan.cs`

### 1. Účel a role v projektu
Přidává jemnou paralaxní animaci 2D ikonám na UI panelech. Ikony reagují na náklon hlavy hráče nebo pohyb kurzoru mírným posunem do stran, což vytváří moderní prostorový 3D dojem (paralaxní hloubka).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript sleduje relativní pozici interaktoru vůči středu tlačítka a posouvá vnitřní grafický element (např. obrázek ikony) v rámci vymezených mezí `maxOffset` pomocí interpolace na RectTransformu.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `rotationSpeed` | `float` | Rychlost otáčení ikony na panelu. |
| `invertDirection` | `bool` | Obrací směr otáčení ikony na panelu. |
| `rotationOffset` | `Vector3` | Počáteční úhlové natočení ikony. |
| `maxAngleX` | `float` | Maximální úhel otáčení na ose X. |
| `maxAngleY` | `float` | Maximální úhel otáčení na ose Y. |
| `enablePositionPan` | `bool` | Povoluje posouvání pozice ikony při najetí. |
| `positionPanAmount` | `float` | Maximální vzdálenost posunu ikony do stran. |
| `positionPanSpeed` | `float` | Rychlost posouvání pozice ikony. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `maxOffset` (v pixelech) na rozumnou hodnotu (např. `10` až `20`), aby posun nebyl příliš divoký. `panSpeed` určuje, jak rychle se ikona vrátí do původního středu při ztrátě fokusu.
- **Vazby na ostatní prvky ve scéně:** Umísťuje se přímo na UI elementy typu Image uvnitř Canvasu.

========================================

## Třída / Skript: `Fan`
- **Relativní cesta k souboru:** `Assets/Scripts/Fan.cs`

### 1. Účel a role v projektu
Třída simulující rotační chování chladicího ventilátoru. Zpracovává zapnutí/vypnutí napájení, plynulé zrychlování otáček (náběh motoru) a setrvačné zpomalování listů až do úplného zastavení po odpojení napájení.

### 2. Jak skript funguje (Logika a vnitřní fungování)
V metodě `Update` skript kontroluje stav napájení. Pokud je ventilátor napájen, aktuální rychlost se lineárně zvyšuje přičítáním `acceleration * Time.deltaTime` až do limitu `maxSpinSpeed`. Pokud napájení chybí, rychlost klesá o `deceleration * Time.deltaTime` k nule. Listy ventilátoru jsou následně otáčeny kolem zvolené osy `rotationAxis` o úhel odpovídající aktuální rychlosti vynásobené časem.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `rotorObject` | `Transform` | Transform rotující části modelu ventilátoru. |
| `rotationAxis` | `Vector3` | Lokální osa otáčení rotoru ventilátoru. |
| `allowReverseRotation` | `bool` | Povoluje zpětný chod otáčení ventilátoru. |
| `startOnAwake` | `bool` | Spustí otáčení ventilátoru ihned po načtení. |
| `defaultTargetSpeed` | `float` | Cílová rychlost otáčení listů ventilátoru. |
| `accelerationRate` | `float` | Rychlost náběhu otáček ventilátoru. |
| `decelerationRate` | `float` | Rychlost doběhu listů při vypnutí. |
| `onFanStarted` | `UnityEvent` | Událost spuštěná při startu ventilátoru. |
| `onFanStopped` | `UnityEvent` | Událost spuštěná při zastavení ventilátoru. |
| `onTargetSpeedReached` | `UnityEvent` | Událost při dosažení cílové rychlosti. |
| `IsRunning` | `bool` | Indikuje ventilátor v chodu. |
| `CurrentSpeed` | `float` | Aktuální rychlost otáčení ventilátoru. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `StartFan` | `void` | `` | Spustí otáčení ventilátoru s plynulým zrychlováním na cílovou rychlost. |
| `StopFan` | `void` | `` | Zahájí setrvačné zpomalování listů ventilátoru až do úplného zastavení. |
| `ToggleFan` | `void` | `` | Přepíná stav chodu ventilátoru mezi spuštěním a zastavením. |
| `SetSpeed` | `void` | `float newSpeed` | Nastavuje novou cílovou rychlost otáčení listů ventilátoru. |
| `SetSpeedMultiplier` | `void` | `float multiplier` | Upravuje aktuální rychlost otáčení listů ventilátoru daným násobkem. |
| `ReverseDirection` | `void` | `` | Obrací směr otáčení listů ventilátoru kolem svislé osy. |
| `ImmediateStop` | `void` | `` | Okamžitě zastaví otáčení ventilátoru bez setrvačného doběhu listů. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zvolte správnou lokální osu rotace `rotationAxis` (často Y nebo Z dle orientace modelu). Rychlost `maxSpinSpeed` nastavte na vysokou hodnotu (např. `1000` pro rychlý ventilátor). `acceleration` and `deceleration` ovlivňují váhu a setrvačnost listů.
- **Vazby na ostatní prvky ve scéně:** Může být napojen na `zoltr_socket` přes UnityEvents, aby se ventilátor rozběhl až v momentě, kdy je správně usazen a zapojen do napájení.

========================================

## Třída / Skript: `FanBladesManager`
- **Relativní cesta k souboru:** `Assets/Scripts/FanBladesManager.cs`

### 1. Účel a role v projektu
Grafický doplněk pro ventilátor. Zajišťuje vizuální motion blur efekt. Při vysoké rychlosti otáčení skryje detailní model listů a zobrazí poloprůhledný texturovaný disk (simulace rychlého otáčení), což šetří výkon a vypadá realisticky.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript v každém snímku čte aktuální rychlost ventilátoru ze skriptu `Fan`. Pokud tato rychlost překročí `blurThreshold` (vyjádřený jako procento maximální rychlosti), skript deaktivuje GameObject detailních listů `detailedBlades` a aktivuje rozmazaný model `blurredBlades`. Při zpomalení pod tuto hranici provede opačnou akci.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `fanBlades` | `Transform` | Transformační bod listů virtuálního ventilátoru. |
| `fanIsOn` | `bool` | Určuje zapnutý stav napájení ventilátoru. |
| `targetFanSpeed` | `float` | Cílová rychlost otáčení listů ventilátoru. |
| `motorAcceleration` | `float` | Rychlost zrychlení motoru ventilátoru. |
| `usePhysics` | `bool` | Povoluje fyzikální výpočet rotace listů. |
| `fanRotationAxis` | `FanRotationAxis` | Vybraná osa otáčení listů ventilátoru. |
| `volumeMultiplier` | `float` | Násobič hlasitosti zvuku motoru ventilátoru. |
| `pitchMultiplier` | `float` | Násobič výšky tónu zvuku ventilátoru. |
| `inDuration` | `float` | Doba náběhu zvuku motoru ventilátoru. |
| `outDuration` | `float` | Doba doběhu zvuku motoru ventilátoru. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `FanRunning` | `void` | `bool isRunning` | Nastavuje zobrazení modelů listů podle stavu chodu ventilátoru. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte odkazy na oba vizuální objekty a nastavte `blurThreshold` typicky na `0.5` (50% otáček).
- **Vazby na ostatní prvky ve scéně:** Vyžaduje přímý odkaz na instanci skriptu `Fan` na stejném nebo nadřazeném objektu.

========================================

## Třída / Skript: `FractureStyle`
- **Relativní cesta k souboru:** `Assets/Scripts/Zoltr_BreakableObject.cs`

### 1. Účel a role v projektu
Definuje styl destrukce křehkého objektu â€“ buď roztříštěním celého tělesa, nebo lokalizovaným poškozením v místě kolize.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Slouží jako přepínač v Zoltr_BreakableObject pro volbu výpočtu sil působících na úlomky modelu při nárazu.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `unfracturedObject` | `GameObject` | GameObject celého nerozbitého modelu součástky. |
| `fracturedObjectRoot` | `GameObject` | Kořenový objekt s rozbitými úlomky součástky. |
| `impactForceThreshold` | `float` | Minimální rychlost nárazu pro rozbití objektu. |
| `breakStyle` | `FractureStyle` | Způsob rozbití součástky po nárazu kolize. |
| `preventChainReactions` | `bool` | Zamezuje řetězovému rozbíjení sousedních křehkých předmětů. |
| `localizedBreakRadius` | `float` | Poloměr oblasti poškození kolem místa nárazu. |
| `crumblePercentage` | `float` | Procento úlomků rozpadajících se na prach. |
| `explosionForce` | `float` | Explozivní síla působící na odletující úlomky. |
| `explosionRadius` | `float` | Poloměr výbuchu rozmetající úlomky do stran. |
| `explosionUpwardModifier` | `float` | Vertikální síla nadnášející úlomky při explozi. |
| `randomTumbleSpin` | `float` | Náhodná rotace udělená úlomkům při rozbití. |
| `breakParticlePrefab` | `GameObject` | Prefab prachových částic vygenerovaných při rozpadu. |
| `breakSound` | `AudioClip` | Zvukový klip doprovázející roztříštění křehkého objektu. |
| `startupGracePeriod` | `float` | Ochranná doba po spuštění hry ignorující poškození. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `HandleCollision` | `void` | `Collision collision` | Vyhodnocuje sílu nárazu pro kontrolu překročení mezí pevnosti. |
| `Shatter` | `void` | `Vector3 impactPoint` | Skryje celý model a vytvoří fyzikální úlomky na pozici. |
| `TakeDamageOrForce` | `void` | `float damageAmount, Vector3 hitPoint` | Aplikuje poškození na strukturální integritu křehkého objektu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Vyberte v dropdown menu styl, který nejlépe odpovídá materiálu objektu.
- **Vazby na ostatní prvky ve scéně:** Používá se přímo v komponentě Zoltr_BreakableObject.

========================================

## Třída / Skript: `FuturisticMenuParticles`
- **Relativní cesta k souboru:** `Assets/Scripts/FuturisticMenuParticles.cs`

### 1. Účel a role v projektu
Spravuje částicové efekty na pozadí hlavního menu. Vytváří ambientní futuristické prostředí a reaguje na přítomnost rukou hráče tím, že částice od sebe jemně odtlačuje.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript přistupuje k poli částic v `ParticleSystem` a porovnává jejich pozice s pozicemi VR ovladačů. Pokud se částice nachází v okruhu `detectionRadius`, aplikuje na její směr pohybu přídavný silový vektor směřující pryč od ovladače.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `placeInFrontOfCameraOnStart` | `bool` | Umístí částice před kameru při startu. |
| `distanceFromCamera` | `float` | Vzdálenost částicového systému od očí. |
| `maxParticles` | `int` | Maximální počet aktivních částic v systému. |
| `emissionRate` | `float` | Množství částic vygenerovaných za sekundu. |
| `particleLifetime` | `float` | Doba života částic v sekundách. |
| `noiseStrength` | `float` | Síla vlivu turbulenčního šumu částic. |
| `noiseFrequency` | `float` | Četnost změn turbulenčního šumu částic. |
| `noiseScrollSpeed` | `float` | Rychlost posunu pole turbulenčního šumu. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Upravte `pushForce` pro nastavení síly odtlačení a `detectionRadius` pro vymezení akční zóny.
- **Vazby na ostatní prvky ve scéně:** Vyžaduje standardní Unity `ParticleSystem` na stejném objektu.

========================================

## Třída / Skript: `HandLocomotionJoystick`
- **Relativní cesta k souboru:** `Assets/Scripts/HandLocomotionJoystick.cs`

### 1. Účel a role v projektu
Snímá náklon analogového joysticku z ovladačů přes Input System a aplikuje odpovídající rotaci na 3D model joysticku na virtuálních rukou hráče. Tím dosahuje 1:1 vizuální shody s fyzickým pohybem prstu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Čte hodnotu `Vector2` ze zaregistrované akce joysticku ovladače. Tyto hodnoty (X a Y) mapuje na rotační úhly kolem lokálních os X a Z modelu joysticku a aplikuje je přes `transform.localRotation`.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `handType` | `Handedness` | Určuje levou nebo pravou ruku hráče. |
| `pinchThreshold` | `float` | Práh stisku triggeru pro uchopení páčky. |
| `maxDragDistance` | `float` | Maximální vzdálenost vytažení páčky ovladače. |
| `moveSpeed` | `float` | Rychlost pohybu hráče ve scéně. |
| `deadzone` | `float` | Mrtvá zóna pro eliminaci nechtěného pohybu. |
| `forwardSource` | `Transform` | Transformace určující směr chůze vpřed. |
| `referenceFrame` | `Transform` | Referenční prostor pro výpočet směru chůze. |
| `joystickVisualPrefab` | `GameObject` | Prefab vizuálního ukazatele pozice joysticku. |
| `lineMaterial` | `Material` | Materiál čáry ukazující směr chůze. |
| `activeColor` | `Color` | Barva směrové čáry při pohybu. |
| `deadzoneColor` | `Color` | Barva směrové čáry v mrtvé zóně. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte Transform modelu joysticku do pole `joystickModel` and definujte maximální úhel výchylky `maxTiltAngle` (např. `20` stupňů).
- **Vazby na ostatní prvky ve scéně:** Propojuje se s InputActionReference pro levou a pravou ruku.

========================================

## Třída / Skript: `IntroDynamicHUD`
- **Relativní cesta k souboru:** `Assets/Scripts/IntroDynamicHUD.cs`

### 1. Účel a role v projektu
HUD rozhraní promítané před oči hráče během úvodní sekvence hry. Slouží k zobrazení ikon pro komfort a bezpečí a k vizualizaci kruhového pokroku při přeskočení úvodu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript ovládá zobrazení varovných ikon a lokalizovaných textů. Obsahuje metody `ShowIcon` a `HideHUD`, které plynule mění průhlednost (alpha) jednotlivých grafických prvků na základě požadavků ze skriptu `MainMenuIntroManager`.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `Initialize` | `void` | `MainMenuIntroManager manager, float requiredTime, float skipHudDistance, Shader ringShader, Shader iconShader, float sphereRadius` | Inicializuje varovné ikony a shader kruhového ukazatele přeskočení na HUD. |
| `ShowIcon` | `void` | `Sprite sprite` | Zobrazí vybranou varovnou ikonu na HUD obrazovce hráče. |
| `FadeOutHUD` | `void` | `` | Plynule skryje zobrazení všech varovných panelů HUD na obrazovce. |
| `FadeInSkipButton` | `void` | `` | Plynule zviditelní kruhové tlačítko pro přeskočení úvodu na HUD. |
| `FadeOutAndDestroy` | `void` | `` | Plynule skryje rozhraní HUD a následně zničí jeho GameObject. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zde přiřaďte sprity pro ikony Safe Space a Dizziness. Můžete upravit škálování ikon (`iconScale`) a jejich poziční odsazení vůči očím hráče.
- **Vazby na ostatní prvky ve scéně:** Tento skript je řízen centrálním manažerem úvodu a spawnuje se přímo před VR kamerou.

========================================

## Třída / Skript: `IntroEventType`
- **Relativní cesta k souboru:** `Assets/Scripts/MainMenuIntroManager.cs`

### 1. Účel a role v projektu
Výčtový typ a podpůrná struktura definující jednotlivé typy událostí, které mohou nastat během úvodního výkladu hry (např. spuštění dabingu, zatmění nebo zobrazení komfortního HUD).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Tento typ slouží ke klasifikaci a řízení toku událostí uvnitř MainMenuIntroManager. Umožňuje snadno rozpoznat a větvit chování podle typu události při načítání konfigurace.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `triggerTime` | `float` | Čas spuštění akce během úvodního intra. |
| `eventType` | `IntroEventType` | Typ prováděné akce během úvodního intra. |
| `scenarioIndex` | `int` | Index výukového scénáře spouštěný touto akcí. |
| `revealDuration` | `float` | Doba trvání animace odhalení součástky. |
| `alwaysPlayIntroForTesting` | `bool` | Vynutí přehrání úvodu při každém testování. |
| `narrationSource` | `AudioSource` | AudioSource pro přehrávání hlasu vypravěče. |
| `narrationClip` | `AudioClip` | AudioClip s nahrávkou hlasu doprovodného vypravěče. |
| `transitionSphere` | `Transform` | Transform sféry pro zatmívání obrazu VR. |
| `initialSphereRadius` | `float` | Počáteční poloměr stmívací sféry při startu. |
| `targetSphereRadius` | `float` | Cílový poloměr stmívací sféry po dokončení. |
| `cinematicVolume` | `Volume` | Hlasitost filmového doprovodu v úvodním intru. |
| `volumeFadeOutDuration` | `float` | Doba ztišení hudby na konci úvodu. |
| `mainMenuCanvasGroup` | `CanvasGroup` | CanvasGroup hlavního menu pro prolínání zobrazení. |
| `requiredHoldTime` | `float` | Doba držení tlačítka pro přeskočení úvodu. |
| `skipHudDistance` | `float` | Vzdálenost skip HUD panelu od očí. |
| `skipButtonShader` | `Shader` | Shader pro kruhový ukazatel držení tlačítka. |
| `iconOverlayShader` | `Shader` | Shader pro vykreslení varovných ikon navrch. |
| `safeSpaceIcon` | `Sprite` | Ikona bezpečného prostoru na HUD panelu. |
| `dizzinessIcon` | `Sprite` | Ikona varování před nevolností na HUD. |
| `iconDistance` | `float` | Vzdálenost varovných ikon od očí hráče. |
| `iconScale` | `float` | Měřítko velikosti varovných ikon na HUD. |
| `iconPositionOffset` | `Vector3` | Poziční odsazení varovných ikon na HUD. |
| `skipButtonScale` | `float` | Měřítko velikosti tlačítka přeskočení na HUD. |
| `scenarioHighlights` | `GameObject[]` | Seznam objektů zvýrazněných v průběhu výkladu. |
| `manualControllerVisualsToHide` | `GameObject[]` | Modely virtuálních ovladačů skryté během úvodu. |
| `OnIntroStart` | `UnityEvent` | Událost spuštěná na začátku úvodního výkladu. |
| `OnIntroEnd` | `UnityEvent` | Událost spuštěná na konci úvodního výkladu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `SkipIntro` | `void` | `` | Okamžitě ukončuje úvodní scénu a načítá hlavní nabídku menu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Používá se v seznamu událostí manažera úvodu pro výběr typu akce.
- **Vazby na ostatní prvky ve scéně:** Je pevně provázán s logikou MainMenuIntroManager.

========================================

## Třída / Skript: `IntroSkipButtonFollower`
- **Relativní cesta k souboru:** `Assets/Scripts/IntroSkipButtonFollower.cs`

### 1. Účel a role v projektu
Zajišťuje, aby se ukazatel přeskočení úvodu (Hold to Skip) držel v zorném poli hráče ve správné výšce a vzdálenosti, nezávisle na rotaci hlavy.

### 2. Jak skript funguje (Logika a vnitřní fungování)
V metodě `Update` skript zjišťuje pozici a směr pohledu hlavní kamery. Vypočítává cílovou pozici před kamerou s definovaným odstupem `distance`. Následně hladce interpoluje (`Vector3.Lerp` a `Quaternion.Slerp`) pozici a rotaci HUD panelu, aby se pohyboval přirozeně a nezpůsoboval motion sickness.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `distanceFromCamera` | `float` | Vzdálenost Skip tlačítka od kamery. |
| `verticalOffset` | `float` | Vertikální posun panelu pod výšku očí. |
| `followSpeed` | `float` | Rychlost sledování pohybu hlavy hráče. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Doporučená hodnota `distance` is `1.0` (1 metr před očima). `followSpeed` určuje dynamiku pohybu (hodnota `5` až `10` poskytuje příjemný pocit setrvačnosti).
- **Vazby na ostatní prvky ve scéně:** Umísťuje se na GameObject panelu Skip HUD.

========================================

## Třída / Skript: `ItemResetFromGround`
- **Relativní cesta k souboru:** `Assets/Scripts/ItemResetFromGround.cs`

### 1. Účel a role v projektu
Bezpečnostní prvek pro zabránění ztráty klíčových předmětů. Pokud hráč omylem upustí součástku (procesor, paměť RAM) a ta propadne texturou podlahy nebo odletí mimo hrací plochu, skript ji bezpečně vrátí zpět na pracovní stůl.

### 2. Jak skript funguje (Logika a vnitřní fungování)
V pravidelných intervalech nebo v metodě `Update` skript kontroluje světovou Y souřadnici objektu. Pokud tato hodnota klesne pod nastavený limit `killHeight`, skript okamžitě přenese pozici objektu na pozici referenčního bodu `spawnPoint`, resetuje lineární i úhlovou rychlost jeho Rigidbody na nulu a volitelně spawne vizuální efekt (např. záblesk částic).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `floorTag` | `string` | Kolizní tag pro identifikaci podlahy. |
| `resetYPos` | `float` | Výška na ose Y spouštějící reset. |
| `resetTimerTime` | `float` | Doba ležení na zemi před resetem. |
| `groundCheckLength` | `float` | Délka paprsku pro detekci země. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `OnDrawGizmosSelected` | `void` | `` | Vykresluje pomocné čáry mezní výšky a paprsku detekce podlahy v editoru. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `killHeight` pod úroveň podlahy (např. `-0.5`). Jako `spawnPoint` přiřaďte prázdný transform umístěný bezpečně nad pracovním stolem.
- **Vazby na ostatní prvky ve scéně:** Skript vyžaduje komponentu Rigidbody na objektu.

========================================

## Třída / Skript: `Lapis_AudioHelper`
- **Relativní cesta k souboru:** `Assets/Scripts/Lapis_AudioHelper.cs`

### 1. Účel a role v projektu
Globální pomocný audio manager využívající vzor Singleton. Poskytuje centralizovaný přístup k přehrávání standardních zvuků uživatelského rozhraní (např. kliknutí na tlačítka, najetí ukazatele, zavření oken).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Třída si drží referenci na vlastní instanci `Instance`. Obsahuje metody `PlayHoverSound` a `PlayClickSound`. Tyto metody interně využívají `AudioSource.PlayClipAtPoint` nebo sdílený AudioSource pro přehrání zvuků na pozici hráče.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `hoverClip` | `AudioClip` | Zvuk najetí myši na tlačítko. |
| `clickClip` | `AudioClip` | Zvuk kliknutí na tlačítko v menu. |
| `transitionSwooshClip` | `AudioClip` | Zvuk švihnutí při přechodu menu. |
| `transitionStinger` | `AudioClip` | Krátká hudební znělka při přechodu scény. |
| `typeSound` | `AudioClip` | Zvukový efekt psaní psacího stroje. |
| `wipeSound` | `AudioClip` | Zvukový efekt vymazání textu na tabuli. |
| `HoverClip` | `AudioClip` | Vlastnost vracející zvuk najetí na tlačítko. |
| `ClickClip` | `AudioClip` | Vlastnost vracející zvuk kliknutí na tlačítko. |
| `TransitionSwooshClip` | `AudioClip` | Vlastnost vracející zvuk švihnutí v menu. |
| `TransitionStinger` | `AudioClip` | Vlastnost vracející hudební znělku přechodu. |
| `TypeSound` | `AudioClip` | Vlastnost vracející zvuk psaní na stroji. |
| `WipeSound` | `AudioClip` | Vlastnost vracející zvuk vymazání textu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `PlayHover` | `void` | `float volume = 1f` | Přehrává zvukový efekt najetí kurzoru myši na UI element. |
| `PlayClick` | `void` | `float volume = 1f` | Přehrává zvukový efekt kliknutí na UI element v menu. |
| `PlayTransitionSwoosh` | `void` | `float volume = 1f` | Přehrává zvukový efekt švihnutí při přechodech v rozhraní. |
| `PlayType` | `void` | `Vector3 position, float volume = 0.4f, int priority = 250` | Přehrává zvuk stisku klávesy psacího stroje na dané pozici. |
| `PlayWipe` | `void` | `Vector3 position, float volume = 0.4f` | Přehrává zvukový efekt mazání tabule houbou na dané pozici. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte výchozí zvukové efekty pro Hover (najetí) a Click (kliknutí).
- **Vazby na ostatní prvky ve scéně:** Přístup odkudkoliv přes: `Lapis_AudioHelper.Instance.PlayHoverSound()`.

========================================

## Třída / Skript: `LearningScenarioComponentWindow`
- **Relativní cesta k souboru:** `Assets/Scripts/LearningScenarioComponentWindow.cs`

### 1. Účel a role v projektu
Skript spravující interaktivní holografický 3D panel s popisy součástek. Zobrazuje podrobné lokalizované informace o vybraném hardwaru, včetně názvu, technických specifikací a popisu jeho reálné funkce v počítači.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript obsahuje metodu `DisplayComponentInfo(ShowDescriptionObject info)`. Ta načte lokalizační klíče z předaného objektu a pomocí lokalizačního systému Unity dosadí texty do polí `TextMeshProUGUI` na panelu. Následně panel zviditelní (např. aktivací nebo plynulým animovaným zvětšením scale).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `scenario` | `LearningScenarioStart` | Odkaz na řídící skript výukového scénáře. |
| `componentId` | `string` | Identifikátor zobrazované počítačové součástky. |
| `componentRoot` | `Transform` | Kořenový transform 3D modelu součástky. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `SelectComponent` | `void` | `` | Aktivuje detailní režim zkoumání a zobrazení popisu pro danou součástku. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zkontrolujte přiřazení textových komponent TextMeshPro pro název, specifikace a popis.
- **Vazby na ostatní prvky ve scéně:** Je volán globálním manažerem `ShowDescriptionObjectManager` při uchopení jakéhokoliv popsaného objektu.

========================================

## Třída / Skript: `LearningScenarioStart`
- **Relativní cesta k souboru:** `Assets/Scripts/LearningScenarioStart.cs`

### 1. Účel a role v projektu
Inicializační skript pro výukové scénáře. Spouští konkrétní úlohu (např. rozebírání PC), resetuje stav a aktivuje potřebné objekty ve scéně učebny.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Při aktivaci (např. stiskem tlačítka na začátku scénáře) skript prode pole `spawnObjects` a aktivuje je. Zároveň může zaslat zprávu do systému `zoltr_buildProgress` pro spuštění sledování postupu.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `id` | `string` | Unikátní textový identifikátor tohoto scénáře. |
| `componentRoot` | `Transform` | Společný kořenový transform všech součástek PC. |
| `libraryWindowRoot` | `Transform` | Kořenový transform pro okna s popisky. |
| `libraryAnchor` | `Transform` | Kotevní transformace pro uspořádání oken. |
| `startButton` | `Button` | Tlačítko pro spuštění výukového scénáře. |
| `backButton` | `Button` | Tlačítko pro ukončení výukového scénáře. |
| `pcCaseDoor` | `OpenComponentVR` | Skript ovládající dveře počítačové skříně. |
| `pcCaseDoorObject` | `Transform` | Transformační bod dveří počítačové skříně. |
| `playerHead` | `Transform` | Transformace hlavy VR hráče pro sledování. |
| `inspectAnchor` | `Transform` | Kotevní transformace před hráčem pro inspekci. |
| `animateCaseDoorFlyAway` | `bool` | Povoluje animaci odletu dveří při startu. |
| `caseDoorFlyDuration` | `float` | Doba trvání animace odletu dveří skříně. |
| `caseDoorFlyDistance` | `float` | Vzdálenost, do které dveře skříně odletí. |
| `caseDoorFlyUpOffset` | `float` | Výškový posun dveří při odletu nahoru. |
| `caseDoorFlyRotateDegrees` | `float` | Úhel rotace dveří během odletu skříně. |
| `hideCaseDoorAfterFly` | `bool` | Skryje objekt dveří po dokončení odletu. |
| `autoGenerateWindows` | `bool` | Povoluje automatické generování informačních oken. |
| `windowPrefab` | `GameObject` | Prefab šablony okna s popisem součástky. |
| `windowParent` | `Transform` | Společný rodič pro vygenerovaná informační okna. |
| `placeholderWindowDepth` | `float` | Hloubkové odsazení pro vygenerovaná okna. |
| `autoGenerateArcLayout` | `bool` | Uspořádá informační okna do kruhového oblouku. |
| `libraryRadius` | `float` | Poloměr oblouku pro rozložení informačních oken. |
| `libraryArcDegrees` | `float` | Úhel rozpětí oblouku rozložení informačních oken. |
| `libraryHeightOffset` | `float` | Výškové odsazení oblouku rozložení informačních oken. |
| `libraryCenterOverride` | `Transform` | Náhradní střed pro oblouk rozložení oken. |
| `libraryForwardOffset` | `float` | Dopředné odsazení oblouku rozložení informačních oken. |
| `minimumLibraryY` | `float` | Minimální povolená výška informačních oken. |
| `autoGenerateRevealAnchors` | `bool` | Povoluje automatické vygenerování bodů odhalení. |
| `revealDistanceFromCase` | `float` | Vzdálenost vysunutí součástek z počítačové skříně. |
| `revealHeightFromCase` | `float` | Výška vysunutí součástek nad počítačovou skříň. |
| `revealArcDegrees` | `float` | Úhel rozpětí kruhového oblouku vysunutých součástek. |
| `caseOpenLeadTime` | `float` | Doba čekání před otevřením skříně. |
| `moveDuration` | `float` | Doba trvání animace pohybu součástek. |
| `introStagger` | `float` | Časový odstup mezi odhalováním jednotlivých součástek. |
| `libraryStagger` | `float` | Časový odstup generování jednotlivých informačních oken. |
| `animateIntroInParallel` | `bool` | Spustí úvodní animace všech součástek současně. |
| `animateAdditionalInParallel` | `bool` | Spustí vedlejší animace všech prvků současně. |
| `inspectEnterDuration` | `float` | Doba přiblížení součástky k očím hráče. |
| `inspectExitDuration` | `float` | Doba návratu součástky na původní místo. |
| `hiddenScaleMultiplier` | `float` | Zmenšení měřítka neaktivních skrytých oken. |
| `moveAwayDistance` | `float` | Vzdálenost odsunutí ostatních součástek při inspekci. |
| `moveAwayUpOffset` | `float` | Výškové odsunutí ostatních součástek při inspekci. |
| `moveHiddenItemsForward` | `bool` | Posune skryté součástky dopředu při startu. |
| `hiddenItemsForwardDistance` | `float` | Vzdálenost posunutí skrytých součástek dopředu. |
| `hiddenItemsForwardSpread` | `float` | Rozptyl skrytých součástek do stran. |
| `inspectScaleMultiplier` | `float` | Měřítko zvětšení součástky při detailním zkoumání. |
| `disablePlayerMovementInScene` | `bool` | Zablokuje pohyb hráče během přehrávání animací. |
| `CurrentState` | `ScenarioState` | Vlastnost vracející aktuální stav výukové lekce. |
| `position` | `Vector3` | Vlastnost výchozí pozice součástky ve skříni. |
| `rotation` | `Quaternion` | Vlastnost výchozí rotace součástky ve skříni. |
| `localScale` | `Vector3` | Vlastnost výchozího měřítka součástky ve skříni. |
| `position` | `Vector3` | Vlastnost výchozí pozice součástky ve skříni. |
| `rotation` | `Quaternion` | Vlastnost výchozí rotace součástky ve skříni. |
| `active` | `bool` | Vlastnost aktivního stavu součástky v kroku. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `StartScenario` | `void` | `` | Spouští výukový scénář, otevírá skříň a rozmisťuje informační okna. |
| `SelectComponentById` | `void` | `string componentId` | Aktivuje zkoumání konkrétní součástky podle jejího textového identifikátoru. |
| `SelectComponent` | `void` | `Transform componentRoot` | Spouští režim zkoumání pro vybranou transformaci součástky. |
| `SelectFromWindow` | `void` | `Transform windowRoot` | Aktivuje zkoumání součástky vybrané kliknutím na informační okno. |
| `ExitInspectMode` | `void` | `` | Ukončuje detailní zkoumání a vrací součástku na původní pozici. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zadejte název scénáře `scenarioName` a přidejte všechny objekty, které se mají na startu zjevit, do seznamu `spawnObjects`.
- **Vazby na ostatní prvky ve scéně:** Propojeno s interaktivními tlačítky v učebně.

========================================

## Třída / Skript: `LearningScenarioWindowLabel`
- **Relativní cesta k souboru:** `Assets/Scripts/LearningScenarioWindowLabel.cs`

### 1. Účel a role v projektu
Zajišťuje dynamickou lokalizaci statických textových nápisů (např. nadpisy 'Specifikace:', 'Funkce:') na holografickém panelu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Naslouchá událostem změny jazyka v Unity Localization a automaticky aktualizuje přiřazené texty na základě klíčů z lokalizační tabulky.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `labelText` | `string` | TMP textové pole pro nadpis okna. |
| `subtitleText` | `string` | TMP textové pole pro podtitul okna. |
| `textHeight` | `float` | Výška textové oblasti na plátně popisku. |
| `fontSize` | `int` | Velikost písma textu v popisku součástky. |
| `textColor` | `Color` | Barva písma textu v popisku součástky. |
| `billboardToPlayer` | `bool` | Otáčí popisek čelem k hlavě hráče. |
| `yawOnly` | `bool` | Omezuje otáčení popisku pouze na ose Y. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zadejte přesný název lokalizační tabulky do pole `localizedTable`.
- **Vazby na ostatní prvky ve scéně:** Umísťuje se na textové objekty uvnitř holografického panelu.

========================================

## Třída / Skript: `Menu`
- **Relativní cesta k souboru:** `Assets/Scripts/Menu.cs`

### 1. Účel a role v projektu
Zpracovává navigaci a logiku hlavního menu v učebně. Umožňuje hráči spustit výuku, přejít do nastavení nebo hru bezpečně vypnout.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript obsahuje metody jako `PlayGame()`, `OpenSettings()` a `QuitGame()`, které reagují na kliknutí na UI tlačítka. Pro přechod do hry využívá asynchronní načítání s plynulým zatměním obrazovky.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `cardName` | `string` | Identifikační název karty v nabídce menu. |
| `canvasGroup` | `CanvasGroup` | CanvasGroup pro plynulé stmívání karty menu. |
| `panel` | `RectTransform` | GameObject panelu s obsahem karty menu. |
| `targetScene` | `string` | Název scény načítané po stisku karty. |
| `cardName` | `string` | Identifikační název karty v nabídce menu. |
| `canvasGroup` | `CanvasGroup` | CanvasGroup pro plynulé stmívání karty menu. |
| `panel` | `RectTransform` | GameObject panelu s obsahem karty menu. |
| `subCards` | `SubCardConfig[]` | Seznam podřízených karet v této kategorii. |
| `returnButtonCanvasGroup` | `CanvasGroup` | CanvasGroup tlačítka zpět pro prolínání zobrazení. |
| `returnButtonPanel` | `RectTransform` | GameObject panelu pro navigační tlačítko zpět. |
| `mainCards` | `MainCardConfig[]` | Seznam karet na hlavní úrovni menu. |
| `ambientLight` | `Light` | Světelný zdroj měnící barvu při přechodech. |
| `transitionBurstParticles` | `ParticleSystem` | Částicový efekt stisknutí tlačítka v menu. |
| `ambientTransitionSpeed` | `float` | Rychlost změny barvy okolního osvětlení učebny. |
| `waveStaggerDelay` | `float` | Časový posun při animování tlačítek menu. |
| `individualFadeDuration` | `float` | Doba prolínání jednoho tlačítka v menu. |
| `hoverTranslationY` | `float` | Výškový posun karty menu při najetí. |
| `hoverScale` | `float` | Měřítko zvětšení tlačítka při najetí ovladačem. |
| `pressScale` | `float` | Měřítko zmenšení tlačítka při stisknutí ovladačem. |
| `smoothSpeed` | `float` | Rychlost vyhlazování pohybu animací v menu. |
| `hoverClip` | `AudioClip` | Zvukový klip přehrávaný při najetí na menu. |
| `clickClip` | `AudioClip` | Zvukový klip přehrávaný při kliknutí v menu. |
| `transitionSwooshClip` | `AudioClip` | Zvukový klip přehrávaný při přechodech v menu. |
| `hapticDuration` | `float` | Doba trvání vibrací ovladače při kliknutí. |
| `IsTransitioning` | `bool` | Vlastnost určující probíhající přechod mezi scénami. |
| `OnClickAction` | `Action<PointerEventData>` | Vlastnost události vyvolané kliknutím na kartu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `SetHoveredPanel` | `void` | `VRPanelController panel` | Označuje vybraný panel rozhraní za aktivně zaměřený ukazatelem. |
| `ClearHoveredPanel` | `void` | `VRPanelController panel` | Ruší označení panelu za zaměřený při ztrátě fokusu ukazatele. |
| `IsAnyPanelFocused` | `bool` | `` | Ověřuje, zda je v současnosti zaměřen jakýkoliv panel rozhraní. |
| `PlaySound` | `void` | `AudioClip clip` | Přehrává zadaný zvukový klip prostřednictvím lokálního AudioSource. |
| `TriggerHapticFeedback` | `void` | `PointerEventData eventData, float amplitude, float duration` | Spouští vibrační odezvu v ovladači odpovídající běžným akcím v UI. |
| `TriggerClickHapticFeedback` | `void` | `PointerEventData eventData` | Spouští intenzivní vibrační odezvu při stisknutí tlačítka ovladačem. |
| `Initialize` | `void` | `Menu manager, RectTransform rt` | Inicializuje základní parametry a rozměry komponenty menu. |
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Spouští vizuální změny a vibrace ovladače při najetí ukazatele. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Vrací vizuální stav prvku do klidu při opuštění ukazatelem. |
| `ForceHoverState` | `void` | `bool state` | Vynucuje a uzamyká vizuální stav najetí ukazatele na prvek. |
| `ResetAlpha` | `void` | `float alpha` | Obnovuje výchozí hodnotu průhlednosti plátna této nabídky menu. |
| `OnPointerDown` | `void` | `PointerEventData eventData` | Zmenšuje měřítko a spouští odezvu při stisknutí tlačítka ukazatelem. |
| `OnPointerUp` | `void` | `PointerEventData eventData` | Obnovuje měřítko najetí při uvolnění stisku tlačítka ukazatelem. |
| `OnPointerClick` | `void` | `PointerEventData eventData` | Vyvolává akce události kliknutí a spouští zvuky přechodů. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zadejte název scény pro spuštění hry do pole `startSceneName` a přiřaďte objekty panelů nastavení a menu.
- **Vazby na ostatní prvky ve scéně:** Propojeno s UI tlačítky přes UnityEvents.

========================================

## Třída / Skript: `OpenComponentVR`
- **Relativní cesta k souboru:** `Assets/Scripts/OpenComponentVR.cs`

### 1. Účel a role v projektu
Zprostředkovává otevření holografického popisu součástky při interakci ve VR (např. při ukázání paprskem a stisku triggeru).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Implementuje standardní rozhraní interakce Unity XRI. Při detekci interakce předá referenci na svůj `ShowDescriptionObject` do globálního manažeru popisků, který následně aktualizuje a zobrazí 3D panel.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `pivot` | `Transform` | Transformační střed otáčení pro zkoumání součástky. |
| `targetRotation` | `Vector3` | Cílové natočení součástky pro zobrazení popisků. |
| `duration` | `float` | Doba trvání animace otevření popisků součástky. |
| `axis` | `Axis` | Osa rotace pro otáčení zkoumaného objektu. |
| `animateOnStart` | `bool` | Spustí rotaci součástky ihned po startu. |
| `dismantled` | `bool` | Vlastnost značící demontovaný stav součástky skříně. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ToggleOpen` | `void` | `` | Přepíná rotaci součástky mezi zavřeným slotem a otevřeným stavem. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Ujistěte se, že je přiřazeno pole `descriptionObject` odkazující na popis této součástky.
- **Vazby na ostatní prvky ve scéně:** Umísťuje se na interaktivní PC součástky.

========================================

## Třída / Skript: `OpenSettingsOnB`
- **Relativní cesta k souboru:** `Assets/Scripts/OpenSettingsOnB.cs`

### 1. Účel a role v projektu
VR naslouchač, který umožňuje hráči kdykoliv vyvolat panel nastavení přímo před sebe stiskem dedikovaného tlačítka na ovladači (typicky tlačítko B na pravém nebo Y na levém ovladači).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript monitoruje stav zaregistrované vstupní akce (Input Action). Při detekci stisku zkontroluje, zda je panel nastavení aktivní. Pokud ne, aktivuje ho, vypočítá pozici přesně ve vzdálenosti `spawnDistance` před hlavou hráče a otočí panel co nejpřesněji k očím. Při dalším stisku panel skryje.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `settingsSceneName` | `string` | Název scény s nastavením parametrů simulátoru. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `spawnDistance` na příjemnou vzdálenost (doporučeno `0.8` až `1.2` metru). Přiřaďte GameObject plátna nastavení do `settingsCanvas`.
- **Vazby na ostatní prvky ve scéně:** Zaregistrujte vstupní akci pro stisk tlačítka (např. `XRI RightHand/Input/menu` nebo secondaryButton).

========================================

## Třída / Skript: `Quiz`
- **Relativní cesta k souboru:** `Assets/Scripts/Quiz.cs`

### 1. Účel a role v projektu
Komplexní mozek interaktivních 3D kvízových stojanů. Zajišťuje kompletní tok kvízu: asynchronně načítá otázky z JSON formátu na základě vybraného tématu, generuje náhodné rozložení odpovědí na tlačítka, vizuálně indikuje správné/špatné odpovědi pomocí ikon a barevných změn tlačítek, spouští typewriter efekt vypisování otázek a na konci kvízu animuje radialní graf úspěšnosti s přehráním odpovídajícího mluveného hodnocení.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript načte text JSON souboru a naplní jím interní struktury otázek. Při zobrazení otázky spustí Coroutine pro typewriter efekt. Po kliknutí na tlačítko porovná index vybrané odpovědi se správným indexem. Zobrazí fajfky/křížky a aktivuje tlačítko 'Další'. Na konci kvízu vypočítá procentuální úspěšnost, spustí Coroutine pro kruhový graf (který rotuje a plní se interpolací) a přehraje audiodabing (excelentní, dobrý, průměrný nebo špatný výkon).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `selectedTopic` | `QuizTopic` | Vybraný tematický okruh otázek pro kvíz. |
| `computerQuestionFile` | `TextAsset` | JSON soubor s otázkami o počítačovém hardwaru. |
| `peripheralsQuestionFile` | `TextAsset` | JSON soubor s otázkami o vnějších periferiích. |
| `stringTableName` | `string` | Název lokalizační tabulky pro texty kvízu. |
| `questionText` | `TextMeshProUGUI` | TMP textový panel pro zobrazení znění otázky. |
| `answerButtons` | `Button[]` | Seznam čtyř tlačítek pro výběr odpovědi hráče. |
| `answer1CanvasGroup` | `CanvasGroup` | CanvasGroup prvního tlačítka výběru odpovědi kvízu. |
| `answer2CanvasGroup` | `CanvasGroup` | CanvasGroup druhého tlačítka výběru odpovědi kvízu. |
| `answer3CanvasGroup` | `CanvasGroup` | CanvasGroup třetího tlačítka výběru odpovědi kvízu. |
| `answer4CanvasGroup` | `CanvasGroup` | CanvasGroup čtvrtého tlačítka výběru odpovědi kvízu. |
| `feedbackText` | `TextMeshProUGUI` | TMP text pro zobrazení vyhodnocení odpovědi. |
| `coloredFeedbackText` | `TextMeshProUGUI` | Barevný TMP text s podrobným hodnocením odpovědi. |
| `scoreText` | `TextMeshProUGUI` | TMP textové pole pro výsledné celkové skóre. |
| `restartButton` | `Button` | Tlačítko pro restartování průběhu spuštěného kvízu. |
| `nextButton` | `Button` | Tlačítko pro přechod na další otázku kvízu. |
| `correctAnswerIcons` | `GameObject[]` | Seznam zelených ikon pro správně zodpovězené otázky. |
| `wrongAnswerIcons` | `GameObject[]` | Seznam červených ikon pro špatně zodpovězené otázky. |
| `circleSize` | `float` | Velikost kruhového grafu úspěšnosti na konci kvízu. |
| `fillAnimationDuration` | `float` | Doba trvání animace plnění kruhového grafu. |
| `waveStaggerDelay` | `float` | Časový posun při animování tlačítek menu. |
| `individualFadeDuration` | `float` | Doba prolínání jednoho tlačítka v menu. |
| `typewriterSpeed` | `float` | Rychlost vypisování znaků textu na tabuli. |
| `highPerformanceAudio` | `AudioClip` | Audio nahrávka vypravěče pro vynikající výsledné hodnocení. |
| `goodPerformanceAudio` | `AudioClip` | Audio nahrávka vypravěče pro dobré výsledné hodnocení. |
| `moderatePerformanceAudio` | `AudioClip` | Audio nahrávka vypravěče pro průměrné výsledné hodnocení. |
| `lowPerformanceAudio` | `AudioClip` | Audio nahrávka vypravěče pro slabé výsledné hodnocení. |
| `audioFadeOutDuration` | `float` | Doba ztišení zvuku po vyhodnocení výsledků kvízu. |
| `questions` | `List<QuizQuestion>` | Vlastnost vracející seznam všech otázek v kvízu. |
| `questionKey` | `string` | Vlastnost klíče lokalizace pro znění otázky. |
| `answerKeys` | `List<string>` | Vlastnost seznamu lokalizačních klíčů pro odpovědi. |
| `correctAnswerIndex` | `int` | Vlastnost indexu správné volby v otázce. |
| `hoverScale` | `float` | Měřítko zvětšení tlačítka při najetí ovladačem. |
| `pressScale` | `float` | Měřítko zmenšení tlačítka při stisknutí ovladačem. |
| `smoothSpeed` | `float` | Rychlost vyhlazování pohybu animací v menu. |
| `hoverHapticAmplitude` | `float` | Intenzita vibrace ovladače při najetí na tlačítko. |
| `clickHapticAmplitude` | `float` | Intenzita vibrace ovladače při stisknutí tlačítka. |
| `hapticDuration` | `float` | Doba trvání vibrací ovladače v sekundách. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ShowNextQuestion` | `void` | `` | Načítá a plynule zobrazuje další kvízovou otázku z JSON. |
| `RestartQuiz` | `void` | `` | Vynuluje skóre a načítá první otázku vybraného tématu kvízu. |
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Aktivuje zvýraznění a jemné vibrace při najetí na tlačítko. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Ruší vizuální zvýraznění na kvízových tlačítkách při sjetí. |
| `OnPointerDown` | `void` | `PointerEventData eventData` | Zmenšuje velikost tlačítka a spouští vibrace při stisku. |
| `OnPointerUp` | `void` | `PointerEventData eventData` | Obnovuje původní velikost kvízového tlačítka při uvolnění stisku. |
| `OnPointerClick` | `void` | `PointerEventData eventData` | Odesílá zvolený index odpovědi k vyhodnocení správnosti kvízu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte JSON soubory s otázkami do polí `computerQuestionFile`, `cablesQuestionFile` a `peripheralsQuestionFile`. Propojte textové komponenty a tlačítka. Do polí audio klipů přiřaďte příslušné dabingové soubory.
- **Vazby na ostatní prvky ve scéně:** Skript komunikuje s Unity Localization pro zobrazení rozhraní v češtině nebo angličtině.

========================================

## Třída / Skript: `SceneAttribute`
- **Relativní cesta k souboru:** `Assets/Scripts/SceneAttribute.cs`

### 1. Účel a role v projektu
Pomocná editorová struktura (PropertyAttribute), která zjednodušuje vývojářům zadávání názvů scén v Unity Inspector. Zabraňuje překlepům, které by vedly k pádům hry při načítání scén.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Označuje textové proměnné v kódu. Custom Property Drawer (ve složce Editor) toto označení detekuje a vykreslí v Unity Inspector přehledný dropdown seznam všech scén definovaných v nastavení sestavení (Build Settings).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Používá se v kódu jako: `[Scene] public string targetScene;`.
- **Vazby na ostatní prvky ve scéně:** Nemá žádnou runtime režii, funguje pouze v editoru.

========================================

## Třída / Skript: `SceneTransitionManager`
- **Relativní cesta k souboru:** `Assets/Scripts/SceneTransitionManager.cs`

### 1. Účel a role v projektu
Globální správce přechodů a načítání scén navržený speciálně pro VR. Zabraňuje nevolnosti při načítání (motion sickness) tím, že před spuštěním načítání plynule zatmí obrazovku hráče do černé barvy (fade out), na pozadí asynchronně načte novou scénu a po jejím spuštění obrazovku opět plynule rozjasní (fade in).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript implementuje vzor Singleton. Využívá metodu `StartCoroutine` pro asynchronní načítání scény přes `SceneManager.LoadSceneAsync`. Během přechodu vykresluje Quad s černým materiálem `fadeMaterial` přesně před očima hráče (nebo mění intenzitu zatmění na VR kameře).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `fadeDuration` | `float` | Doba trvání stmívací animace přechodu scény. |
| `fadeColor` | `Color` | Cílová barva stmívání obrazovky při přechodu. |
| `use3DFade` | `bool` | Povoluje použití 3D sféry pro zatmění. |
| `force3DFadeInXR` | `bool` | Vynutí 3D sféru stmívání v headsetu VR. |
| `forceFadeLayerToRenderedCamera` | `bool` | Směruje vrstvu zatmění přímo do kamery hráče. |
| `transitionCanvas` | `Canvas` | Plátno pro vykreslení 2D stmívací plochy. |
| `fadeGroup` | `CanvasGroup` | CanvasGroup spravující plynulé prolínání přechodové obrazovky. |
| `fadeImage` | `Image` | UI obrázek pro celoobrazovkové 2D stmívání. |
| `loadingContainer` | `GameObject` | GameObject panelu s nápisem a ukazatelem průběhu. |
| `progressBar` | `Image` | UI obrázek pro zobrazení postupu načítání scény. |
| `loadingText` | `TextMeshProUGUI` | TMP textové pole s procentuálním stavu načítání. |
| `driveAudioTransition` | `bool` | Povoluje postupné ztlumení zvuku při načítání. |
| `useAdvancedMusicTransition` | `bool` | Povoluje pokročilé prolínání hudby mezi scénami. |
| `transitionStinger` | `AudioClip` | Hudební znělka přehrávaná během načítání scény. |
| `useGlobalAudioFadeFallback` | `bool` | Povoluje nouzové ztlumení všech zdrojů zvuku. |
| `globalAudioFadeSpeed` | `float` | Rychlost nouzového ztlumení celého zvuku hry. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `LoadSceneSmooth` | `void` | `string sceneName, bool useBackgroundLoading = true` | Spustí zatmění obrazu VR a asynchronně načte novou scénu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Ujistěte se, že `fadeMaterial` používá shader podporující transparentnost a černou barvu. Nastavte výchozí čas přechodu `defaultFadeDuration` (např. `1.0`s).
- **Vazby na ostatní prvky ve scéně:** Třída je persistentní napříč scénami (`DontDestroyOnLoad`). Volá se přes: `SceneTransitionManager.Instance.LoadSceneSmooth(sceneName)`.

========================================

## Třída / Skript: `Settings`
- **Relativní cesta k souboru:** `Assets/Scripts/Settings.cs`

### 1. Účel a role v projektu
Skript zajišťující správu uživatelských nastavení. Propojuje posuvníky (slidery) v UI s hlasitostí zvuku a haptikou a ukládá uživatelské volby do paměti.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Při změně hodnoty na UI posuvníku skript přepočítá hodnotu na logaritmickou škálu (vhodnou pro decibely v Audio Mixer) a nastaví příslušný parametr v Audio Mixer. Pro haptiku uloží float hodnotu síly vibrací. Všechny hodnoty ukládá přes `PlayerPrefs` pod unikátními klíči.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `languageButtonText` | `TextMeshProUGUI` | TMP textový panel tlačítka nastavení jazyka. |
| `stringTableName` | `string` | Název lokalizační tabulky s nastavením textů. |
| `languageButtonKey` | `string` | Klíč lokalizace pro nápis tlačítka přepínání. |
| `languageButtonFallback` | `string` | Záložní nápis na tlačítku přepínání jazyků. |
| `controlsObjectToShow` | `GameObject` | GameObject panelu s nápovědou ovládání hry. |
| `settingsObjectToHide` | `GameObject` | GameObject hlavního nastavení skrývaný při nápovědě. |
| `controlsImage` | `Image` | UI obrázek pro zobrazení schématu ovládání. |
| `controlsSprite` | `Sprite` | Sprite se schématem rozložení tlačítek ovladačů. |
| `hideControlsOnStart` | `bool` | Skryje nápovědu ovládání při spuštění hry. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ChangeScene` | `void` | `string sceneName` | Volá správce přechodů scén pro načtení zadané scény. |
| `ChangeLanguage` | `void` | `string languageCode` | Mění aktivní jazyk lokalizace podle zadaného kódu (cs/en). |
| `ChangeToNextLanguage` | `void` | `` | Přepíná na následující dostupný jazyk v lokalizačním systému. |
| `ShowControlsPng` | `void` | `` | Zobrazí panel s obrázkem rozložení ovládacích prvků ovladačů. |
| `HideControlsPng` | `void` | `` | Skryje panel s obrázkem rozložení ovládacích prvků ovladačů. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Propojte posuvníky pro hudbu, dabing a vibrace. Zkontrolujte, zda názvy parametrů Audio Mixer přesně odpovídají řetězcům v kódu.
- **Vazby na ostatní prvky ve scéně:** Načítá uložená nastavení hned při spuštění hry.

========================================

## Třída / Skript: `ShatteringGlass`
- **Relativní cesta k souboru:** `Assets/Scripts/ShatteringGlass.cs`

### 1. Účel a role v projektu
Třída zajišťující fyzikální rozbití skla. Nahrazuje statický model skleněné tabule za prefab roztříštěného skla při silném nárazu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Při detekci silného nárazu v `OnCollisionEnter` skript schová původní objekt a na jeho místě instancuje `brokenPrefab`. Tento prefab obsahuje desítky malých úlomků s vlastními collidery a Rigidbodies, které se vlivem gravitace sesypou na zem.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `shatteringGlassObject` | `GameObject` | GameObject celého nerozbitého skla ve scéně. |
| `shatteringLimit` | `float` | Minimální síla nárazu potřebná k rozbití. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte model celého skla `glassMesh` a prefab střepů `brokenPrefab`.
- **Vazby na ostatní prvky ve scéně:** Vyžaduje collider nastavený na detekci kolizí.

========================================

## Třída / Skript: `ShowDescriptionObject`
- **Relativní cesta k souboru:** `Assets/Scripts/ShowDescriptionObject.cs`

### 1. Účel a role v projektu
Jednoduchý datový kontejner, který nese lokalizační klíče pro popis konkrétního hardwaru. Každá součástka má tento skript, aby hra věděla, co o ní napsat na holografickém panelu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Neobsahuje žádnou logiku, slouží pouze k uložení lokalizačních klíčů (strings), které pak čte `LearningScenarioComponentWindow`.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `objectName` | `string` | Unikátní název součástky pro zobrazení popisku. |
| `description` | `string` | Lokalizační klíč s podrobným popisem součástky. |
| `objectImage` | `Material` | Materiál s obrázkem náhledu počítačové součástky. |
| `dubbingClip` | `AudioClip` | Audio nahrávka popisu součástky doprovodným vypravěčem. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ShowObjectDescription` | `void` | `` | Aktivuje zobrazení informačního okna s popisem pro danou součástku. |
| `ShowObjectDescription` | `void` | `UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs args` | Aktivuje zobrazení informačního okna s popisem pro danou součástku. |
| `HideObjectDescription` | `void` | `` | Skryje informační okno s popisem pro danou součástku. |
| `HideObjectDescription` | `void` | `UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs args` | Skryje informační okno s popisem pro danou součástku. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zadejte klíče z lokalizační tabulky pro Název (`componentNameKey`), Specifikace (`specsKey`) a Popis (`descriptionKey`).
- **Vazby na ostatní prvky ve scéně:** Musí být umístěn na každé sestavitelné PC součástce.

========================================

## Třída / Skript: `ShowDescriptionObjectManager`
- **Relativní cesta k souboru:** `Assets/Scripts/ShowDescriptionObjectManager.cs`

### 1. Účel a role v projektu
Globální správce popisných hologramů. Detekuje, když hráč vezme součástku do ruky, a automaticky aktivuje 3D panel s popiskem.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Naslouchá událostem uchopení (`selectEntered`) na všech `XRGrabInteractable` objektech. Při uchopení načte `ShowDescriptionObject` součástky a předá ho do UI panelu k zobrazení.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `nameText` | `TMP_Text` | TMP panel pro zobrazení názvu součástky. |
| `descriptionText` | `TMP_Text` | TMP panel pro zobrazení popisu součástky. |
| `soundManager` | `SoundManager` | Odkaz na správce zvuků v učebně. |
| `audioSource` | `AudioSource` | AudioSource pro přehrávání zvukových efektů popisků. |
| `typeSound` | `AudioClip` | Audio nahrávka zvuku psaní na stroji. |
| `wipeSound` | `AudioClip` | Audio nahrávka zvuku smazání textu tabule. |
| `stringTableName` | `string` | Název lokalizační tabulky pro popisy součástek. |
| `currentlyShowObject` | `ShowDescriptionObject` | Aktuálně zobrazený datový objekt s popisem. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `TurnOnObject` | `void` | `UnityEngine.Object objRef` | Zviditelňuje vybrané panely holografických informačních oken. |
| `TurnOffObject` | `void` | `UnityEngine.Object objRef` | Skrývá vybrané panely holografických informačních oken. |
| `StopFadingSources` | `void` | `` | Zastaví spuštěné coroutiny pro postupné ztlumení zvuku. |
| `SwitchToObject` | `IEnumerator` | `ShowDescriptionObject obj` | Plynule přepíná zobrazené popisy součástek s typewriter efektem. |
| `PrintAllLocalizationKeys` | `void` | `` | Pomocná metoda vypisující všechny lokalizační klíče do konzole. |
| `StartWriteAnimation` | `IEnumerator` | `` | Spouští zvuk psacího stroje a postupné odkrývání písma. |
| `AutoPopulateLocalizationTables` | `void` | `` | Pomocný skript pro automatické doplnění lokalizačních řetězců. |
| `RemoveAutoGeneratedLocalizations` | `void` | `` | Pomocný skript pro vymazání automaticky generovaných lokalizací. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte referenci na panel `displayPanel`.
- **Vazby na ostatní prvky ve scéně:** Propojeno s XR Interaction Managerem.

========================================

## Třída / Skript: `SnapGrabInteractable`
- **Relativní cesta k souboru:** `Assets/Scripts/SnapGrabInteractable.cs`

### 1. Účel a role v projektu
Rozšířená verze interaktivního objektu Unity XRI. Umožňuje přesné přichycení držených předmětů (např. ventilátory, šroubky, RAM) k předem definovaným SnapPointům při jejich uvolnění. Navíc podporuje mechaniku šroubování â€“ hráč může objektem po přichycení otáčet kolem určené osy krouživým pohybem ruky, čímž simuluje utahování šroubů.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Při uvolnění předmětu (`OnSelectExited`) skript projde všechny volné `SnapPoint` objekty ve scéně. Pokud se některý nachází v okruhu `snapDistance`, zahájí plynulou interpolaci pozice a rotace směrem k tomuto bodu (`UpdateSmoothSnap`). Po zapadnutí nastaví fyziku na kinematic. Pokud je povoleno šroubování, skript sleduje kruhový pohyb ovladače kolem osy šroubu a převádí jej na otáčení modelu.

**Klíčová metoda šroubování (`UpdateScrewingRotation`):**
```csharp
void UpdateScrewingRotation()
    {
        if (interactorsSelecting.Count == 0 || currentSnapPoint == null) return;

        var grabber = interactorsSelecting[0];
        if (grabber == null || grabber.transform == null) return;

        Vector3 currentControllerPos = grabber.transform.position;

        if (!trackingControllerForScrewing)
        {
            // Start tracking
            lastControllerPosition = currentControllerPos;
            trackingControllerForScrewing = true;
            return;
        }

        // Calculate controller movement
        Vector3 controllerMovement = currentControllerPos - lastControllerPosition;
        lastControllerPosition = currentControllerPos;

        // Get the snap point position and determine the rotation axis
        Transform snapTransform = currentSnapPoint.attachTransform != null 
            ? currentSnapPoint.attachTransform 
            : currentSnapPoint.transform;

        Vector3 snapPos = snapTransform.position;
        Vector3 rotationAxis = GetScrewingAxis(snapTransform);

        // Project controller movement onto a plane perpendicular to the rotation axis
        Vector3 movementOnPlane = Vector3.ProjectOnPlane(controllerMovement, rotationAxis);

        // Calculate rotation around the axis based on circular movement
        if (movementOnPlane.magnitude > 0.001f)
        {
            // Get vector from snap point to controller
            Vector3 toController = currentControllerPos - snapPos;
            Vector3 toControllerOnPlane = Vector3.ProjectOnPlane(toController, rotationAxis);

            // Calculate the angular movement using cross product
            Vector3 cross = Vector3.Cross(toControllerOnPlane.normalized, movementOnPlane);
            float rotationAmount = Vector3.Dot(cross, rotationAxis) * screwingSensitivity;

            // Apply rotation around the chosen axis while keeping position locked
            Vector3 currentPos = transform.position;
            transform.RotateAround(snapPos, rotationAxis, rotationAmount * Mathf.Rad2Deg);
            
            // Lock position back to where it should be (in case RotateAround moved it slightly)
            if (objectAttachTransform != null)
            {
                Vector3 currentOffset = objectAttachTransform.position - transform.position;
                transform.position = snapPos - currentOffset;
            }
        }
    }
```

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `snapPoints` | `SnapPoint[]` | Seznam kompatibilních upevňovacích bodů ve scéně. |
| `snapDistance` | `float` | Maximální vzdálenost pro přichycení součástky k socketu. |
| `objectAttachTransform` | `Transform` | Kotevní transformace pro úchop rukou hráče. |
| `parentOnSnap` | `bool` | Připojí součástku pod transformaci cílového socketu. |
| `snapPointTag` | `string` | Kolizní tag pro vyhledání kompatibilního socketu. |
| `snapSpeed` | `float` | Rychlost plynulého přichycení součástky do patice. |
| `unsnapDistanceMultiplier` | `float` | Násobič vzdálenosti pro odpojení součástky taháním. |
| `allowScrewingRotation` | `bool` | Povoluje utahování šroubu otáčením ruky hráče. |
| `screwingSensitivity` | `float` | Citlivost převodu otáčení ruky na šroubování. |
| `screwingAxis` | `ScrewingAxis` | Vybraná osa otáčení šroubku při utahování. |
| `IsSnapped` | `bool` | Vlastnost určující, zda je součástka přichycená. |
| `CurrentSnapPoint` | `SnapPoint` | Vlastnost vracející aktuální obsazený kotevní bod. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ForceUnsnap` | `void` | `` | Okamžitě odpojí součástku ze socketu a zapne gravitaci. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `snapDistance` (např. `0.1` metru). Zaškrtněte `allowScrewingRotation` pro šroubky a zvolte správnou osu otáčení `screwingAxis`.
- **Vazby na ostatní prvky ve scéně:** Vyžaduje přítomnost `SnapPoint` ve scéně.

========================================

## Třída / Skript: `SnapPoint`
- **Relativní cesta k souboru:** `Assets/Scripts/SnapPoint.cs`

### 1. Účel a role v projektu
Reprezentuje cílový bod v prostoru (3D souřadnice a rotaci), kam se může `SnapGrabInteractable` přichytit. Zobrazuje zelenou vizuální pomůcku (Gizmo) v editoru pro snadné polohování.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript slouží jako pasivní datový kontejner a detekční bod. Při spuštění scény si drží stav obsazenosti (`occupied`) a v Unity Editoru vykresluje pomocí metody `OnDrawGizmos` barevný drátěný box pro usnadnění přesného prostorového zarovnání.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `attachTransform` | `Transform` | Kotevní transformace pro upevnění přichyceného objektu. |
| `occupied` | `bool` | Vlastnost určující obsazení tohoto kotevního bodu. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Umístěte SnapPoint přesně tam, kde má součástka dosednout (např. otvory pro šrouby).
- **Vazby na ostatní prvky ve scéně:** Ukládá si informaci o obsazenosti (`occupied`).

========================================

## Třída / Skript: `SoundManager`
- **Relativní cesta k souboru:** `Assets/Scripts/SoundManager.cs`

### 1. Účel a role v projektu
Centrální zvukový manažer hry. Zajišťuje přehrávání ambientní hudby na pozadí a prostorových 3D zvuků pro interakce ve světě.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript implementuje návrhový vzor Singleton a spravuje fond (pool) 3D zdrojů zvuku (`AudioSource`). V metodě `Awake` inicializuje hudbu na pozadí, a při volání metod `PlaySFX` dynamicky přiřazuje volné zdroje zvuku k přehrání prostorových efektů.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `sceneName` | `string` | Název scény s učebnou pro nastavení. |
| `bgm` | `AudioClip` | AudioClip s hudebním doprovodem na pozadí. |
| `minDistance` | `float` | Minimální vzdálenost pro prostorové šíření zvuku. |
| `maxDistance` | `float` | Maximální vzdálenost pro prostorové šíření zvuku. |
| `loop` | `bool` | Povoluje nekonečnou smyčku přehrávání hudby pozadí. |
| `rolloffMode` | `AudioRolloffMode` | Typ útlumu hlasitosti zvuku se vzdáleností. |
| `fadeOutDuration` | `float` | Doba ztišení hudby při zastavení přehrávání. |
| `holdDuration` | `float` | Doba setrvání hlasitosti před začátkem ztlumení. |
| `fadeInDuration` | `float` | Doba náběhu hlasitosti při spuštění hudby. |
| `musicCrossfadeDuration` | `float` | Doba vzájemného prolínání dvou hudebních skladeb. |
| `stopMusicWhenNoClip` | `bool` | Zastaví přehrávání, pokud není přiřazen AudioClip. |
| `useUnscaledTime` | `bool` | Využívá neovlivněný čas pro stmívání zvuku. |
| `sceneMusicCrossfadeDuration` | `float` | Doba prolínání hudby při načtení scény. |
| `useAdvancedSceneTransitions` | `bool` | Povoluje pokročilé prolínání hudby při přechodech. |
| `initialSFXPoolSize` | `int` | Počáteční velikost fondu pro zvukové efekty. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `Default2D` | `SoundOptions` | `float vol = 1f` | Vrací výchozí nastavení pro přehrávání 2D zvukových klipů. |
| `Default3D` | `SoundOptions` | `float vol = 1f` | Vrací výchozí nastavení pro přehrávání prostorových 3D zvuků. |
| `SoftUI` | `SoundOptions` | `` | Vrací specifické nastavení pro zvuky uživatelského rozhraní. |
| `Cinematic` | `TransitionMusicOptions` | `` | Vrací nastavení pro hudební doprovod v filmových sekvencích. |
| `PlaySFX2D` | `AudioSource` | `AudioClip clip, float volume = 1f` | Přehrává standardní 2D zvukový efekt při zadané hlasitosti. |
| `PlaySFX3D` | `AudioSource` | `AudioClip clip, Vector3 worldPosition, float volume = 1f` | Přehrává prostorový 3D zvukový efekt na zadaných souřadnicích. |
| `PlaySFX` | `AudioSource` | `AudioClip clip, Vector3 position, SoundOptions options` | Přehrává zvukový efekt na pozici s nastavitelnými parametry. |
| `StopSFX` | `void` | `AudioSource source, float fadeOutDuration = 0.5f` | Spustí postupné ztišení zvuku a následně zastaví přehrávání. |
| `PreloadSceneMusicTransition` | `Coroutine` | `string sceneName, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Načítá hudbu pro cílovou scénu ještě před spuštěním přechodu. |
| `PreloadSceneMusicTransition` | `Coroutine` | `string sceneName, TransitionMusicOptions options, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Načítá hudbu pro cílovou scénu ještě před spuštěním přechodu. |
| `TransitionToSceneMusic` | `Coroutine` | `string sceneName, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Spustí prolínání hudby odpovídající stavu načítání nové scény. |
| `TransitionToSceneMusic` | `Coroutine` | `string sceneName, TransitionMusicOptions options, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Spustí prolínání hudby odpovídající stavu načítání nové scény. |
| `PlayMusic` | `void` | `AudioClip clip, float crossfadeDuration = 1.5f` | Spouští přehrávání hudby na pozadí s nastavitelným prolínáním. |
| `StopMusic` | `void` | `float fadeOutDuration = 1.5f` | Ztlumí a zastaví přehrávání aktivní hudby na pozadí. |
| `PauseMusic` | `void` | `` | Dočasně pozastaví přehrávání hudební stopy na pozadí. |
| `ResumeMusic` | `void` | `` | Obnoví dříve pozastavené přehrávání hudby na pozadí. |
| `SetMusicPitch` | `void` | `float pitch` | Nastavuje výšku tónu (rychlost) přehrávání hudby pozadí. |
| `SetMusicVolume` | `void` | `float volume` | Nastavuje úroveň hlasitosti kanálu hudby na pozadí. |
| `SetMasterVolume` | `void` | `float volume` | Nastavuje celkovou úroveň hlasitosti hlavního mixeru hry. |
| `SetSFXVolume` | `void` | `float volume` | Nastavuje úroveň hlasitosti kanálu pro zvukové efekty. |
| `GlobalFadeOut` | `void` | `float speedMultiplier = 10f` | Plynule ztlumí všechny aktivní zvukové kanály hry. |
| `GlobalFadeIn` | `void` | `float speedMultiplier = 10f` | Plynule obnoví hlasitost všech aktivních zvukových kanálů. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Ujistěte se, že AudioSource je správně nakonfigurován pro prostorový zvuk (3D Spatial Blend nastaven na 1.0).
- **Vazby na ostatní prvky ve scéně:** Nastavení hlasitosti je napojeno na `Settings`.

========================================

## Třída / Skript: `VRInspectRotate`
- **Relativní cesta k souboru:** `Assets/Scripts/VRInspectRotate.cs`

### 1. Účel a role v projektu
Umožňuje hráči detailně prohlížet a otáčet uchopený objekt ve VR. Když hráč drží předmět a pohne joystickem na ovladači, předmět se začne otáčet ve vzduchu před ním, což usnadňuje jeho zkoumání ze všech stran.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript zachycuje vstup z joysticku ovladače prostřednictvím registrace v XR Interaction Toolkitu. V metodě `Update` přepočítává náklon joysticku na úhlovou rotaci a aplikuje ji přímo na transformaci zkoumaného objektu kolem os X a Y.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `referenceFrame` | `Transform` | Referenční souřadný systém pro otáčení součástky. |
| `yawDegreesPerMeter` | `float` | Citlivost otáčení součástky na ose Y joystickem. |
| `pitchDegreesPerMeter` | `float` | Citlivost otáčení součástky na ose X joystickem. |
| `lockPositionWhileInspecting` | `bool` | Zablokuje pozici součástky v ruce při inspekci. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `SetInspectEnabled` | `void` | `bool enabled` | Aktivuje nebo deaktivuje ovládání otáčení zkoumaného objektu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Tato komponenta se přidává přímo na XR Grab Interactable objekty. Nevyžaduje další úpravy.
- **Vazby na ostatní prvky ve scéně:** Skript automaticky přebírá vstup z ovladače, který provedl select objektu.

========================================

## Třída / Skript: `VRReturnButton`
- **Relativní cesta k souboru:** `Assets/Scripts/VRReturnButton.cs`

### 1. Účel a role v projektu
Interaktivní tlačítko se speciálními vizuálními efekty. Border tlačítka reaguje na držení (HDR záře se plní po obvodu) a rychlé klikání (spamování generuje intenzivní záři ve středu tlačítka). Používá se pro bezpečný návrat do menu, aby hráč neodešel nechtěným jedním klikem.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript v metodě `Update` vyhodnocuje čas stisku a držení tlačítka. Postupně zvyšuje hodnotu postupu (`holdProgress`), která se přenáší jako parametr do shaderu materiálu tlačítka, a při překročení limitu vyvolá akci návratu.

**Vnitřní smyčka tlačítka (`Update`):**
```csharp
private void Update()
    {
        if (rectTransform == null) return;
        
        timeSinceLastClick += Time.unscaledDeltaTime;
        UpdateTargetState();
        
        float t = 1f - Mathf.Exp(-smoothSpeed * Time.unscaledDeltaTime);

        rectTransform.anchoredPosition3D = Vector3.Lerp(rectTransform.anchoredPosition3D, targetPosition, t);
        rectTransform.localScale = Vector3.Lerp(rectTransform.localScale, targetScale, t);

        currentAlpha = Mathf.Lerp(currentAlpha, targetAlpha, t);
        if (fadeGroup != null)
        {
            fadeGroup.alpha = currentAlpha;
        }

        // Hold & Spam logic tick
        if (isPressed && !hasTriggeredAction)
        {
            currentHoldProgress += Time.unscaledDeltaTime / requiredHoldTime;
        }
        else if (!isPressed)
        {
            currentHoldProgress -= Time.unscaledDeltaTime * holdDecayRate;
        }
        currentHoldProgress = Mathf.Clamp01(currentHoldProgress);
        
        currentSpamPulse = Mathf.Lerp(currentSpamPulse, 0f, 10f * Time.unscaledDeltaTime);

        // Auto trigger when hold is full
        if (currentHoldProgress >= 1f && !hasTriggeredAction)
        {
            hasTriggeredAction = true;
            TriggerAction(null);
        }
        
        // Reset trigger lock if fully released
        if (!isPressed && currentHoldProgress <= 0.01f)
        {
            hasTriggeredAction = false;
        }

        if (panelMaterial != null)
        {
            currentHighlight = Mathf.Lerp(currentHighlight, targetHighlight, t);
            
            panelMaterial.SetFloat("_FillAmount", currentHoldProgress);
            panelMaterial.SetFloat("_SpamPulse", currentSpamPulse);
            
            // Legacy highlight (can be supported if shader adds it, or acts as a fallback)
            if (panelMaterial.HasProperty("_HighlightAmount"))
                panelMaterial.SetFloat("_HighlightAmount", currentHighlight);
                
            float aspect = rectTransform.rect.width / Mathf.Max(rectTransform.rect.height, 1f);
            if (aspect > 0 && !float.IsInfinity(aspect)) 
                panelMaterial.SetFloat("_AspectRatio", aspect);
        }
    }
```

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `targetScene` | `string` | Název načítané scény po aktivaci tlačítka. |
| `hoverTranslationY` | `float` | Výškový posun tlačítka zpět při najetí. |
| `hoverScale` | `float` | Měřítko zvětšení tlačítka při najetí ovladačem. |
| `pressScale` | `float` | Měřítko zmenšení tlačítka při stisku triggeru. |
| `smoothSpeed` | `float` | Rychlost vyhlazování pohybu tlačítka v menu. |
| `requiredHoldTime` | `float` | Doba podržení tlačítka k aktivaci návratu. |
| `spamBoostAmount` | `float` | Přidaný pokrok na jedno rychlé stisknutí. |
| `holdDecayRate` | `float` | Rychlost poklesu indikátoru držení při uvolnění. |
| `hoverClip` | `AudioClip` | Zvukový klip přehrávaný při najetí na tlačítko. |
| `clickClip` | `AudioClip` | Zvukový klip přehrávaný při stisku tlačítka. |
| `hapticDuration` | `float` | Doba trvání vibrací ovladače při stisku. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Spustí záření obrysu tlačítka při najetí ovladačem. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Zhasne záření obrysu tlačítka při opuštění ovladačem. |
| `OnPointerDown` | `void` | `PointerEventData eventData` | Zahájí měření doby držení tlačítka zpět při stisku. |
| `OnPointerUp` | `void` | `PointerEventData eventData` | Přeruší měření doby držení tlačítka při uvolnění stisku. |
| `OnPointerClick` | `void` | `PointerEventData eventData` | Přidá bonus k postupu při rychlém klikání na tlačítko. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Skript vyžaduje napojení na materiál tlačítka využívající speciální shader `UI/InteractiveButton`.
- **Vazby na ostatní prvky ve scéně:** Při úspěšném naplnění indexu aktivuje SceneTransitionManager pro hladký přesun do jiné scény.

========================================

## Třída / Skript: `objectdissapear`
- **Relativní cesta k souboru:** `Assets/Scripts/objectdissapear.cs`

### 1. Účel a role v projektu
Pomocný skript pro optimalizaci scény. Umožňuje dočasným objektům (jako jsou krabice od součástek nebo ochranné kryty) po určité době plynule zmizet a uvolnit tak paměť a fyzikální procesor.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Po aktivaci skript spustí odpočet. Po uplynutí `lifetime` zače plynule snižovat hodnotu průhlednosti materiálů na všech rendererech objektu. Jakmile alfatest dosáhne nuly, objekt je zničen (`Destroy`).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `delayBeforeDisappear` | `float` | Čas před spuštěním stmívací animace mizení. |
| `animationDuration` | `float` | Doba trvání stmívání průhlednosti materiálu objektu. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `lifetime` v sekundách (např. `10.0`s) a zaškrtněte `fadeOut` pro hladké zmizení namísto okamžitého smazání.
- **Vazby na ostatní prvky ve scéně:** Umístěte na jakékoliv nedůležité fyzikální předměty.

========================================

<div style='page-break-before: always;'></div>

# Fyzika a Propojování Kabelů (Assets/Scripts/zoltr/)
---

## Třída / Skript: `ZoltrCableDynamicInteractor`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/ZoltrCableDynamicInteractor.cs`

### 1. Účel a role v projektu
Skript pro detekci kolizí s kabely. Umísťuje se na rychle se pohybující objekty (jako jsou VR ruce hráče nebo zahozené předměty). Provádí optimalizované matematické Sweep testy (kruh, kapsle, krabice) vůči allen aktivním kabelům, čímž zabraňuje tomu, aby ruka 'proskočila' skrz tenký kabel bez kolize.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Tato komponenta se přichycuje k interaktivním objektům a ovladačům. V metodě `Update` provádí Sweep detekce (koule, kapsle) vůči zaregistrovaným instancím kabelů, přičemž přenáší hybnost na zasažené částice kabelu.

**Výpočet kolize koule s trajektorií částice (`EvaluateCollision`):**
```csharp
public void EvaluateCollision(Vector3 point, float cableRadius, out Vector3 pushDir, out float penetration)
    {
        pushDir = Vector3.zero;
        penetration = 0f;

        Vector3 currentPos = transform.position;
        Quaternion currentRot = transform.rotation;

        if (shape == InteractorShape.Sphere)
        {
            Vector3 scale = transform.lossyScale;
            float maxScale = Mathf.Max(scale.x, Mathf.Max(scale.y, scale.z));
            float scaledRadius = sphereRadius * maxScale;
            // Exact mathematically swept sphere (Capsule trajectory)
            Vector3 centerOld = oldPosition + oldRotation * sphereOffset;
            Vector3 centerNew = currentPos + currentRot * sphereOffset;
            
            Vector3 movement = centerNew - centerOld;
            float magSqr = movement.sqrMagnitude;
            
            float t = 0f;
            if (magSqr > 0.000001f)
            {
                t = Mathf.Clamp01(Vector3.Dot(point - centerOld, movement) / magSqr);
            }
            
            Vector3 closestPointOnTrajectory = centerOld + movement * t;
            Vector3 diff = point - closestPointOnTrajectory;
            float distSqr = diff.sqrMagnitude;
            
            float combinedRadius = scaledRadius + cableRadius;
            if (distSqr < combinedRadius * combinedRadius && distSqr > 0.000001f)
            {
                float dist = Mathf.Sqrt(distSqr);
                pushDir = diff / dist;
                penetration = combinedRadius - dist;
            }
            return;
        }
```

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `shape` | `InteractorShape` | Tvar kolizní oblasti interaktoru s kabelem. |
| `momentumTransfer` | `float` | Koeficient přenosu hybnosti na fyziku kabelu. |
| `sphereRadius` | `float` | Poloměr kolizní sféry interaktoru s kabelem. |
| `sphereOffset` | `Vector3` | Poziční odsazení kolizní sféry interaktoru kabelu. |
| `capsuleRadius` | `float` | Poloměr kolizní kapsle interaktoru s kabelem. |
| `capsuleHeight` | `float` | Délka kolizní kapsle interaktoru s kabelem. |
| `capsuleDirection` | `int` | Směrová osa kolizní kapsle interaktoru kabelu. |
| `capsuleOffset` | `Vector3` | Poziční odsazení kolizní kapsle interaktoru kabelu. |
| `boxOffset` | `Vector3` | Poziční odsazení kolizního boxu interaktoru kabelu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `EvaluateCollision` | `void` | `Vector3 point, float cableRadius, out Vector3 pushDir, out float penetration` | Počítá průnik dráhy kolizní sféry s částicemi kabelu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Tuto komponentu umístěte na ovladače/ruce hráče.
- **Vazby na ostatní prvky ve scéně:** Automaticky se registruje v globálním seznamu kolizních interaktorů pro kabely.

========================================

## Třída / Skript: `object_id`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_helpers.cs`

### 1. Účel a role v projektu
Výčtový typ (enum) definující unikátní identifikátory pro všechny počítačové součástky a kabely v projektu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Slouží jako klíč pro porovnávání kompatibility při zapojování součástek do socketů.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `dependencyItems` | `zoltr_socketItem[]` | Seznam závislých součástek pro zapojení objektu. |
| `needsToBe` | `ItemRuleOption` | Požadovaný stav závislé součástky pro montáž. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `GetComponentKey` | `int` | `object_id component, int index = 0` | Vrací unikátní číselný identifikátor pro hardwarovou součástku. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Vyberte ID odpovídající typu součástky.
- **Vazby na ostatní prvky ve scéně:** Používá se napříč celým socketovým systémem.

========================================

## Třída / Skript: `zoltr_audioHelper`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_audioHelper.cs`

### 1. Účel a role v projektu
Zvukový pomocník pro socketový a kabelový systém. Obsahuje a přehrává zvuky pro přichycení součástek, tahání (napětí kabelů) a jejich vytržení ze socketů.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Pomocný skript spravující a přehrávající lokální audio efekty pro fyzikální interakce. Na základě událostí z kabelů a socketů přehrává specifické audio klipy na zadaných souřadnicích.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `itemCollisionSounds` | `AudioClip[]` | Seznam zvuků nárazů předmětů o stůl. |
| `itemPickupSound` | `AudioClip` | Zvuk přehrávaný při uchopení předmětu rukou. |
| `componentSnapSound` | `AudioClip` | Zvuk úspěšného zacvaknutí součástky do patice. |
| `componentUnsnapSound` | `AudioClip` | Zvuk vytažení součástky z patice desky. |
| `componentPullingSound` | `AudioClip` | Zvuk pnutí při tahání za kabel. |
| `fanLoopSound` | `AudioClip` | Zvuková smyčka chodu a hučení ventilátoru. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte vhodné AudioClips pro snap, unsnap a tahání kabelu.
- **Vazby na ostatní prvky ve scéně:** Volá se programově ze skriptů kabelu a socketů.

========================================

## Třída / Skript: `zoltr_buildProgress`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_buildProgress.cs`

### 1. Účel a role v projektu
Vyhodnocuje celkový stav a postup sestavování počítače. Kontroluje obsazenost určených socketů a po úspěšném dokončení všech kroků aktivuje konečnou fázi výukového scénáře.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript monitoruje stav zapojení součástek v poli socketů. V pravidelných intervalech (nebo po změně stavu) prochází pole `zsi` a přepočítává procentuální stav sestavení, který odesílá do UI textových komponent.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `zsi` | `zoltr_socketItem[]` | Seznam sledovaných socketů pro kontrolu postupu. |
| `text` | `string` | Textová šablona pro zobrazení procent postupu. |
| `allItems` | `progressItem[]` | Seznam všech sledovaných součástí pro stav. |
| `buildProgress` | `float` | Procentuální ukazatel celkového stavu sestavení počítače. |
| `parentUiObject` | `GameObject` | Rodičovský panel HUD pro zobrazení stavu. |
| `textPrefab` | `GameObject` | Prefab textového popisku pro zobrazení postupu. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Vložte všechny požadované sockety do pole `requiredSockets`.
- **Vazby na ostatní prvky ve scéně:** Po dokončení vyvolá zaregistrovanou událost `onBuildComplete`.

========================================

## Třída / Skript: `zoltr_cable`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_cable.cs`

### 1. Účel a role v projektu
Pokročilý fyzikální simulátor kabelů navržený speciálně pro VR. Využívá metodu XPBD (Extended Position-Based Dynamics) rozdělenou do několika fyzikálních sub-kroků (substeps). Zajišťuje realistické chování (průvěs, ohybová tuhost, tah), podporuje kolize s okolím, stabilizaci ohybu u konektorů (tangent locking) a obousměrnou fyzikální vazbu s Rigididbody (kabel dokáže zatáhnout za visící předmět). Vykresluje se buď pomocí LineRendereru, nebo ohýbáním kostí (Skinned Mesh Rigging) importovaného modelu kabelu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Pokročilá simulace fyziky ohebných těles. V metodě `FixedUpdate` spouští smyčku sub-kroků Verletovy integrace, aplikuje délkové a ohybové vazby a v `LateUpdate` promítá vypočtené pozice částic na kosti mesh modelu.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `startPoint` | `Transform` | Kotevní transformace pro začátek kabelu. |
| `endPoint` | `Transform` | Kotevní transformace pro konec kabelu. |
| `segmentCount` | `int` | Počet fyzikálních segmentů simulující ohyb kabelu. |
| `cableLength` | `float` | Celková délka simulovaného kabelu v metrech. |
| `allowUnpluggable` | `bool` | Povoluje vytržení kabelu při velkém tahu. |
| `unpluggableDistance` | `float` | Vzdálenost tahu ruky spouštějící vytržení kabelu. |
| `cableMaterial` | `Material` | Materiál pro vykreslení 3D těla kabelu. |
| `startColor` | `Color` | Počáteční barva vykreslovaného těla kabelu. |
| `endColor` | `Color` | Koncová barva vykreslovaného těla kabelu. |
| `textureTiling` | `float` | Opakování textury podél těla simulovaného kabelu. |
| `substeps` | `int` | Počet sub-kroků výpočtu fyziky za snímek. |
| `bendingStiffness` | `float` | Tuhost v ohybu určující ohebnost kabelu. |
| `anchorStiffness` | `float` | Tuhost ohybu kabelu v místech zapojení. |
| `motionDamping` | `float` | Tlumení pohybu zabraňující nekonečnému vlnění kabelu. |
| `enableCollisions` | `bool` | Povoluje kolize částic kabelu s okolím. |
| `enableContinuousCollision` | `bool` | Aktivuje nepřetržitou detekci kolizí částic kabelu. |
| `extraCollisionChecksPerSegment` | `int` | Dodatečné kontrolní body kolize na jeden segment. |
| `cableRadius` | `float` | Poloměr kolizního těla simulovaného kabelu. |
| `collisionMask` | `LayerMask` | Maska vrstev pro detekci kolizí kabelu. |
| `collisionFriction` | `float` | Tření při kontaktu kabelu s okolními povrchy. |
| `collisionRestitution` | `float` | Pružnost kabelu při nárazu na překážky. |
| `pullRigidbodies` | `bool` | Povoluje přenos tahové síly na zapojené Rigidbody. |
| `positionPullMultiplier` | `float` | Síla posunu přenášená z kabelu na předmět. |
| `rotationPullMultiplier` | `float` | Síla rotace přenášená z kabelu na předmět. |
| `maxPullVelocity` | `float` | Maximální rychlost přenosu tahové síly na objekt. |
| `cableElasticity` | `float` | Pružnost určující míru roztažitelnosti simulovaného kabelu. |
| `enableVRSmoothing` | `bool` | Povoluje vyhlazování chvění kabelu ve VR. |
| `visualSmoothing` | `float` | Míra vyhlazení vizuálního zobrazení ohybů kabelu. |
| `lineSubdivisions` | `int` | Počet dělení segmentů pro hladké vykreslení. |
| `boneForwardAxis` | `BoneForwardAxis` | Směrová osa kostí modelu pro ohýbání. |
| `applyTwistOffset` | `bool` | Povoluje úhlové kroucení kostí podél kabelu. |
| `twistOffsetAngle` | `float` | Úhel kroucení kostí podél délky kabelu. |
| `boneStartOffset` | `float` | Odsazení počátku ohýbání kostry od konektoru. |
| `boneEndOffset` | `float` | Odsazení konce ohýbání kostry od konektoru. |
| `isStartGrabbed` | `bool` | Indikuje uchopení počátečního konektoru. |
| `isEndGrabbed` | `bool` | Indikuje uchopení koncového konektoru. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `AutoAssignBones` | `void` | `` | Automaticky vyhledá child transformace kostí modelu SkinnedMesh. |
| `CableStartLocked` | `void` | `bool grabbed` | Upevní počáteční částici fyziky kabelu k transformaci konektoru. |
| `CableEndLocked` | `void` | `bool grabbed` | Upevní koncovou částici fyziky kabelu k transformaci konektoru. |
| `SetSegmentCountFromRig` | `void` | `` | Nastaví počet částic fyziky podle počtu nalezených kostí. |
| `ResolveDynamicInteractor` | `void` | `ZoltrCableDynamicInteractor interactor, Vector3 objVelocity` | Přenáší hybnost z kolidujícího interaktoru na segmenty kabelu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Pokud se kabel chová nestabilně nebo příliš pruží, zvyšte počet `substeps` (sub-kroků fyziky) na 10 nebo 12.
- **Vazby na ostatní prvky ve scéně:** Propojuje počáteční a koncový konektor (typu zoltr_socketItem).

========================================

## Třída / Skript: `zoltr_itemHandle`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_itemHandle.cs`

### 1. Účel a role v projektu
Reprezentuje úchytový bod (handle) na komponentu nebo konektoru kabelu. Zajišťuje, aby ruka hráče uchopila součástku na správném místě a ve správné orientaci.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Třída definující bod úchopu pro konektory. V metodách `Awake` a `Start` konfiguruje interakční vrstvy XR Grab Interactable, aby zajistila korektní zarovnání ruky hráče.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `handleCollider` | `BoxCollider` | BoxCollider vymezující oblast uchopení konektoru rukou. |
| `interactionLayerName` | `string` | Název interakční vrstvy pro úchop předmětu. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zarovnejte handle collider přesně s 3D modelem konektoru nebo úchytu.
- **Vazby na ostatní prvky ve scéně:** Slouží jako cíl pro detekci doteku ruky hráče.

========================================

## Třída / Skript: `zoltr_physicsAudio`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_physicsAudio.cs`

### 1. Účel a role v projektu
Generuje realistické zvuky při fyzikálních nárazech předmětů o okolí. Výška tónu a hlasitost zvuku se dynamicky odvíjí od relativní rychlosti nárazu a hmotnosti kolidujících objektů.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript naslouchá kolizím Rigidbody v metodě `OnCollisionEnter`. Vypočítává relativní rychlost nárazu a podle ní upravuje hlasitost a výšku tónu přehrávaného zvuku kolize.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `minImpactVelocity` | `float` | Minimální rychlost nárazu pro přehrání zvuku. |
| `maxImpactVelocity` | `float` | Maximální rychlost nárazu pro plnou hlasitost. |
| `velocityGrain` | `float` | Krok rozlišení rychlosti nárazu pro zvuk. |
| `minVolume` | `float` | Minimální hlasitost přehrávaného zvuku nárazu. |
| `maxVolume` | `float` | Maximální hlasitost přehrávaného zvuku nárazu. |
| `pitchVariation` | `float` | Náhodná odchylka výšky tónu při nárazu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `DisableAudio` | `void` | `` | Dočasně vypne generování zvuků kolizí pro daný objekt. |
| `EnableAudioAfter` | `void` | `float duration` | Znovu povolí generování zvuků kolizí po uplynutí doby. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Přiřaďte sadu zvuků nárazů pro různé materiály (kov, plast).
- **Vazby na ostatní prvky ve scéně:** Vyžaduje přítomnost Rigidbody na stejném objektu.

========================================

## Třída / Skript: `zoltr_socket`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_socket.cs`

### 1. Účel a role v projektu
Slot, do kterého se vkládají komponenty nebo konektory kabelů. Obsahuje informaci o typu podporovaného komponentu (`socket_type`) a vizualizuje stav slotu (zelený box = volný, červený = obsazený) přímo v Unity Editoru.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Třída reprezentující montážní slot. V metodě `Awake` inicializuje počáteční zapojené součástky a na základě událostí kolize spouští kontroly kompatibility zoltr_socketItem.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `socket_type` | `object_id` | Typ hardwarového slotu pro vložení součástky. |
| `used` | `bool` | Označuje obsazení slotu součástkou. |
| `snappedItemOnAwake` | `zoltr_socketItem` | Součástka vložená do patice při startu. |
| `usable` | `bool` | Indikuje připravenost patice pro zapojení. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zvolte správný `socket_type` odpovídající hardwaru (např. CPU_SOCKET).
- **Vazby na ostatní prvky ve scéně:** Detekuje vstupy kolidujících zoltr_socketItem součástek.

========================================

## Třída / Skript: `zoltr_socketItem`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/zoltr_socketItem.cs`

### 1. Účel a role v projektu
Klíčový skript pro jakýkoliv předmět, který se má zapojovat do socketů (grafická karta, procesor, konektor kabelu). Spravuje přichycení (snapping), testování kompatibility se socketem, detekci vytržení uživatelem (vyžaduje překonání odporu `neededPullForceForUnsnap` vyvoláním vibračního třasu a zvuku pnutí), kontrolu závislostí (např. nelze vyndat procesor, dokud je nasazen chladič) a vykreslování holografického náhledu (ghost mesh) při přiblížení k volnému socketu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Klíčová komponenta pro zapojování. V metodě `Update` vyhodnocuje tahovou vzdálenost při pokusu o vytržení a spouští vizuální třas, zatímco v `LateUpdate` vyhlazuje pozice holografického náhledu.

**Snímání tahu a uvolnění ze socketu (`Update`):**
```csharp
private void Update()
    {
        // Check if the user is actively holding the item while it's in a socket
        if (attachedSocket != null && grabInteractable != null && grabInteractable.isSelected && currentInteractor != null)
        {
            if (neededPullForceForUnsnap <= 0f)
            {
                BreakFromSocket();
                return;
            }

            GetSnapWorldPose(attachedSocket, out Vector3 targetPos, out Quaternion targetRot);

            // Measure absolute distance between the controller and the target socket position
            float currentDistance = Vector3.Distance(currentInteractor.transform.position, targetPos);
            
            // Calculate how much further away the controller has traveled since grabbing it
            float pullDelta = currentDistance - initialPullDistance;

            if (pullDelta >= neededPullForceForUnsnap)
            {
                BreakFromSocket();
            }
            else
            {
                // Progress map from 0.0 (no pull change) to 1.0 (on the verge of snapping)
                float progress = Mathf.Clamp01(pullDelta / neededPullForceForUnsnap);
                progress *= progress;

                pullingAudioSource.volume = progress;
                pullingAudioSource.pitch = 1f + progress * 0.4f;

                // Generate random high-frequency procedural shake offsets scaling with progress
                Vector3 shakeOffset = Random.insideUnitSphere * maxShakeIntensity * progress;
                Quaternion shakeRot = Quaternion.Euler(
                    Random.Range(-1f, 1f) * maxShakeRotationIntensity * progress,
                    Random.Range(-1f, 1f) * maxShakeRotationIntensity * progress,
                    Random.Range(-1f, 1f) * maxShakeRotationIntensity * progress
                );

                // Apply target coordinates + visual tension jitter
                transform.SetPositionAndRotation(targetPos + shakeOffset, targetRot * shakeRot);
            }
        }
```

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `socket_type` | `object_id` | Typ hardwarové součástky pro určení kompatibility. |
| `snapAxis` | `SnapAxisDirection` | Směrová osa vyrovnávající součástku do patice. |
| `snapRotation` | `Vector3` | Dodatečná úhlová rotace po přichycení součástky. |
| `allowUnsnap` | `bool` | Povoluje hráči zpětné vytažení součástky ven. |
| `neededPullForceForUnsnap` | `float` | Tahová síla v metrech k vytržení. |
| `canBeSnapped` | `bool` | Povoluje opětovné zapojení součástky. |
| `dependencyRules` | `ItemDependencyRule[]` | Pravidla montážních závislostí pro vložení součástky. |
| `maxShakeIntensity` | `float` | Maximální intenzita třasu při tahání součástky. |
| `maxShakeRotationIntensity` | `float` | Maximální intenzita úhlového třasu při tahání. |
| `ghostMaterialValid` | `Material` | Zelený poloprůhledný materiál pro platný náhled. |
| `ghostMaterialInvalid` | `Material` | Červený poloprůhledný materiál pro neplatný náhled. |
| `highlightMaterial` | `Material` | Materiál zvýraznění při přiblížení ruky hráče. |
| `attachedSocket` | `zoltr_socket` | Odkaz na socket, ve kterém je. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `SnapToSocket` | `bool` | `zoltr_socket socket` | Upevní pozici součástky a její Rigidbody do patice. |
| `BreakFromSocket` | `void` | `` | Obnoví standardní fyziku Rigidbody a odpojí prvek z patice. |
| `RecalculateDependencies` | `void` | `` | Znovu prověřuje stav zapojení všech závislých součástek. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Nastavte `neededPullForceForUnsnap` na přiměřenou hodnotu (např. 0.2 metru tahu), aby nebylo vytržení příliš obtížné ani příliš snadné.
- **Vazby na ostatní prvky ve scéně:** Vyžaduje komponentu Rigidbody a collider na objektu.

========================================

<div style='page-break-before: always;'></div>

# Editor Rozšíření a Lokalizace (Assets/Scripts/Editor/ a Assets/Scripts/zoltr/Editor/)
---

## Třída / Skript: `MenuLocalizationHelper`
- **Relativní cesta k souboru:** `Assets/Scripts/Editor/MenuLocalizationHelper.cs`

### 1. Účel a role v projektu
Pomocný editorový skript pro rychlé testování a aktualizaci lokalizačních písem a řetězců přímo v Unity Editoru bez nutnosti spouštět hru.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Využívá API Unity editoru pro procházení aktivních textových polí a simulaci změn jazyka za běhu editoru.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ApplyFixes` | `void` | `` | Aplikuje okamžité aktualizace lokalizačních řetězců a písem v prvcích menu. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Skript je aktivní pouze v editoru a spouští se přes kontextové menu.
- **Vazby na ostatní prvky ve scéně:** Editorový nástroj, neprovazuje se se scénou.

========================================

## Třída / Skript: `MissingMaterialFinder`
- **Relativní cesta k souboru:** `Assets/Scripts/Tools/MissingMaterialFinder/Editor/MissingMaterialFinder.cs`

### 1. Účel a role v projektu
Editorový nástroj pro automatické vyhledání a nahrazení chybějících (růžových) materiálů ve scéně.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Prochází mesh renderery a vyhledává chybějící materiály, které následně nahradí zvoleným materiálem.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `renderer` | `Renderer` | Renderer objektu s chybějícími materiály ve scéně. |
| `materialIndex` | `int` | Index materiálu v Renderer komponentě součástky. |
| `customReplacement` | `Material` | Náhradní materiál pro opravu chybějícího zobrazení. |
| `path` | `string` | Cesta k souboru náhradního materiálu v Assets. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ShowWindow` | `void` | `` | Otevře okno editoru se seznamem chybějících materiálů. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zadejte náhradní materiál a spusťte vyhledávání.
- **Vazby na ostatní prvky ve scéně:** Užitečný nástroj pro opravu importovaných modelů.

========================================

## Třída / Skript: `PeripheralsQuizCreator`
- **Relativní cesta k souboru:** `Assets/Scripts/Editor/PeripheralsQuizCreator.cs`

### 1. Účel a role v projektu
Editorové rozšíření pro snadné vytváření a správu databáze kvízových otázek zaměřených na vnější počítačové periferie.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Vykresluje vlastní okno editoru s formulářem pro zadávání otázek a odpovědí a automaticky exportuje data do formátu JSON.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `Setup` | `void` | `` | Inicializuje a nastavuje databázi otázek kvízu o periferních zařízeních. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Spouští se z horního menu editoru v záložce Tools.
- **Vazby na ostatní prvky ve scéně:** Slouží jako autorský nástroj pro tvorbu obsahu kvízů.

========================================

## Třída / Skript: `SceneDrawer`
- **Relativní cesta k souboru:** `Assets/Scripts/Editor/SceneDrawer.cs`

### 1. Účel a role v projektu
Vlastní vykreslovač (PropertyDrawer) pro proměnné označené atributem [Scene]. Nahrazuje ruční psaní názvů scén bezpečným dropdown menu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Čte seznam scén ze souboru Build Settings a převádí jej na pole pro výběr v okně Inspector.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Automaticky nahrazuje standardní textové pole u označených proměnných.
- **Vazby na ostatní prvky ve scéně:** Používá se výhradně pro pohodlí vývojáře při návrhu scén.

========================================

## Třída / Skript: `SceneTransitionManagerEditor`
- **Relativní cesta k souboru:** `Assets/Scripts/Editor/SceneTransitionManagerEditor.cs`

### 1. Účel a role v projektu
Vlastní inspektor pro SceneTransitionManager. Přidává testovací tlačítka pro okamžité vyzkoušení stmívání a přechodů přímo v editoru.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Rozšiřuje standardní zobrazení komponenty a přidává GUI tlačítka, která za chodu hry volají metody transition manažeru.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Tlačítka se zobrazují na spodku inspektoru při vybrání manageru za běhu hry.
- **Vazby na ostatní prvky ve scéně:** Usnadňuje ladění přechodových efektů.

========================================

## Třída / Skript: `ShowDescriptionObjectEditor`
- **Relativní cesta k souboru:** `Assets/Scripts/Editor/ShowDescriptionObjectEditor.cs`

### 1. Účel a role v projektu
Vlastní editor pro ShowDescriptionObject zjednodušující správu popisků součástek.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Umožňuje přímou správu lokalizačních klíčů a vazeb na audio soubory z jednoho místa.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zpřehledňuje zadávání lokalizačních klíčů v Inspector okně.
- **Vazby na ostatní prvky ve scéně:** Určeno pro editorové konfigurace.

========================================

## Třída / Skript: `TranslationInjector`
- **Relativní cesta k souboru:** `Assets/Scripts/Editor/TranslationInjector.cs`

### 1. Účel a role v projektu
Editorový nástroj pro automatické hromadné vkládání a aktualizaci lokalizačních komponent na UI textové prvky ve scéně.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Vyhledá všechny TextMeshPro komponenty a automaticky na ně přidá skript LocalizeStringEvent se správnými klíči.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `InjectTranslations` | `void` | `` | Programově vkládá přeložené textové řetězce do aktivních textových komponent. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Spouští se jednorázově přes kontextové menu pro rychlou lokalizaci celé scény.
- **Vazby na ostatní prvky ve scéně:** Slouží k urychlení překladatelských prací v projektu.

========================================

## Třída / Skript: `ZoltrCableDynamicInteractorEditor`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/Editor/ZoltrCableDynamicInteractorEditor.cs`

### 1. Účel a role v projektu
Vlastní editor pro ZoltrCableDynamicInteractor usnadňující nastavení kolizních tvarů kabelů.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Vykresluje v okně editoru přehledné nastavení pro sféry, kapsle a boxy.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zjednodušuje konfiguraci rozměrů kolizních zón.
- **Vazby na ostatní prvky ve scéně:** Používá se pro úpravu interaktorů ovladačů.

========================================

## Třída / Skript: `zoltr_socketItemEditor`
- **Relativní cesta k souboru:** `Assets/Scripts/zoltr/Editor/zoltr_socketItemEditor.cs`

### 1. Účel a role v projektu
Vlastní editor pro zoltr_socketItem. Umožňuje přímé testování snapů a nastavení offsetů z inspektoru.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Přidává tlačítka pro uložení aktuální pozice jako snap offsetu přímo za běhu editoru.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Použije tlačítko 'Save Current Pose' pro rychlé nastavení pozice součástky.
- **Vazby na ostatní prvky ve scéně:** Významně urychluje konfiguraci socketových součástek.

========================================

<div style='page-break-before: always;'></div>

# Nástroje a Pomocné Třídy (Assets/Scripts/Tools/ a Assets/Scripts/XR/)
---

## Třída / Skript: `FindMissingScripts`
- **Relativní cesta k souboru:** `Assets/Scripts/Tools/ChatGPTMissingScripts.cs`

### 1. Účel a role v projektu
Nástroj pro vyhledání chybějících (Broken) C# skriptů na objektech v celé scéně.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Prochází všechny GameObjects a kontroluje, zda neobsahují prázdné komponenty (Missing MonoScript).

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Spustí se z menu Tools -> Find Missing Scripts.
- **Vazby na ostatní prvky ve scéně:** Usnadňuje údržbu a opravy poškozených prefabů.

========================================

## Třída / Skript: `HapticFeedbackRunner`
- **Relativní cesta k souboru:** `Assets/Scripts/Tools/HapticFeedbackRunner.cs`

### 1. Účel a role v projektu
Monobehaviour obal pro HapticFeedbackHelper, který umožňuje spouštět haptické impulsy z UnityEvents (např. při najetí na tlačítko v UI).

### 2. Jak skript funguje (Logika a vnitřní fungování)
Zprostředkovává volání HapticFeedbackHelperu přes public metodu, kterou lze propojit v inspektoru.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `StartFadingHaptic` | `void` | `object interactor, float startAmplitude, float endAmplitude, float duration, AnimationCurve curve = null` | Plynule zeslabuje amplitudu vibrací na aktivním ovladači. |
| `StartContinuous` | `void` | `int id, object interactor, float initialAmplitude, float maxDuration = -1f` | Spustí trvalou vibrační smyčku na vybraném ovladači. |
| `SetContinuousAmplitude` | `void` | `int id, float newAmplitude` | Mění intenzitu probíhající trvalé vibrační smyčky. |
| `StopContinuous` | `void` | `int id` | Zastaví probíhající trvalou vibrační smyčku. |
| `StartSequence` | `void` | `object interactor, float[] amplitudes, float[] durations, float[] gaps` | Přehrává definovanou řadu vibračních kroků a mezer. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Upravte amplitudu a trvání vibrací pro konkrétní UI tlačítko.
- **Vazby na ostatní prvky ve scéně:** Lze propojit s jakoukoliv UnityEvent událostí v UI systému.

========================================

## Třída / Skript: `HapticPattern`
- **Relativní cesta k souboru:** `Assets/Scripts/Tools/HapticFeedbackHelper.cs`

### 1. Účel a role v projektu
Reprezentuje datovou strukturu definující vibrační vzor (sekvenci kroků a pauz) pro VR ovladače.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Ukládá pole intenzit a délek vibrací, které pak přehrávač haptiky postupně posílá do ovladačů.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
*Tento skript nemá žádná veřejná pole pro konfiguraci v Inspector okně.*

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `TriggerHaptics` | `bool` | `PointerEventData eventData, float amplitude, float duration` | Odesílá vibrační impuls se zadanou silou a délkou. |
| `TriggerHaptics` | `bool` | `XRNode node, float amplitude, float duration` | Odesílá vibrační impuls se zadanou silou a délkou. |
| `TriggerHaptics` | `bool` | `InputDevice device, float amplitude, float duration` | Odesílá vibrační impuls se zadanou silou a délkou. |
| `TriggerBaseHaptics` | `bool` | `object interactorOrController, float amplitude, float duration` | Vyhledá příslušný ovladač a spustí vibrační odezvu. |
| `TriggerGlobalHaptics` | `void` | `float amplitude, float duration` | Spouští shodný vibrační impuls v obou ovladačích současně. |
| `TriggerFadingHaptics` | `void` | `PointerEventData eventData, float startAmplitude, float endAmplitude, float duration, AnimationCurve curve = null` | Spouští vibraci s plynulým slábnutím intenzity v čase. |
| `TriggerFadingHaptics` | `void` | `XRNode node, float startAmplitude, float endAmplitude, float duration, AnimationCurve curve = null` | Spouští vibraci s plynulým slábnutím intenzity v čase. |
| `StartContinuousHaptics` | `int` | `PointerEventData eventData, float amplitude, float maxDuration = -1f` | Spustí nepřetržitou vibrační smyčku na vybraném ovladači. |
| `StartContinuousHaptics` | `int` | `XRNode node, float amplitude, float maxDuration = -1f` | Spustí nepřetržitou vibrační smyčku na vybraném ovladači. |
| `SetContinuousHapticsAmplitude` | `void` | `int id, float newAmplitude` | Upravuje intenzitu běžící nepřetržité vibrační smyčky. |
| `StopContinuousHaptics` | `void` | `int id` | Zastaví běžící nepřetržitou vibrační smyčku na ovladači. |
| `TriggerHapticSequence` | `void` | `PointerEventData eventData, float[] amplitudes, float[] durations, float[] gaps = null` | Spouští sekvenci po sobě jdoucích vibrací s mezerami. |
| `TriggerHapticPattern` | `void` | `XRNode node, HapticPattern pattern` | Přehrává předdefinovaný vibrační vzor na vybraném ovladači. |
| `TriggerHapticPattern` | `void` | `PointerEventData eventData, HapticPattern pattern` | Přehrává předdefinovaný vibrační vzor na vybraném ovladači. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Můžete nakonfigurovat vlastní vzory vibrací přímo na komponentě.
- **Vazby na ostatní prvky ve scéně:** Používá se v HapticFeedbackHelperu.

========================================

## Třída / Skript: `MissingScriptWindow`
- **Relativní cesta k souboru:** `Assets/Scripts/Tools/Missing Scripts Tool/Scripts/MissingScriptWindow.cs`

### 1. Účel a role v projektu
Interaktivní okno editoru zobrazující přehledný seznam všech poškozených skriptů v projektu.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Vykresluje tabulku s cestami k chybám a umožňuje rychlý přechod na poškozený objekt kliknutím.

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `Paths` | `List<string>` | Seznam cest k chybějícím skriptům projektu. |
| `ActiveIndex` | `int` | Vybraný index v seznamu chybějících skriptů. |
| `Kind` | `SourceKind` | Typ klasifikace původu chybějícího skriptu v projektu. |
| `AssetPath` | `string` | Cesta k souboru chybějícího skriptu v Assets. |
| `ObjectPath` | `string` | Cesta k objektu s chybějícím skriptem. |
| `Key` | `string` | Unikátní klíč identifikující chybu chybějícího skriptu. |

### 4. Metody a API rozhraní
| Metoda | Návratový typ | Parametry | Popis |
|---|---|---|---|
| `ShowWindow` | `void` | `` | Otevře okno editoru se seznamem chybějících skriptů. |

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Využijte vyhledávací pole k rychlému filtrování chyb.
- **Vazby na ostatní prvky ve scéně:** Pomocný vývojářský nástroj.

========================================

<div style='page-break-before: always;'></div>

# VR Hráč a Animace Rukou (Assets/Scripts/VRPlayer/)
---

## Třída / Skript: `AnimateHandOnInput`
- **Relativní cesta k souboru:** `Assets/Scripts/VRPlayer/AnimateHandOnInput.cs`

### 1. Účel a role v projektu
Zajišťuje animaci prstů virtuální ruky (Grip a Pinch) na základě analogových vstupů z VR ovladače, což poskytuje plynulý pocit sevření pěsti nebo stisku ukazováčku.

### 2. Jak skript funguje (Logika a vnitřní fungování)
Skript čte hodnoty stisku triggerů z ovladačů. V metodě `Update` předává tyto hodnoty do parametrů Animatoru virtuální ruky pro plynulé míchání animací Grip a Pinch.

**Kompletní kód čtení vstupů a animace rukou:**
```csharp
using UnityEngine;
using UnityEngine.InputSystem;

public class AnimateHandOnInput : MonoBehaviour
{
    public InputActionProperty pinchAnimationAction;
    public InputActionProperty gripAnimationAction;
    public Animator handAnimator;

    void Update()
    {
        float pinchValue = pinchAnimationAction.action.ReadValue<float>();
        float gripValue = gripAnimationAction.action.ReadValue<float>();
        handAnimator.SetFloat("Trigger", pinchValue);
        handAnimator.SetFloat("Grip", gripValue);
    }
}
```

### 3. Vlastnosti v Unity Inspector (Konfigurace)
| Proměnná | Typ | Popis a jak ji správně nastavit v editoru |
|---|---|---|
| `pinchAnimationAction` | `InputActionProperty` | Input Action mapující trigger ovladače na pinch. |
| `gripAnimationAction` | `InputActionProperty` | Input Action mapující grip ovladače na stisk. |
| `handAnimator` | `Animator` | Komponenta Animator na modelu ruky hráče. |

### 4. Metody a API rozhraní
*Tento skript neposkytuje žádné veřejné metody pro volání z jiných objektů.*

### 5. Návod k úpravám a integraci
- **Doporučená úprava v Inspector okně:** Zkontrolujte správné propojení s Unity Input Action Assetem.
- **Vazby na ostatní prvky ve scéně:** Přiřazuje se přímo na prefab virtuální ruky s animátorem.

========================================

<div style='page-break-before: always;'></div>

# 3. Příručka Vývojáře - Návody Krok za Krokem
---

## 3.1 Jak přidat novou součástku do PC sestavování
Představme si, že chcete do hry přidat novou součástku, například **zvukovou kartu (Sound Card)**, kterou hráč musí zapojit do PCI-E slotu na základní desce:
1. **Příprava 3D Modelu**: Importujte model zvukové karty (formát FBX/OBJ) do Unity projektu. Přetáhněte model do scény a vytvořte z něj nový Prefab.
2. **Nastavení Fyziky**: Na kořenový objekt Prefabu přidejte komponentu `Rigidbody` (hmotnost cca `0.2` kg, zapnutá gravitace) a vhodný `Collider` (např. Box Collider obepínající celou kartu). Ujistěte se, že collider není Trigger.
3. **Konfigurace VR Uchopení (XRI)**: Přidejte komponentu `XRGrabInteractable`. Nastavte `Movement Type` na `Instant` nebo `Kinematic`. Vytvořte child objekt `GrabPoint` a přiřaďte jej do `Attach Transform` v XRGrabInteractable, aby hráč kartu držel za správný okraj.
4. **Příprava Identifikátoru**: Otevřete soubor [zoltr_helpers.cs](file:///C:/Users/adamk/Erasmus-2026-06-11-11-53-25/Assets/Scripts/zoltr/zoltr_helpers.cs). Do výčtu `object_id` přidejte novou položku (např. `SOUND_CARD`).
5. **Nastavení Snappingu**: Na kartu přidejte skript `zoltr_socketItem`.
   - Nastavte `socket_type` na `SOUND_CARD` (nově přidané ID).
   - Nastavte `snapAxis` (osa, podél které karta zapadne do slotu, obvykle `Forward` nebo `Down`).
   - Upravte `snapOffset` a `snapRotation` tak, aby karta v zapojeném stavu vizuálně seděla přesně ve slotu desky.
   - Zaškrtněte `allowUnsnap` na `true` a nastavte `neededPullForceForUnsnap` na `0.15` (15 centimetrů tahu rukou před vytržením).
6. **Vytvoření Socketu na Desce**: Najděte na modelu základní desky příslušný PCI-E slot. Vytvořte v něm prázdný GameObject `Socket_SoundCard`.
   - Přidejte `BoxCollider` nastavený jako **Is Trigger** obepínající prostor nad slotem.
   - Přidejte skript `zoltr_socket` a nastavte `socket_type` na `SOUND_CARD`.
7. **Definování závislostí (Dependency Rules)**: Hráč by neměl mít možnost vložit zvukovou kartu, pokud deska není přišroubovaná v case. Ve skriptu `zoltr_socketItem` zvukové karty přidejte pravidlo do seznamu `dependencyRules`:
   - Nastavte součástku základní desky jako cíl.
   - Nastavte `needsToBe` na `SnappedIn`.

## 3.2 Jak vytvořit a zapojit nový kabel
Zapojování kabelů (např. SATA kabelu ze základní desky do pevného disku) vyžaduje propojení ohebné fyziky s koncovkami typu `socketItem`:
1. **Vytvoření GameObjectu**: Vytvořte ve scéně nový prázdný GameObject `SataCable` a přidejte k němu skript `zoltr_cable`.
2. **Definice Kotevních Bodů (Konektorů)**: Vytvořte dva child objekty `ConnectorStart` a `ConnectorEnd`. Tyto objekty budou představovat fyzické plastové koncovky SATA kabelu, které hráč bere do ruky.
   - K oběma konektorům přidejte `Collider`, `Rigidbody` (Kinematic) a komponenty `XRGrabInteractable`.
   - Přidejte k nim skript `zoltr_socketItem` s typem `SATA_DATA` a nakonfigurujte jejich snap offsety.
3. **Propojení s Fyzikou Kabelu**: Ve skriptu `zoltr_cable` na hlavním objektu přetáhněte `ConnectorStart` do pole `startPoint` a `ConnectorEnd` do pole `endPoint`.
4. **Konfigurace Parametrů Fyziky**: Nastavte `cableLength` na požadovanou délku (např. `0.3`m), `segmentCount` na `10` a `substeps` na `8`. Tuhost ohybu `bendingStiffness` nastavte na `0.4` (kabel bude mírně tuhý a bude držet oblouky). Tuhost konců `anchorStiffness` nastavte na `0.8` (zajistí, že kabel bude z konektoru vycházet kolmo k jeho zadní části).
5. **Vykreslení**: Pokud máte připravenou deformovatelnou síť kabelu s kostmi (Rigged Mesh), přiřaďte kosti do seznamu `cableBones` a použijte kontextové menu -> `Set Segment Count From Rig`. Pokud kosti nemáte, nechte pole prázdné â€“ skript automaticky vygeneruje `LineRenderer` a vykreslí hladký 3D kabel matematicky.

## 3.3 Jak spravovat a rozšiřovat Kvízové otázky
Hra obsahuje 3D kvízové stojany spravované skriptem `Quiz`. Otázky jsou načítány z textových JSON souborů, což umožňuje jejich rychlou editaci:
1. **Umístění souborů**: Soubory s otázkami se nacházejí v adresáři `Assets/Content/Quizzes/` (např. `ComputerQuiz.json`).
2. **Struktura otázky**: Formát souboru musí odpovídat následující struktuře:
   ```json
   {
     "questions": [
       {
         "question": "Jaký je primární účel chladiče procesoru?",
         "answers": [
           "Odvádět teplo a předcházet přehřátí",
           "Zvyšovat rychlost operační paměti",
           "Ukládat trvalá data",
           "Napájet základní desku"
         ],
         "correctAnswerIndex": 0
       }
     ]
   }
   ```
3. **Přidání Otázky**: Jednoduše přidejte nový blok do pole `questions` v JSON souboru. Kvízový stojan otázku automaticky zařadí do hry při startu. Tlačítka odpovědí se dynamicky přizpůsobí délce textu.
4. **Dabing Vyhodnocení**: Skript `Quiz` na základě úspěšnosti (procenta správných odpovědí) přehrává dabing. Tyto audio klipy můžete vyměnit přímo na komponentě `Quiz` v Unity Inspectoru v sekci `Narrator Audio`.

## 3.4 Jak funguje a jak upravovat Lokalizační systém (Unity Localization)
Hra podporuje plnou lokalizaci uživatelského rozhraní (UI) a textů (český a anglický jazyk) pomocí oficiálního balíčku **Unity Localization**.
### Jak lokalizace funguje pod kapotou:
1. **Lokalizační tabulky (String Tables)**: Veškeré lokalizované texty jsou uloženy v tabulkách řetězců (String Tables). Výchozí tabulka v projektu se jmenuje `LocalizationTable` (nebo dle nastavení v parametru `stringTableName`). Každý řádek v tabulce má svůj **Key** (klíč, např. `quiz_score`) a překlady pro jednotlivé jazyky (Locales) â€“ české (`cs`) a anglické (`en`).
2. **Přepínání jazyků**: Výchozí jazyk se detekuje podle nastavení systému nebo je zvolen hráčem v nastavení. Kód mění aktivní Locale voláním `LocalizationSettings.SelectedLocale = locale;`.
3. **Dynamické texty (Localize String Event)**: Komponenty jako `LearningScenarioWindowLabel` nebo kvízy využívají události lokalizace. Při změně jazyka se automaticky změní texty bez nutnosti restartovat scénu.
### Návod: Jak přiradit nový překlad nebo upravit text
Chcete-li upravit stávající text (např. opravit chybu v češtině) nebo přidat nový popisek:
1. **Otevření tabulky**: V Unity Editoru otevřete okno přes horní menu: **Window -> Asset Management -> Localization Tables**.
2. **Výběr tabulky**: V dropdown menu zvolte tabulku projektu (např. `LocalizationTable`).
3. **Úprava textu**: Vyhledejte příslušný klíč (Key) v seznamu a přímo editujte text ve sloupci `Czech (cs)` nebo `English (en)`.
4. **Přidání nového klíče**: Klikněte na tlačítko **Add New Entry** ve spodní části tabulky, zadejte unikátní klíč (např. `hud_welcome_message`) a doplňte jeho český i anglický překlad.
5. **Použití v UI**: Na textový element (TextMeshPro - Text) přidejte komponentu `Localize String Event`. V sekci `String Reference` zvolte váš nově přidaný klíč. Komponenta se postará o zbytek.

*/}.toString().split('/*!')[1].split('*/')[0].trim();