﻿<center>

# TECHNICAL CODEBASE DOCUMENTATION

### Creative Hill College, ZlÃ­n

<br>
<hr style="width: 150px; border: 1px solid #2b5797; margin: auto;"/>

**Year:** 2025/2026  
*Designed for Future Developers and Students*

</center>

<div style="page-break-after: always;"></div>


<div style='page-break-before: always;'></div><br><br><br>

# 1. System Architecture & Core Mechanics
This documentation provides a comprehensive, in-depth technical reference for all custom C# scripts authored for this VR PC simulator. It is designed to act as a definitive guide for future developers taking over the project, ensuring they understand the underlying systems, component connections, editor configurations, and coding guidelines.

## 1.1 Assembly and Socket System (Zoltr)
The mechanic for assembling and disassembling computer hardware is built on interaction between `zoltr_socket` components (static slots placed in the scene, e.g., CPU sockets, PCI-E slots, SATA ports) and `zoltr_socketItem` components (grabbable objects). The flow operates as follows:
1. **Hover Detection**: The `zoltr_socketItem` utilizes trigger colliders. Upon entering a socket's trigger, it checks compatibility (`socket_type`). If it matches and all prerequisite rules (`dependencyRules`) are satisfied, the script instantiates a translucent ghost preview (`CreateGhost`) at the socket's target position.
2. **Snapping**: When the player releases the object (`selectExited`), the component transitions to a snapped state. Its Rigidbody is made Kinematic, gravity is disabled, its transform is smoothly interpolated and locked to the socket's attach transform, and the socket is marked as occupied.
3. **Pull-to-Unsnap (Tension & Detachment)**: If removing the item is allowed (`allowUnsnap`), grabbing the snapped item does not immediately detach it. Instead, the script measures the physical distance between the controller and the socket anchor (`pullDelta`). As the player pulls their hand away, the item shakes procedurally (`maxShakeIntensity`) and plays a creaking sound. If the pull exceeds `neededPullForceForUnsnap`, the item pops out, regaining physics, colliders, and gravity.

## 1.2 Advanced Cable Physics (Verlet-XPBD)
The ohebnÃ½ cable simulator (`zoltr_cable`) avoids standard Unity joints, which are notoriously unstable and prone to jitter in VR. Instead, it utilizes **Position-Based Dynamics (XPBD)**:
- **Verlet Integration**: Cable particles track current and previous positions, deriving velocity implicitly. This guarantees extreme stability under massive tension.
- **Constraint Projection**: Over several execution steps per frame (`substeps`), length and bending stiffness constraints are applied to keep particles within physical bounds.
- **Environment Collisions**: Dynamic capsule/sphere Sweep tests prevent the cable from clipping through desks, PC cases, or components.
- **Bone Deformation (Rigging)**: For cables modeled with a skeleton rig, the script in `LateUpdate` rotates and positions the bones of the skinned mesh to follow the physical simulation particles exactly, producing high-fidelity smooth deformation.

<div style='page-break-before: always;'></div>

# Core Gameplay and UI Scripts (Assets/Scripts/)
---

## Class / Script: `BobAndRotate`
- **Relative Path:** `Assets/Scripts/BobAndRotate.cs`

### 1. Purpose and Role
Ensures a smooth levitation movement of the object (up and down in a sine wave shape) and its simultaneous rotation around a chosen axis. It is primarily used for visual highlighting of collectible and important items (e.g., installation floppy disks, keys, or small components) so that the player can easily locate them in space.

### 2. Inner Workings & Implementation
The script calculates the object's new position in the `Update` method using the trigonometric function `Mathf.Sin(Time.time * bobSpeed) * bobHeight`. This value is added to the object's starting position, ensuring smooth, jitter-free periodic motion. Rotation is performed by calling `transform.Rotate` with `rotateSpeed * Time.deltaTime` around the Y-axis.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `bobHeight` | `float` | Height range of sine-wave floating motion. |
| `bobSpeed` | `float` | Speed rate of sine-wave floating animation. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Fine-tune the levitation visuals here. For small objects, it is recommended to set `bobHeight` to `0.02` (a 2 cm displacement) and `bobSpeed` to `2.0`. If you want the object to rotate only, set `bobHeight` to `0`.
- **Scene Binding:** Place the script directly on the object's model. If the object has a physical Rigidbody, ensure it is set to Kinematic, otherwise physics will conflict with the mathematical movement of this script.

========================================

## Class / Script: `CanvasAlwaysOnTop`
- **Relative Path:** `Assets/Scripts/CanvasAlwaysOnTop.cs`

### 1. Purpose and Role
Rotates a World-Space Canvas containing text or graphics so that it faces the player's eyes (camera) at all times. This billboarding effect is crucial for VR interfaces, ensuring that text floating in space remains readable from all angles and does not suffer from visual skewing or distortion.

### 2. Inner Workings & Implementation
In every frame (in `LateUpdate` or `Update`), the script finds the position of the player's camera. It calculates the direction vector from the canvas to the camera and rotates the transform using `transform.LookAt` or by directly assigning rotation via `Quaternion.LookRotation`. If the Y-axis lock is active, the rotation is restricted to the vertical axis only, preventing the canvas from tilting up and down.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ApplyAlwaysOnTop` | `void` | `` | Modifies materials and shaders to bypass the depth buffer and render on top. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `lockY` to `true` if you want the panel to rotate only left and right (suitable for standing displays). If the panel floats freely in the air, leave `lockY` disabled so it tilts when looked at from above or below.
- **Scene Binding:** Assign this script to a Canvas set to Render Mode: World Space. The script automatically finds the scene's main camera on startup.

========================================

## Class / Script: `CanvasGroupHoverFade`
- **Relative Path:** `Assets/Scripts/CanvasGroupHoverFade.cs`

### 1. Purpose and Role
Implements smooth fading in and out of UI panels (Canvas Group) based on pointer interaction (hover). When the player points the controller ray at the panel, it smoothly brightens (fade-in), and when the ray moves away, the panel fades out again.

### 2. Inner Workings & Implementation
The script implements the Unity EventSystem interfaces for detecting pointer hover entry and exit (`IPointerEnterHandler`, `IPointerExitHandler`). Based on these events, it changes the target alpha value. In the `Update` method, it linearly interpolates (`Mathf.MoveTowards` or `Mathf.Lerp`) the current `alpha` of the `CanvasGroup` toward the target value.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `fadeSpeed` | `float` | Speed rate of CanvasGroup transparency transitions. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Initiates the alpha fade-in interpolation when the XR raycast hovers over the UI. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Initiates the alpha fade-out interpolation when the XR raycast leaves the UI. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Adjust the transition speed using `fadeSpeed`. The `hoverAlpha` value determines how visible the panel is when hovered (typically `1.0` for full opacity), and `defaultAlpha` determines the idle state (`0.0` for complete invisibility).
- **Scene Binding:** Requires a `CanvasGroup` component on the same GameObject. A collider must also be present so the XR Ray Interactor can detect the pointer hover.

========================================

## Class / Script: `DynamicIconPan`
- **Relative Path:** `Assets/Scripts/DynamicIconPan.cs`

### 1. Purpose and Role
Adds a subtle parallax animation to 2D icons on UI panels. The icons react to the player's head tilt or cursor movement by shifting slightly sideways, creating a modern spatial 3D effect (parallax depth).

### 2. Inner Workings & Implementation
The script tracks the relative position of the interactor to the center of the button and shifts the internal graphic element (like an icon image) within the defined boundaries of `maxOffset` using interpolation on the RectTransform.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `rotationSpeed` | `float` | Rotation speed of the UI icon. |
| `invertDirection` | `bool` | Inverts rotation direction of UI icon. |
| `rotationOffset` | `Vector3` | Initial angle offset of the icon. |
| `maxAngleX` | `float` | Maximum horizontal rotation angle for pan. |
| `maxAngleY` | `float` | Maximum vertical rotation angle for pan. |
| `enablePositionPan` | `bool` | Enables position panning of UI icon. |
| `positionPanAmount` | `float` | Maximum offset distance for position pan. |
| `positionPanSpeed` | `float` | Speed of icon position pan movement. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `maxOffset` (in pixels) to a reasonable value (e.g., `10` to `20`) so the movement is not too erratic. `panSpeed` determines how quickly the icon returns to the center when focus is lost.
- **Scene Binding:** Placed directly on Image-type UI elements inside a Canvas.

========================================

## Class / Script: `Fan`
- **Relative Path:** `Assets/Scripts/Fan.cs`

### 1. Purpose and Role
A class simulating the rotational behavior of a cooling fan. It handles power state switching, smooth acceleration (motor spin-up), and inertial deceleration of the blades to a complete stop when power is disconnected.

### 2. Inner Workings & Implementation
In the `Update` method, the script checks the power status. If powered, the current speed increases linearly by adding `acceleration * Time.deltaTime` up to the `maxSpinSpeed` limit. If power is lost, the speed decreases by `deceleration * Time.deltaTime` down to zero. The fan blades are then rotated around the chosen `rotationAxis` by an angle corresponding to the current speed multiplied by time.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `rotorObject` | `Transform` | Transform of rotating fan blade model. |
| `rotationAxis` | `Vector3` | Local axis of fan rotor rotation. |
| `allowReverseRotation` | `bool` | Allows fan to spin backwards safely. |
| `startOnAwake` | `bool` | Starts fan rotation immediately on awake. |
| `defaultTargetSpeed` | `float` | Target rotation speed of the blades. |
| `accelerationRate` | `float` | Acceleration speed when fan starts spinning. |
| `decelerationRate` | `float` | Deceleration speed when fan is stopped. |
| `onFanStarted` | `UnityEvent` | Event fired when fan starts spinning. |
| `onFanStopped` | `UnityEvent` | Event fired when fan stops spinning. |
| `onTargetSpeedReached` | `UnityEvent` | Event fired when target speed reached. |
| `IsRunning` | `bool` | Tracks if fan is currently running. |
| `CurrentSpeed` | `float` | Current rotation speed of the fan. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `StartFan` | `void` | `` | Starts the rotor spin acceleration toward the configured target speed. |
| `StopFan` | `void` | `` | Initiates setrvaÄnÃ© deceleration of the rotor blades until they stop. |
| `ToggleFan` | `void` | `` | Toggles the power state of the fan between active spinning and stop. |
| `SetSpeed` | `void` | `float newSpeed` | Updates the target rotation velocity parameter of the rotor blades. |
| `SetSpeedMultiplier` | `void` | `float multiplier` | Scales the current spin velocity of the blades by a multiplier. |
| `ReverseDirection` | `void` | `` | Inverts the rotation axis direction of the spinning fan blades. |
| `ImmediateStop` | `void` | `` | Halts the fan rotation instantly without setrvaÄnÃ© deceleration. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Select the correct local rotation axis `rotationAxis` (usually Y or Z depending on the model's orientation). Set `maxSpinSpeed` to a high value (e.g., `1000` for a fast fan). `acceleration` and `deceleration` affect the weight and inertia of the blades.
- **Scene Binding:** Can be linked to a `zoltr_socket` via UnityEvents, so the fan starts spinning only when it is correctly seated and connected to a power supply.

========================================

## Class / Script: `FanBladesManager`
- **Relative Path:** `Assets/Scripts/FanBladesManager.cs`

### 1. Purpose and Role
A graphical utility for the fan. It provides a visual motion blur effect. At high rotation speeds, it hides the detailed blade model and displays a semi-transparent textured disc (simulating rapid rotation) to save performance and look realistic.

### 2. Inner Workings & Implementation
In every frame, the script reads the fan's current speed from the `Fan` component. If this speed exceeds `blurThreshold` (expressed as a percentage of maximum speed), the script disables the `detailedBlades` GameObject and activates the `blurredBlades` model. When the speed drops below this threshold, the reverse action is taken.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `fanBlades` | `Transform` | Transform of the physical fan blades. |
| `fanIsOn` | `bool` | Tracks power state of the fan. |
| `targetFanSpeed` | `float` | Target velocity of blade rotation model. |
| `motorAcceleration` | `float` | Rate of motor spin speed changes. |
| `usePhysics` | `bool` | Enables physics rotation for fan blades. |
| `fanRotationAxis` | `FanRotationAxis` | Selected rotation axis for fan blades. |
| `volumeMultiplier` | `float` | Volume scale of fan hum audio. |
| `pitchMultiplier` | `float` | Pitch scale of fan hum audio. |
| `inDuration` | `float` | Fade-in duration of fan motor sound. |
| `outDuration` | `float` | Fade-out duration of fan motor sound. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `FanRunning` | `void` | `bool isRunning` | Configures visual blade models based on active fan running state. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign references to both visual objects and set `blurThreshold` typically to `0.5` (50% of maximum speed).
- **Scene Binding:** Requires a direct reference to the `Fan` script instance on the same or parent object.

========================================

## Class / Script: `FractureStyle`
- **Relative Path:** `Assets/Scripts/Zoltr_BreakableObject.cs`

### 1. Purpose and Role
Defines the physical destruction style of a breakable object, determining whether the entire mesh shatters or if damage is localized to the impact point.

### 2. Inner Workings & Implementation
Acts as a dropdown setting selector inside the breakable object script to choose shard velocity calculation methods upon collision.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `unfracturedObject` | `GameObject` | GameObject representing intact unbroken mesh model. |
| `fracturedObjectRoot` | `GameObject` | GameObject root containing pre-fractured mesh pieces. |
| `impactForceThreshold` | `float` | Force limit velocity initiating object destruction. |
| `breakStyle` | `FractureStyle` | Style classification of physics destruction animation. |
| `preventChainReactions` | `bool` | Prevents breaking adjacent objects on collision. |
| `localizedBreakRadius` | `float` | Radius range of localized impact destruction. |
| `crumblePercentage` | `float` | Percentage of broken pieces converted crumble. |
| `explosionForce` | `float` | Explosive force applied to broken shards. |
| `explosionRadius` | `float` | Explosion radius range of shard physics. |
| `explosionUpwardModifier` | `float` | Upward explosion force modifier coefficient value. |
| `randomTumbleSpin` | `float` | Random rotation torque applied to shards. |
| `breakParticlePrefab` | `GameObject` | Prefab template of impact dust particles. |
| `breakSound` | `AudioClip` | Audio clip played when object shatters. |
| `startupGracePeriod` | `float` | Startup duration ignoring collision impact damage. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `HandleCollision` | `void` | `Collision collision` | Evaluates collision force velocity to check break limits. |
| `Shatter` | `void` | `Vector3 impactPoint` | Hides intact model and instantiates shattered shard pieces. |
| `TakeDamageOrForce` | `void` | `float damageAmount, Vector3 hitPoint` | Applies damage to object structural integrity limits. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Select the destruction behavior that fits your object mesh structure from the dropdown.
- **Scene Binding:** Used directly by the Zoltr_BreakableObject component.

========================================

## Class / Script: `FuturisticMenuParticles`
- **Relative Path:** `Assets/Scripts/FuturisticMenuParticles.cs`

### 1. Purpose and Role
Manages particle effects in the background of the main menu. It creates a futuristic ambient environment and reacts to the player's hands by gently pushing particles away.

### 2. Inner Workings & Implementation
The script accesses the particle array in the `ParticleSystem` and compares their positions with the positions of the VR controllers. If a particle is within `detectionRadius`, it applies an additional force vector to its movement direction, pushing it away from the controller.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `placeInFrontOfCameraOnStart` | `bool` | Positions particle system in HMD view. |
| `distanceFromCamera` | `float` | Spawn distance from VR head camera. |
| `maxParticles` | `int` | Limit of active particles in system. |
| `emissionRate` | `float` | Particles spawned per second rate value. |
| `particleLifetime` | `float` | Life duration of particles in seconds. |
| `noiseStrength` | `float` | Strength of movement turbulence noise field. |
| `noiseFrequency` | `float` | Frequency of particle turbulence noise change. |
| `noiseScrollSpeed` | `float` | Scroll speed of turbulence noise field. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Adjust `pushForce` to set the strength of the repulsion, and `detectionRadius` to define the interaction zone.
- **Scene Binding:** Requires a standard Unity `ParticleSystem` on the same object.

========================================

## Class / Script: `HandLocomotionJoystick`
- **Relative Path:** `Assets/Scripts/HandLocomotionJoystick.cs`

### 1. Purpose and Role
Detects thumbstick tilt from controllers via the Input System and applies the corresponding rotation to the 3D model of the joystick on the player's virtual hands. This achieves a 1:1 visual match with the physical movement of the player's thumb.

### 2. Inner Workings & Implementation
Reads the `Vector2` value from the registered joystick action. It maps these values (X and Y) to rotation angles around the local X and Z axes of the joystick model and applies them via `transform.localRotation`.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `handType` | `Handedness` | Specifies target left or right controller. |
| `pinchThreshold` | `float` | Pinch trigger threshold for joystick grab. |
| `maxDragDistance` | `float` | Maximum drag range of joystick handle. |
| `moveSpeed` | `float` | Locomotion speed of VR player avatar. |
| `deadzone` | `float` | Deadzone size ignoring minor joystick inputs. |
| `forwardSource` | `Transform` | Transform defining move forward vector direction. |
| `referenceFrame` | `Transform` | Reference space coordinates for movement direction. |
| `joystickVisualPrefab` | `GameObject` | Prefab for visual joystick indicator canvas. |
| `lineMaterial` | `Material` | Material used for move direction indicator. |
| `activeColor` | `Color` | Line color when moving actively. |
| `deadzoneColor` | `Color` | Line color inside joystick deadzone area. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign the Transform of the joystick model to the `joystickModel` field and define the maximum tilt angle `maxTiltAngle` (e.g., `20` degrees).
- **Scene Binding:** Connects with InputActionReferences for the left and right hands.

========================================

## Class / Script: `IntroDynamicHUD`
- **Relative Path:** `Assets/Scripts/IntroDynamicHUD.cs`

### 1. Purpose and Role
A HUD interface projected in front of the player's eyes during the game's intro sequence. It displays comfort and safety icons, and visualizes a circular progress bar for skipping the intro.

### 2. Inner Workings & Implementation
The script controls the display of warning icons and localized texts. It contains methods `ShowIcon` and `HideHUD` that smoothly change the opacity (alpha) of individual graphics based on requests from the `MainMenuIntroManager`.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `Initialize` | `void` | `MainMenuIntroManager manager, float requiredTime, float skipHudDistance, Shader ringShader, Shader iconShader, float sphereRadius` | Sets up the VR screen warning icons and radial skip progress shader. |
| `ShowIcon` | `void` | `Sprite sprite` | Renders the specified warning icon sprite on the player's HUD. |
| `FadeOutHUD` | `void` | `` | Fades out the visibility of the VR screen warning HUD panels. |
| `FadeInSkipButton` | `void` | `` | Fades in the circular skip button HUD indicator. |
| `FadeOutAndDestroy` | `void` | `` | Smoothly hides the HUD interface and destroys its GameObject. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign sprites for the Safe Space and Dizziness icons here. You can adjust the icon scale (`iconScale`) and their positional offset from the player's eyes.
- **Scene Binding:** This script is controlled by the central intro manager and spawns directly in front of the VR camera.

========================================

## Class / Script: `IntroEventType`
- **Relative Path:** `Assets/Scripts/MainMenuIntroManager.cs`

### 1. Purpose and Role
Enum and helper structure defining different event types that can occur during the main menu intro sequence (such as narrations, camera fades, or comfortable HUD toggles).

### 2. Inner Workings & Implementation
This type is used to classify and control the flow of events in MainMenuIntroManager, allowing easy branching based on event category during configuration loading.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `triggerTime` | `float` | Timestamp triggering sequential intro actions. |
| `eventType` | `IntroEventType` | Type classification of sequential intro events. |
| `scenarioIndex` | `int` | Index of scenario triggered by event. |
| `revealDuration` | `float` | Reveal animation duration of target component. |
| `alwaysPlayIntroForTesting` | `bool` | Forces intro replay during test runs. |
| `narrationSource` | `AudioSource` | AudioSource playing narrator voiceover audio clips. |
| `narrationClip` | `AudioClip` | Voiceover AudioClip file containing voice track. |
| `transitionSphere` | `Transform` | VR screen-fading black sphere transform mesh. |
| `initialSphereRadius` | `float` | Initial start radius of fade sphere. |
| `targetSphereRadius` | `float` | Target end radius of fade sphere. |
| `cinematicVolume` | `Volume` | Volume parameter of cinematic sound tracks. |
| `volumeFadeOutDuration` | `float` | Fade-out duration of cinematic audio tracks. |
| `mainMenuCanvasGroup` | `CanvasGroup` | CanvasGroup component for main menu layout. |
| `requiredHoldTime` | `float` | Required hold time to skip intro. |
| `skipHudDistance` | `float` | Distance from camera to skip HUD. |
| `skipButtonShader` | `Shader` | Shader rendering radial skip progress outline. |
| `iconOverlayShader` | `Shader` | Shader rendering warning icons over everything. |
| `safeSpaceIcon` | `Sprite` | UI Sprite representing VR safe space. |
| `dizzinessIcon` | `Sprite` | UI Sprite representing VR dizziness warning. |
| `iconDistance` | `float` | HUD warning icons rendering depth distance. |
| `iconScale` | `float` | Scale multiplier size of HUD icons. |
| `iconPositionOffset` | `Vector3` | Positional screen offset of warning icons. |
| `skipButtonScale` | `float` | Scale multiplier size of skip button. |
| `scenarioHighlights` | `GameObject[]` | Array of GameObjects highlighted during intro. |
| `manualControllerVisualsToHide` | `GameObject[]` | Visual controller models hidden during intro. |
| `OnIntroStart` | `UnityEvent` | Event triggered when intro playback begins. |
| `OnIntroEnd` | `UnityEvent` | Event triggered when intro playback finishes. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `SkipIntro` | `void` | `` | Forces the intro scene playback to end, loading the main menu. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Used within the intro events list inside the inspector to categorize actions.
- **Scene Binding:** Tightly coupled with the MainMenuIntroManager script execution.

========================================

## Class / Script: `IntroSkipButtonFollower`
- **Relative Path:** `Assets/Scripts/IntroSkipButtonFollower.cs`

### 1. Purpose and Role
Ensures that the 'Hold to Skip' indicator stays within the player's field of view at the correct height and distance, independent of head rotation.

### 2. Inner Workings & Implementation
In the `Update` method, the script tracks the position and viewing direction of the main camera. It calculates a target position in front of the camera with a defined `distance` offset. It then smoothly interpolates (`Vector3.Lerp` and `Quaternion.Slerp`) the position and rotation of the HUD panel, allowing it to move naturally and prevent motion sickness.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `distanceFromCamera` | `float` | Distance of skip button from camera. |
| `verticalOffset` | `float` | Height offset relative to HMD view. |
| `followSpeed` | `float` | Camera tracking follow speed of button. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** The recommended `distance` is `1.0` (1 meter in front of the eyes). `followSpeed` determines the movement dynamics (a value of `5` to `10` provides a pleasant feeling of inertia).
- **Scene Binding:** Placed on the Skip HUD panel GameObject.

========================================

## Class / Script: `ItemResetFromGround`
- **Relative Path:** `Assets/Scripts/ItemResetFromGround.cs`

### 1. Purpose and Role
A safety feature to prevent losing key items. If the player accidentally drops a component (CPU, RAM) and it falls through the floor collider or goes out of bounds, the script safely returns it to the workbench.

### 2. Inner Workings & Implementation
At regular intervals or in the `Update` method, the script checks the object's world Y coordinate. If this value drops below the set `killHeight`, the script immediately teleports the object to the reference `spawnPoint`, resets its Rigidbody's linear and angular velocity to zero, and optionally spawns a visual effect (like a particle burst).

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `floorTag` | `string` | Collision tag identifying floor objects. |
| `resetYPos` | `float` | Y-height threshold triggering automatic reset. |
| `resetTimerTime` | `float` | Duration item stays grounded before reset. |
| `groundCheckLength` | `float` | Raycast check length checking floor distance. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `OnDrawGizmosSelected` | `void` | `` | Draws visual Y-height boundary lines and ground check raycasts in editor. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `killHeight` below floor level (e.g., `-0.5`). Assign an empty transform located safely above the workbench as the `spawnPoint`.
- **Scene Binding:** Requires a Rigidbody component on the object.

========================================

## Class / Script: `Lapis_AudioHelper`
- **Relative Path:** `Assets/Scripts/Lapis_AudioHelper.cs`

### 1. Purpose and Role
A global auxiliary audio manager using the Singleton pattern. It provides centralized access to playing standard UI sound effects (such as button clicks, hover indicators, window closures).

### 2. Inner Workings & Implementation
The class holds a reference to its own instance `Instance`. It contains methods `PlayHoverSound` and `PlayClickSound`. These methods internally use `AudioSource.PlayClipAtPoint` or a shared AudioSource to play sounds at the player's location.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `hoverClip` | `AudioClip` | Sound clip played during button hover. |
| `clickClip` | `AudioClip` | Sound clip played on button click. |
| `transitionSwooshClip` | `AudioClip` | Audio clip played during swipe transition. |
| `transitionStinger` | `AudioClip` | Short music stinger played on transition. |
| `typeSound` | `AudioClip` | Typewriter typing sound effect clip. |
| `wipeSound` | `AudioClip` | Text erasing sound effect clip. |
| `HoverClip` | `AudioClip` | Property returning button hover audio clip. |
| `ClickClip` | `AudioClip` | Property returning button click audio clip. |
| `TransitionSwooshClip` | `AudioClip` | Property returning menu swipe audio clip. |
| `TransitionStinger` | `AudioClip` | Property returning transition music stinger clip. |
| `TypeSound` | `AudioClip` | Property returning typewriter typing audio clip. |
| `WipeSound` | `AudioClip` | Property returning text erase audio clip. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `PlayHover` | `void` | `float volume = 1f` | Plays the UI hover sound effect through the sound helper. |
| `PlayClick` | `void` | `float volume = 1f` | Plays the UI click sound effect through the sound helper. |
| `PlayTransitionSwoosh` | `void` | `float volume = 1f` | Plays the swipe sound effect during UI transitions. |
| `PlayType` | `void` | `Vector3 position, float volume = 0.4f, int priority = 250` | Plays a single typewriter key click sound at position. |
| `PlayWipe` | `void` | `Vector3 position, float volume = 0.4f` | Plays the chalkboard erase sound effect at position. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign default sound clips for Hover and Click actions.
- **Scene Binding:** Accessible from anywhere via: `Lapis_AudioHelper.Instance.PlayHoverSound()`.

========================================

## Class / Script: `LearningScenarioComponentWindow`
- **Relative Path:** `Assets/Scripts/LearningScenarioComponentWindow.cs`

### 1. Purpose and Role
A script managing an interactive holographic 3D panel with component descriptions. It displays detailed localized information about the selected hardware, including name, technical specifications, and a description of its real-world function in a PC.

### 2. Inner Workings & Implementation
The script contains the method `DisplayComponentInfo(ShowDescriptionObject info)`. It reads localization keys from the passed object and uses Unity's localization system to populate the `TextMeshProUGUI` fields on the panel, then reveals the panel (e.g., by enabling it or smoothly scaling it up).

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `scenario` | `LearningScenarioStart` | Parent learning scenario manager script reference. |
| `componentId` | `string` | Hardware ID of the displayed hardware. |
| `componentRoot` | `Transform` | Root transform of component visual mesh. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `SelectComponent` | `void` | `` | Triggers inspection and detail display of the assigned hardware component. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Verify the assignment of TextMeshPro text components for name, specs, and description.
- **Scene Binding:** Called by the global `ShowDescriptionObjectManager` whenever any described object is grabbed.

========================================

## Class / Script: `LearningScenarioStart`
- **Relative Path:** `Assets/Scripts/LearningScenarioStart.cs`

### 1. Purpose and Role
Initialization script for learning scenarios. It starts a specific task (e.g., PC disassembly), resets the state, and activates the required objects in the classroom scene.

### 2. Inner Workings & Implementation
When activated (e.g., by pressing a button at the start of a scenario), the script iterates through the `spawnObjects` array and enables them. It may also send a message to the `zoltr_buildProgress` system to start tracking assembly progress.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `id` | `string` | Unique string ID of this scenario. |
| `componentRoot` | `Transform` | Root transform containing all PC components. |
| `libraryWindowRoot` | `Transform` | Parent transform for spawned description windows. |
| `libraryAnchor` | `Transform` | Anchor transform centering info windows arc. |
| `startButton` | `Button` | Button UI trigger starting active scenario. |
| `backButton` | `Button` | Button UI trigger exiting active scenario. |
| `pcCaseDoor` | `OpenComponentVR` | Inspect script controlling computer case door. |
| `pcCaseDoorObject` | `Transform` | Transform of the case door model. |
| `playerHead` | `Transform` | Transform tracking player VR head position. |
| `inspectAnchor` | `Transform` | Target transform position close to player. |
| `animateCaseDoorFlyAway` | `bool` | Enables door fly animation on start. |
| `caseDoorFlyDuration` | `float` | Duration of case door fly animation. |
| `caseDoorFlyDistance` | `float` | Distance the case door flies away. |
| `caseDoorFlyUpOffset` | `float` | Upward offset during door fly animation. |
| `caseDoorFlyRotateDegrees` | `float` | Rotation angle during door fly animation. |
| `hideCaseDoorAfterFly` | `bool` | Hides door object after fly animation. |
| `autoGenerateWindows` | `bool` | Enables automatic generation of UI windows. |
| `windowPrefab` | `GameObject` | Prefab template for hardware description window. |
| `windowParent` | `Transform` | Parent transform organizing generated info windows. |
| `placeholderWindowDepth` | `float` | Depth offset distance for description windows. |
| `autoGenerateArcLayout` | `bool` | Arranges generated windows in radial arc. |
| `libraryRadius` | `float` | Placement arc radius of description windows. |
| `libraryArcDegrees` | `float` | Spread angle of windows placement arc. |
| `libraryHeightOffset` | `float` | Height offset of windows placement arc. |
| `libraryCenterOverride` | `Transform` | Override center transform of placement arc. |
| `libraryForwardOffset` | `float` | Forward offset distance of placement arc. |
| `minimumLibraryY` | `float` | Minimum height allowed for generated windows. |
| `autoGenerateRevealAnchors` | `bool` | Enables automatic generation of reveal points. |
| `revealDistanceFromCase` | `float` | Reveal spawn distance from PC case. |
| `revealHeightFromCase` | `float` | Reveal spawn height above PC case. |
| `revealArcDegrees` | `float` | Radial spread angle for revealed components. |
| `caseOpenLeadTime` | `float` | Delay before case door opens automatically. |
| `moveDuration` | `float` | Duration of component translation motion animations. |
| `introStagger` | `float` | Stagger delay between sequential component reveals. |
| `libraryStagger` | `float` | Stagger delay between window generation steps. |
| `animateIntroInParallel` | `bool` | Animates all components in parallel timing. |
| `animateAdditionalInParallel` | `bool` | Animates additional decorations in parallel timing. |
| `inspectEnterDuration` | `float` | Duration of component moving to player. |
| `inspectExitDuration` | `float` | Duration of component returning to slot. |
| `hiddenScaleMultiplier` | `float` | Scale multiplier for hidden inactive windows. |
| `moveAwayDistance` | `float` | Slide distance of other components during inspect. |
| `moveAwayUpOffset` | `float` | Upward offset when other components slide away. |
| `moveHiddenItemsForward` | `bool` | Pushes hidden items forward on start. |
| `hiddenItemsForwardDistance` | `float` | Forward slide distance of hidden items. |
| `hiddenItemsForwardSpread` | `float` | Lateral spread range of hidden items. |
| `inspectScaleMultiplier` | `float` | Scale size multiplier under active inspection. |
| `disablePlayerMovementInScene` | `bool` | Blocks player VR movement during animations. |
| `CurrentState` | `ScenarioState` | Property returning current active tutorial state. |
| `position` | `Vector3` | Property returning default hardware transform position. |
| `rotation` | `Quaternion` | Property returning default hardware transform rotation. |
| `localScale` | `Vector3` | Property returning default hardware local scale. |
| `position` | `Vector3` | Property returning default hardware transform position. |
| `rotation` | `Quaternion` | Property returning default hardware transform rotation. |
| `active` | `bool` | Property returning active step tutorial status. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `StartScenario` | `void` | `` | Begins the active learning scenario, initiating opening animations and window layout. |
| `SelectComponentById` | `void` | `string componentId` | Triggers inspection of a component using its hardware string ID. |
| `SelectComponent` | `void` | `Transform componentRoot` | Enters inspect mode for the specified component transform. |
| `SelectFromWindow` | `void` | `Transform windowRoot` | Triggers component inspection when selected from a floating info window. |
| `ExitInspectMode` | `void` | `` | Closes detail inspection, returning the component to its default slot. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Enter the scenario name `scenarioName` and add all objects that should appear on startup to the `spawnObjects` list.
- **Scene Binding:** Connected to interactive buttons in the classroom.

========================================

## Class / Script: `LearningScenarioWindowLabel`
- **Relative Path:** `Assets/Scripts/LearningScenarioWindowLabel.cs`

### 1. Purpose and Role
Ensures dynamic localization of static text labels (such as headers like 'Specifications:' or 'Function:') on the holographic panel.

### 2. Inner Workings & Implementation
Listens for language change events in Unity Localization and automatically updates the assigned texts based on keys from the localization table.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `labelText` | `string` | TextMeshPro component showing main window title. |
| `subtitleText` | `string` | TextMeshPro component showing window subtitle text. |
| `textHeight` | `float` | Height dimension of text UI canvas. |
| `fontSize` | `int` | Font size value of main text. |
| `textColor` | `Color` | Color parameter applied to text characters. |
| `billboardToPlayer` | `bool` | Rotates label to face player camera. |
| `yawOnly` | `bool` | Locks label billboard rotation on Y-axis. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Enter the exact name of the localization table in the `localizedTable` field.
- **Scene Binding:** Placed on text objects inside the holographic panel.

========================================

## Class / Script: `Menu`
- **Relative Path:** `Assets/Scripts/Menu.cs`

### 1. Purpose and Role
Handles navigation and logic for the main menu in the classroom. Allows the player to start a scenario, open settings, or exit the game safely.

### 2. Inner Workings & Implementation
Contains methods like `PlayGame()`, `OpenSettings()`, and `QuitGame()` that react to UI button clicks. Uses asynchronous loading with screen fades when starting the game.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `cardName` | `string` | Identifier tag of menu item card. |
| `canvasGroup` | `CanvasGroup` | CanvasGroup managing transition fades of card. |
| `panel` | `RectTransform` | GameObject wrapper of this menu card. |
| `targetScene` | `string` | Scene name string loaded by card. |
| `cardName` | `string` | Identifier tag of menu item card. |
| `canvasGroup` | `CanvasGroup` | CanvasGroup managing transition fades of card. |
| `panel` | `RectTransform` | GameObject wrapper of this menu card. |
| `subCards` | `SubCardConfig[]` | Sub-menu cards array inside this category. |
| `returnButtonCanvasGroup` | `CanvasGroup` | CanvasGroup of the back navigation button. |
| `returnButtonPanel` | `RectTransform` | GameObject of the back button panel. |
| `mainCards` | `MainCardConfig[]` | Root level menu cards array lists. |
| `ambientLight` | `Light` | Light source changing color on transition. |
| `transitionBurstParticles` | `ParticleSystem` | Particles burst played when clicking buttons. |
| `ambientTransitionSpeed` | `float` | Color transition speed of ambient lights. |
| `waveStaggerDelay` | `float` | Stagger delay between sibling buttons fading. |
| `individualFadeDuration` | `float` | Fading animation duration of single button. |
| `hoverTranslationY` | `float` | Horizontal/vertical hover offset of the card. |
| `hoverScale` | `float` | Scale multiplier value on hover state. |
| `pressScale` | `float` | Scale multiplier value on click state. |
| `smoothSpeed` | `float` | Smooth motion interpolation speed of UI. |
| `hoverClip` | `AudioClip` | Audio clip played when hovering over menu. |
| `clickClip` | `AudioClip` | Audio clip played when clicking menu button. |
| `transitionSwooshClip` | `AudioClip` | Audio clip played during menu swipe transitions. |
| `hapticDuration` | `float` | Haptic vibration duration of menu button click. |
| `IsTransitioning` | `bool` | Property checking if screen transition active. |
| `OnClickAction` | `Action<PointerEventData>` | Property callback triggered on card selection. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `SetHoveredPanel` | `void` | `VRPanelController panel` | Registers the specified UI panel controller as actively hovered. |
| `ClearHoveredPanel` | `void` | `VRPanelController panel` | Deregisters the specified UI panel controller when focus is lost. |
| `IsAnyPanelFocused` | `bool` | `` | Checks if any UI panel currently has focus. |
| `PlaySound` | `void` | `AudioClip clip` | Plays the specified UI sound clip through the local AudioSource. |
| `TriggerHapticFeedback` | `void` | `PointerEventData eventData, float amplitude, float duration` | Triggers a controller vibration impulse matching standard UI interactions. |
| `TriggerClickHapticFeedback` | `void` | `PointerEventData eventData` | Triggers a strong click vibration impulse on the active controller. |
| `Initialize` | `void` | `Menu manager, RectTransform rt` | Sets up base parameters and dimensions of the menu component. |
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Initiates hover transitions and triggers haptics when raycast enters element. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Resets visual state to idle when raycast leaves element. |
| `ForceHoverState` | `void` | `bool state` | Overrides and locks the visual hover state of the element. |
| `ResetAlpha` | `void` | `float alpha` | Resets the transparency value of the menu canvas group. |
| `OnPointerDown` | `void` | `PointerEventData eventData` | Applies scale adjustments and click triggers when pointer is pressed. |
| `OnPointerUp` | `void` | `PointerEventData eventData` | Restores visual hover scale when pointer is released. |
| `OnPointerClick` | `void` | `PointerEventData eventData` | Fires click event actions and plays transition sounds. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Enter the scene name to load when starting the game in `startSceneName` and assign the menu and settings panel objects.
- **Scene Binding:** Connected to UI buttons via UnityEvents.

========================================

## Class / Script: `OpenComponentVR`
- **Relative Path:** `Assets/Scripts/OpenComponentVR.cs`

### 1. Purpose and Role
Triggers the holographic description of a component during VR interaction (e.g., pointing with the ray and pulling the trigger).

### 2. Inner Workings & Implementation
Implements standard Unity XRI interaction interfaces. Upon interaction detection, it passes a reference of its `ShowDescriptionObject` to the global label manager, which updates and displays the 3D panel.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `pivot` | `Transform` | Pivot transform used for visual rotation. |
| `targetRotation` | `Vector3` | Target rotation applied during detail examination. |
| `duration` | `float` | Duration of visual opening inspect animation. |
| `axis` | `Axis` | Rotation axis vector for component inspection. |
| `animateOnStart` | `bool` | Rotates component automatically on game start. |
| `dismantled` | `bool` | Property tracking if component is removed. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ToggleOpen` | `void` | `` | Toggles the component rotation between closed slot and open inspection states. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Ensure `descriptionObject` is assigned and points to the description for this component.
- **Scene Binding:** Placed on interactive PC components.

========================================

## Class / Script: `OpenSettingsOnB`
- **Relative Path:** `Assets/Scripts/OpenSettingsOnB.cs`

### 1. Purpose and Role
A VR listener that allows the player to open the settings panel in front of them at any time by pressing a dedicated controller button (typically B on the right controller or Y on the left).

### 2. Inner Workings & Implementation
Monitors the state of the registered Input Action. When pressed, it checks if the settings panel is active. If not, it enables it, calculates a position exactly `spawnDistance` in front of the player's head, and rotates the panel toward their eyes. Pressing it again hides the panel.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `settingsSceneName` | `string` | Scene name string containing settings interface. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `spawnDistance` to a comfortable distance (recommended `0.8` to `1.2` meters). Assign the settings canvas GameObject to `settingsCanvas`.
- **Scene Binding:** Register the input action for the menu button (e.g., `XRI RightHand/Input/menu` or secondaryButton).

========================================

## Class / Script: `Quiz`
- **Relative Path:** `Assets/Scripts/Quiz.cs`

### 1. Purpose and Role
The complex brain of the interactive 3D quiz stands. It manages the entire quiz flow: asynchronously loads questions from a JSON file based on the selected topic, shuffles and generates random answer options on buttons, visually indicates correct/incorrect choices with checkmarks/crosses and button color changes, runs a typewriter effect for the question text, and at the end of the quiz, animates a circular success chart while playing the corresponding narrator evaluation audio.

### 2. Inner Workings & Implementation
Loads the JSON question file and populates internal structures. For displaying questions, it starts a Coroutine for the typewriter effect. When a button is clicked, it checks the selected answer index against the correct index, shows checkmarks/crosses, and enables the 'Next' button. At the end of the quiz, it calculates success percentage, runs a circular graph fill Coroutine via interpolation, and plays narrator voiceovers corresponding to excellent, good, average, or poor performance.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `selectedTopic` | `QuizTopic` | Currently active topic index of quiz. |
| `computerQuestionFile` | `TextAsset` | JSON question data asset for hardware. |
| `peripheralsQuestionFile` | `TextAsset` | JSON question data asset for peripherals. |
| `stringTableName` | `string` | String table name of localization keys. |
| `questionText` | `TextMeshProUGUI` | TextMeshPro showing current question string text. |
| `answerButtons` | `Button[]` | UI Buttons array showing answer selections. |
| `answer1CanvasGroup` | `CanvasGroup` | CanvasGroup of button option panel one. |
| `answer2CanvasGroup` | `CanvasGroup` | CanvasGroup of button option panel two. |
| `answer3CanvasGroup` | `CanvasGroup` | CanvasGroup of button option panel three. |
| `answer4CanvasGroup` | `CanvasGroup` | CanvasGroup of button option panel four. |
| `feedbackText` | `TextMeshProUGUI` | TextMeshPro presenting immediate answer feedback. |
| `coloredFeedbackText` | `TextMeshProUGUI` | Colored TextMeshPro showing option check details. |
| `scoreText` | `TextMeshProUGUI` | TextMeshPro showing final calculated quiz score. |
| `restartButton` | `Button` | Button UI trigger resetting active quiz. |
| `nextButton` | `Button` | Button UI trigger loading next question. |
| `correctAnswerIcons` | `GameObject[]` | Icons array enabled for correct selections. |
| `wrongAnswerIcons` | `GameObject[]` | Icons array enabled for incorrect selections. |
| `circleSize` | `float` | Size scale radius of result chart. |
| `fillAnimationDuration` | `float` | Duration of circular result chart animation. |
| `waveStaggerDelay` | `float` | Stagger delay animating sibling menu buttons. |
| `individualFadeDuration` | `float` | Fading duration of single menu button. |
| `typewriterSpeed` | `float` | Typing delay seconds per character value. |
| `highPerformanceAudio` | `AudioClip` | Narrator voiceover clip for excellent score. |
| `goodPerformanceAudio` | `AudioClip` | Narrator voiceover clip for good score. |
| `moderatePerformanceAudio` | `AudioClip` | Narrator voiceover clip for average score. |
| `lowPerformanceAudio` | `AudioClip` | Narrator voiceover clip for poor score. |
| `audioFadeOutDuration` | `float` | Audio fadeout duration after result review. |
| `questions` | `List<QuizQuestion>` | Property returning active quiz questions list. |
| `questionKey` | `string` | Property string localization key of question. |
| `answerKeys` | `List<string>` | Property list localization keys of answers. |
| `correctAnswerIndex` | `int` | Property index value of correct option. |
| `hoverScale` | `float` | Scale size multiplier during button hover. |
| `pressScale` | `float` | Scale size multiplier during button press. |
| `smoothSpeed` | `float` | Smooth interpolation speed for UI animations. |
| `hoverHapticAmplitude` | `float` | Haptic vibration strength during button hover. |
| `clickHapticAmplitude` | `float` | Haptic vibration strength during button click. |
| `hapticDuration` | `float` | Duration of haptic vibration in seconds. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ShowNextQuestion` | `void` | `` | Loads and fades in the next quiz question from database. |
| `RestartQuiz` | `void` | `` | Resets score tracker and reloads first question of active topic. |
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Triggers hover highlights and haptic ticks on quiz buttons. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Clears hover highlights on quiz buttons. |
| `OnPointerDown` | `void` | `PointerEventData eventData` | Triggers button scale down and click haptics. |
| `OnPointerUp` | `void` | `PointerEventData eventData` | Restores quiz button scale when pointer released. |
| `OnPointerClick` | `void` | `PointerEventData eventData` | Submits selected answer index for verification. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign JSON question files to `computerQuestionFile`, `cablesQuestionFile`, and `peripheralsQuestionFile`. Connect text components and buttons. Assign narrator evaluation audio clips to their respective fields.
- **Scene Binding:** Communicates with Unity Localization to support English and Czech interfaces.

========================================

## Class / Script: `SceneAttribute`
- **Relative Path:** `Assets/Scripts/SceneAttribute.cs`

### 1. Purpose and Role
A helper editor PropertyAttribute that simplifies entering scene names in the Unity Inspector for developers, preventing typos that could lead to scene loading crashes.

### 2. Inner Workings & Implementation
Marks string variables in code. A Custom Property Drawer (in the Editor folder) detects this and draws a dropdown in the Inspector containing all scenes added to Build Settings.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Used in code as: `[Scene] public string targetScene;`.
- **Scene Binding:** Has no runtime overhead; works only inside the Unity Editor.

========================================

## Class / Script: `SceneTransitionManager`
- **Relative Path:** `Assets/Scripts/SceneTransitionManager.cs`

### 1. Purpose and Role
A global scene transition manager designed specifically for VR. It prevents motion sickness during scene loads by smoothly fading the screen to black (fade out), asynchronously loading the scene in the background, and fading back in once loaded.

### 2. Inner Workings & Implementation
Implements the Singleton pattern. Uses a Coroutine for asynchronous scene loading via `SceneManager.LoadSceneAsync`. During transitions, it renders a black quad `fadeMaterial` directly in front of the player's eyes (or changes camera fade intensity).

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `fadeDuration` | `float` | Duration of screen fade transition animation. |
| `fadeColor` | `Color` | Target color of transition screen overlay. |
| `use3DFade` | `bool` | Enables 3D sphere fade in VR. |
| `force3DFadeInXR` | `bool` | Forces 3D sphere fade inside XR. |
| `forceFadeLayerToRenderedCamera` | `bool` | Binds fading rendering layer to HMD. |
| `transitionCanvas` | `Canvas` | Canvas screen used for 2D transitions. |
| `fadeGroup` | `CanvasGroup` | CanvasGroup component managing UI fading animation. |
| `fadeImage` | `Image` | UI Image filling transition overlay screen. |
| `loadingContainer` | `GameObject` | GameObject wrapper for loading UI panels. |
| `progressBar` | `Image` | UI Image component representing progress slider. |
| `loadingText` | `TextMeshProUGUI` | TextMeshPro showing loading percentage string text. |
| `driveAudioTransition` | `bool` | Enables volume fading during scene loading. |
| `useAdvancedMusicTransition` | `bool` | Enables advanced crossfades of music tracks. |
| `transitionStinger` | `AudioClip` | Audio stinger clip played on transitions. |
| `useGlobalAudioFadeFallback` | `bool` | Enables global fallback fadeout for audio. |
| `globalAudioFadeSpeed` | `float` | Speed coefficient of global volume fade. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `LoadSceneSmooth` | `void` | `string sceneName, bool useBackgroundLoading = true` | Initiates VR camera black fadeout and loads scene asynchronously. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Ensure `fadeMaterial` uses a shader supporting transparency and pure black. Set `defaultFadeDuration` (e.g., `1.0`s).
- **Scene Binding:** Persistent across scenes (`DontDestroyOnLoad`). Called via: `SceneTransitionManager.Instance.LoadSceneSmooth(sceneName)`.

========================================

## Class / Script: `Settings`
- **Relative Path:** `Assets/Scripts/Settings.cs`

### 1. Purpose and Role
Manages user settings. Connects UI sliders to audio volume and haptics, saving choices to persistent storage.

### 2. Inner Workings & Implementation
When a UI slider is adjusted, the script converts the slider value to a logarithmic scale (suitable for decibels in the Audio Mixer) and sets the parameter. For haptics, it saves a float value for vibration strength. All values are saved in `PlayerPrefs` under unique keys.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `languageButtonText` | `TextMeshProUGUI` | TextMeshPro label showing active language name. |
| `stringTableName` | `string` | String table name containing settings translations. |
| `languageButtonKey` | `string` | Localization key for language switch label. |
| `languageButtonFallback` | `string` | Fallback language string label if empty. |
| `controlsObjectToShow` | `GameObject` | Help panel object shown to player. |
| `settingsObjectToHide` | `GameObject` | Settings menu object hidden on help. |
| `controlsImage` | `Image` | Image component showing control layouts overlay. |
| `controlsSprite` | `Sprite` | Sprite asset representing controller mappings visual. |
| `hideControlsOnStart` | `bool` | Hides controls help panel on start. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ChangeScene` | `void` | `string sceneName` | Triggers SceneTransitionManager to load a new scene. |
| `ChangeLanguage` | `void` | `string languageCode` | Updates active localization language using locale string code. |
| `ChangeToNextLanguage` | `void` | `` | Cycles to next available localization language locale. |
| `ShowControlsPng` | `void` | `` | Fades in UI panel displaying controller layout helper. |
| `HideControlsPng` | `void` | `` | Fades out UI panel displaying controller layout helper. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Connect sliders for music, voice, and vibration. Check that Audio Mixer parameter names match strings in the code exactly.
- **Scene Binding:** Loads saved settings immediately upon game startup.

========================================

## Class / Script: `ShatteringGlass`
- **Relative Path:** `Assets/Scripts/ShatteringGlass.cs`

### 1. Purpose and Role
Handles the physical breaking of glass. Replaces a static glass mesh with a fractured prefab upon receiving a strong collision.

### 2. Inner Workings & Implementation
Detects collision force in `OnCollisionEnter`. Hides the original mesh and instantiates `brokenPrefab` at its position. The prefab contains small shards with Rigidbodies and colliders that fall under gravity.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `shatteringGlassObject` | `GameObject` | Intact unbroken glass GameObject mesh reference. |
| `shatteringLimit` | `float` | Collision force threshold triggering glass shatter. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign the unbroken glass mesh `glassMesh` and the fractured shard prefab `brokenPrefab`.
- **Scene Binding:** Requires a collider configured for collision detection.

========================================

## Class / Script: `ShowDescriptionObject`
- **Relative Path:** `Assets/Scripts/ShowDescriptionObject.cs`

### 1. Purpose and Role
A simple data container storing localization keys for a specific PC component's description. Every component has this script so the game knows what text to display on the holographic panel.

### 2. Inner Workings & Implementation
Contains no runtime logic; stores localization keys (strings) read by `LearningScenarioComponentWindow`.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `objectName` | `string` | Unique string name of target component. |
| `description` | `string` | Localization key string for description text. |
| `objectImage` | `Material` | Material displaying component preview image sprite. |
| `dubbingClip` | `AudioClip` | Narrator voiceover AudioClip file for description. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ShowObjectDescription` | `void` | `` | Triggers holographic info window creation for hovered hardware component. |
| `ShowObjectDescription` | `void` | `UnityEngine.XR.Interaction.Toolkit.SelectEnterEventArgs args` | Triggers holographic info window creation for hovered hardware component. |
| `HideObjectDescription` | `void` | `` | Hides holographic info window for hovered hardware component. |
| `HideObjectDescription` | `void` | `UnityEngine.XR.Interaction.Toolkit.SelectExitEventArgs args` | Hides holographic info window for hovered hardware component. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Enter localization table keys for component name (`componentNameKey`), specs (`specsKey`), and description (`descriptionKey`).
- **Scene Binding:** Placed on every assembleable PC component.

========================================

## Class / Script: `ShowDescriptionObjectManager`
- **Relative Path:** `Assets/Scripts/ShowDescriptionObjectManager.cs`

### 1. Purpose and Role
Global manager for description holograms. Detects when a player grabs a component and activates the corresponding 3D description panel.

### 2. Inner Workings & Implementation
Listens for hover/grab events (`selectEntered`) on all `XRGrabInteractable` objects. When grabbed, reads the object's `ShowDescriptionObject` and passes it to the UI panel.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `nameText` | `TMP_Text` | TextMeshPro rendering active component name title. |
| `descriptionText` | `TMP_Text` | TextMeshPro rendering detailed description texts body. |
| `soundManager` | `SoundManager` | Sound manager reference governing background tracks. |
| `audioSource` | `AudioSource` | AudioSource playing typewriter sound effects clips. |
| `typeSound` | `AudioClip` | AudioClip of active typewriter typing effect. |
| `wipeSound` | `AudioClip` | AudioClip of text erasing chalkboard sound. |
| `stringTableName` | `string` | Name string of active localization table. |
| `currentlyShowObject` | `ShowDescriptionObject` | Active description dataset object under inspection. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `TurnOnObject` | `void` | `UnityEngine.Object objRef` | Enables visibility of target holographic window panels. |
| `TurnOffObject` | `void` | `UnityEngine.Object objRef` | Disables visibility of target holographic window panels. |
| `StopFadingSources` | `void` | `` | Stops active audio fade-out coroutines on audio sources. |
| `SwitchToObject` | `IEnumerator` | `ShowDescriptionObject obj` | Smoothly switches visible description panels using typewriter animations. |
| `PrintAllLocalizationKeys` | `void` | `` | Utility method outputting all database keys to console. |
| `StartWriteAnimation` | `IEnumerator` | `` | Initiates typewriter writing sound and letters reveal animations. |
| `AutoPopulateLocalizationTables` | `void` | `` | Utility script populating empty localization string rows automatically. |
| `RemoveAutoGeneratedLocalizations` | `void` | `` | Utility script clearing auto generated localization rows. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign a reference to the `displayPanel`.
- **Scene Binding:** Integrated with the XR Interaction Manager.

========================================

## Class / Script: `SnapGrabInteractable`
- **Relative Path:** `Assets/Scripts/SnapGrabInteractable.cs`

### 1. Purpose and Role
An extended version of Unity XRI's grab interactable. It allows precise alignment of held objects (fans, RAM, screws) to predefined SnapPoints upon release. Additionally, it supports a screwing mechanic â€“ players can rotate the object after snapping using a circular hand motion, simulating tightening a screw.

### 2. Inner Workings & Implementation
When released (`OnSelectExited`), the script checks all free `SnapPoint` objects in the scene. If any is within `snapDistance`, it starts a smooth interpolation toward it (`UpdateSmoothSnap`) and sets the Rigidbody to kinematic. If screwing is enabled, the script tracks the controller's circular movement around the screw axis and rotates the mesh accordingly.

**Core Screwing Logic (`UpdateScrewingRotation`):**
```csharp
void UpdateScrewingRotation()
    {
        if (interactorsSelecting.Count == 0 || currentSnapPoint == null) return;

        var grabber = interactorsSelecting[0];
        if (grabber == null || grabber.transform == null) return;

        Vector3 currentControllerPos = grabber.transform.position;

        if (!trackingControllerForScrewing)
        {
            // Start tracking
            lastControllerPosition = currentControllerPos;
            trackingControllerForScrewing = true;
            return;
        }

        // Calculate controller movement
        Vector3 controllerMovement = currentControllerPos - lastControllerPosition;
        lastControllerPosition = currentControllerPos;

        // Get the snap point position and determine the rotation axis
        Transform snapTransform = currentSnapPoint.attachTransform != null 
            ? currentSnapPoint.attachTransform 
            : currentSnapPoint.transform;

        Vector3 snapPos = snapTransform.position;
        Vector3 rotationAxis = GetScrewingAxis(snapTransform);

        // Project controller movement onto a plane perpendicular to the rotation axis
        Vector3 movementOnPlane = Vector3.ProjectOnPlane(controllerMovement, rotationAxis);

        // Calculate rotation around the axis based on circular movement
        if (movementOnPlane.magnitude > 0.001f)
        {
            // Get vector from snap point to controller
            Vector3 toController = currentControllerPos - snapPos;
            Vector3 toControllerOnPlane = Vector3.ProjectOnPlane(toController, rotationAxis);

            // Calculate the angular movement using cross product
            Vector3 cross = Vector3.Cross(toControllerOnPlane.normalized, movementOnPlane);
            float rotationAmount = Vector3.Dot(cross, rotationAxis) * screwingSensitivity;

            // Apply rotation around the chosen axis while keeping position locked
            Vector3 currentPos = transform.position;
            transform.RotateAround(snapPos, rotationAxis, rotationAmount * Mathf.Rad2Deg);
            
            // Lock position back to where it should be (in case RotateAround moved it slightly)
            if (objectAttachTransform != null)
            {
                Vector3 currentOffset = objectAttachTransform.position - transform.position;
                transform.position = snapPos - currentOffset;
            }
        }
    }
```

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `snapPoints` | `SnapPoint[]` | Compatible snap points inside scene environment. |
| `snapDistance` | `float` | Threshold distance initiating snap lock interpolation. |
| `objectAttachTransform` | `Transform` | Local attach point transform offset coordinates. |
| `parentOnSnap` | `bool` | Parents component transform to target socket. |
| `snapPointTag` | `string` | Collision tag filter identifying valid sockets. |
| `snapSpeed` | `float` | Interpolation speed of snap alignment motion. |
| `unsnapDistanceMultiplier` | `float` | Distance threshold multiplier initiating user unsnap. |
| `allowScrewingRotation` | `bool` | Enables manual screwing rotation of component. |
| `screwingSensitivity` | `float` | Sensitivity of hand rotation to screw. |
| `screwingAxis` | `ScrewingAxis` | Local axis used for manual screwing. |
| `IsSnapped` | `bool` | Property checking if component snapped currently. |
| `CurrentSnapPoint` | `SnapPoint` | Property returning active snapped socket point. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ForceUnsnap` | `void` | `` | Instantly detaches component from socket, restoring full physics. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `snapDistance` (e.g., `0.1`m). Check `allowScrewingRotation` for screws and choose the correct rotation axis `screwingAxis`.
- **Scene Binding:** Requires a `SnapPoint` in the scene.

========================================

## Class / Script: `SnapPoint`
- **Relative Path:** `Assets/Scripts/SnapPoint.cs`

### 1. Purpose and Role
Represents a target coordinate and orientation in 3D space where a `SnapGrabInteractable` can snap. Displays a green Gizmo in the editor for easy placement.

### 2. Inner Workings & Implementation
The script acts as a passive data container and spatial anchor. At runtime, it maintains the occupancy state (`occupied`), and in the Unity Editor, it renders a colored wireframe box using the `OnDrawGizmos` method to facilitate precise spatial alignment.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `attachTransform` | `Transform` | Attach transform anchor for snapped items. |
| `occupied` | `bool` | Property checking if socket point occupied. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Place the SnapPoint exactly where the component should sit (e.g., screw holes).
- **Scene Binding:** Tracks whether it is occupied (`occupied`).

========================================

## Class / Script: `SoundManager`
- **Relative Path:** `Assets/Scripts/SoundManager.cs`

### 1. Purpose and Role
Central sound manager for the game. Handles playing background ambient music and spatialized 3D audio for world interactions.

### 2. Inner Workings & Implementation
The script implements the Singleton pattern and manages a pool of 3D audio sources. During `Awake`, it initializes the background music, and when `PlaySFX` is called, it dynamically assigns free audio sources from the pool to play spatialized effects at specific coordinates.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `sceneName` | `string` | String name identifier of classroom scene. |
| `bgm` | `AudioClip` | Audio clip of background ambient tracks. |
| `minDistance` | `float` | Minimum radius range for spatial audio. |
| `maxDistance` | `float` | Maximum radius range for spatial audio. |
| `loop` | `bool` | Loops playback of background music tracks. |
| `rolloffMode` | `AudioRolloffMode` | Rolloff curve mapping volume drop distance. |
| `fadeOutDuration` | `float` | Fade-out duration of active music tracks. |
| `holdDuration` | `float` | Delay duration before next track starts. |
| `fadeInDuration` | `float` | Fade-in duration of active music tracks. |
| `musicCrossfadeDuration` | `float` | Crossfade overlap duration of music transitions. |
| `stopMusicWhenNoClip` | `bool` | Stops audio source when track empty. |
| `useUnscaledTime` | `bool` | Ignores time-scale modifications for audio fades. |
| `sceneMusicCrossfadeDuration` | `float` | Crossfade duration during scene loading transitions. |
| `useAdvancedSceneTransitions` | `bool` | Enables advanced transitions of scene music. |
| `initialSFXPoolSize` | `int` | Preallocated pool size of sound effects. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `Default2D` | `SoundOptions` | `float vol = 1f` | Returns standard configurations for 2D audio clips. |
| `Default3D` | `SoundOptions` | `float vol = 1f` | Returns standard configurations for spatial 3D audio clips. |
| `SoftUI` | `SoundOptions` | `` | Returns specialized configuration options for UI sound effects. |
| `Cinematic` | `TransitionMusicOptions` | `` | Returns configurations for background cinematic music tracks transitions. |
| `PlaySFX2D` | `AudioSource` | `AudioClip clip, float volume = 1f` | Plays standard 2D sound effect clip at specified volume. |
| `PlaySFX3D` | `AudioSource` | `AudioClip clip, Vector3 worldPosition, float volume = 1f` | Plays spatial 3D sound effect clip at world position. |
| `PlaySFX` | `AudioSource` | `AudioClip clip, Vector3 position, SoundOptions options` | Plays audio clip at world position with custom options. |
| `StopSFX` | `void` | `AudioSource source, float fadeOutDuration = 0.5f` | Initiates volume fadeout of active audio source before stopping. |
| `PreloadSceneMusicTransition` | `Coroutine` | `string sceneName, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Preloads target scene music tracks ahead of scene loading. |
| `PreloadSceneMusicTransition` | `Coroutine` | `string sceneName, TransitionMusicOptions options, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Preloads target scene music tracks ahead of scene loading. |
| `TransitionToSceneMusic` | `Coroutine` | `string sceneName, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Triggers music crossfade transition matching scene loading state. |
| `TransitionToSceneMusic` | `Coroutine` | `string sceneName, TransitionMusicOptions options, AudioClip transitionStinger = null, AudioClip overrideMusicClip = null` | Triggers music crossfade transition matching scene loading state. |
| `PlayMusic` | `void` | `AudioClip clip, float crossfadeDuration = 1.5f` | Plays background music tracks with crossfade parameters. |
| `StopMusic` | `void` | `float fadeOutDuration = 1.5f` | Fades out active background music track until stop. |
| `PauseMusic` | `void` | `` | Pauses active background music track playback. |
| `ResumeMusic` | `void` | `` | Resumes paused background music track playback. |
| `SetMusicPitch` | `void` | `float pitch` | Sets pitch velocity of background music playback. |
| `SetMusicVolume` | `void` | `float volume` | Sets volume level of background music channel. |
| `SetMasterVolume` | `void` | `float volume` | Sets master volume level of main mixer channel. |
| `SetSFXVolume` | `void` | `float volume` | Sets sound effects volume level of mixer channel. |
| `GlobalFadeOut` | `void` | `float speedMultiplier = 10f` | Smoothly fades out all active audio channel volume levels. |
| `GlobalFadeIn` | `void` | `float speedMultiplier = 10f` | Smoothly fades in all active audio channel volume levels. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Ensure AudioSource is correctly configured for spatial audio (3D Spatial Blend set to 1.0).
- **Scene Binding:** Volume settings are tied to the `Settings` script.

========================================

## Class / Script: `VRInspectRotate`
- **Relative Path:** `Assets/Scripts/VRInspectRotate.cs`

### 1. Purpose and Role
Allows the player to inspect and rotate a grabbed object in VR. While holding an object, moving the controller's joystick rotates the object in mid-air for detailed examination.

### 2. Inner Workings & Implementation
The script captures controller joystick input by registering with the XR Interaction Toolkit. In the `Update` method, it translates joystick tilt values into angular offsets and applies them directly to the target object's transform rotation on the X and Y axes.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `referenceFrame` | `Transform` | Reference coordinate system for rotation calculations. |
| `yawDegreesPerMeter` | `float` | Horizontal rotation sensitivity of item inspect. |
| `pitchDegreesPerMeter` | `float` | Vertical rotation sensitivity of item inspect. |
| `lockPositionWhileInspecting` | `bool` | Locks physical position of inspected component. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `SetInspectEnabled` | `void` | `bool enabled` | Enables or disables visual item rotation control. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** This component is added directly to XR Grab Interactable objects. No additional settings required.
- **Scene Binding:** The script automatically takes input from the controller that initiated the grab.

========================================

## Class / Script: `VRReturnButton`
- **Relative Path:** `Assets/Scripts/VRReturnButton.cs`

### 1. Purpose and Role
An interactive button with special visual effects. The button border reacts to holding (an HDR outline fills up) and rapid clicking (spamming generates an intense glow in the button center). Used for returning to the menu to prevent accidental exits with a single click.

### 2. Inner Workings & Implementation
The script evaluates button hold and click durations in its `Update` loop. It increments a `holdProgress` value which is passed as a property to the button material shader, and triggers the transition action once the threshold is crossed.

**Core Button Loop (`Update`):**
```csharp
private void Update()
    {
        if (rectTransform == null) return;
        
        timeSinceLastClick += Time.unscaledDeltaTime;
        UpdateTargetState();
        
        float t = 1f - Mathf.Exp(-smoothSpeed * Time.unscaledDeltaTime);

        rectTransform.anchoredPosition3D = Vector3.Lerp(rectTransform.anchoredPosition3D, targetPosition, t);
        rectTransform.localScale = Vector3.Lerp(rectTransform.localScale, targetScale, t);

        currentAlpha = Mathf.Lerp(currentAlpha, targetAlpha, t);
        if (fadeGroup != null)
        {
            fadeGroup.alpha = currentAlpha;
        }

        // Hold & Spam logic tick
        if (isPressed && !hasTriggeredAction)
        {
            currentHoldProgress += Time.unscaledDeltaTime / requiredHoldTime;
        }
        else if (!isPressed)
        {
            currentHoldProgress -= Time.unscaledDeltaTime * holdDecayRate;
        }
        currentHoldProgress = Mathf.Clamp01(currentHoldProgress);
        
        currentSpamPulse = Mathf.Lerp(currentSpamPulse, 0f, 10f * Time.unscaledDeltaTime);

        // Auto trigger when hold is full
        if (currentHoldProgress >= 1f && !hasTriggeredAction)
        {
            hasTriggeredAction = true;
            TriggerAction(null);
        }
        
        // Reset trigger lock if fully released
        if (!isPressed && currentHoldProgress <= 0.01f)
        {
            hasTriggeredAction = false;
        }

        if (panelMaterial != null)
        {
            currentHighlight = Mathf.Lerp(currentHighlight, targetHighlight, t);
            
            panelMaterial.SetFloat("_FillAmount", currentHoldProgress);
            panelMaterial.SetFloat("_SpamPulse", currentSpamPulse);
            
            // Legacy highlight (can be supported if shader adds it, or acts as a fallback)
            if (panelMaterial.HasProperty("_HighlightAmount"))
                panelMaterial.SetFloat("_HighlightAmount", currentHighlight);
                
            float aspect = rectTransform.rect.width / Mathf.Max(rectTransform.rect.height, 1f);
            if (aspect > 0 && !float.IsInfinity(aspect)) 
                panelMaterial.SetFloat("_AspectRatio", aspect);
        }
    }
```

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `targetScene` | `string` | Target scene name string loaded click. |
| `hoverTranslationY` | `float` | Vertical translation displacement on button hover. |
| `hoverScale` | `float` | Scale multiplier size of hovered button. |
| `pressScale` | `float` | Scale multiplier size of pressed button. |
| `smoothSpeed` | `float` | Interpolation speed of button visual animations. |
| `requiredHoldTime` | `float` | Required hold duration to activate navigation. |
| `spamBoostAmount` | `float` | Progress percent added on button click. |
| `holdDecayRate` | `float` | Decay rate of hold progress value. |
| `hoverClip` | `AudioClip` | Audio clip played on button hover. |
| `clickClip` | `AudioClip` | Audio clip played on button click. |
| `hapticDuration` | `float` | Haptic vibration duration in seconds. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `OnPointerEnter` | `void` | `PointerEventData eventData` | Fades in active glow outline when player hovers button. |
| `OnPointerExit` | `void` | `PointerEventData eventData` | Fades out glow outline when player leaves button. |
| `OnPointerDown` | `void` | `PointerEventData eventData` | Starts required hold time registration on press. |
| `OnPointerUp` | `void` | `PointerEventData eventData` | Cancels hold progress tracker when press released. |
| `OnPointerClick` | `void` | `PointerEventData eventData` | Adds spam click progress boost to hold meter. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** The script requires linking the button's material, which must use the specialized `UI/InteractiveButton` shader.
- **Scene Binding:** Triggers SceneTransitionManager on activation for a smooth fade to a different scene.

========================================

## Class / Script: `objectdissapear`
- **Relative Path:** `Assets/Scripts/objectdissapear.cs`

### 1. Purpose and Role
A helper script for scene optimization. It allows temporary objects (like component boxes or protective covers) to smoothly fade away after a certain duration, freeing up memory and physics processing.

### 2. Inner Workings & Implementation
Upon activation, the script starts a countdown. After `lifetime` expires, it begins smoothly reducing the transparency (alpha) of materials on all renderers of the object. Once alpha reaches zero, the object is destroyed.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `delayBeforeDisappear` | `float` | Delay seconds before fadeout animation starts. |
| `animationDuration` | `float` | Fading transparency animation duration in seconds. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `lifetime` in seconds (e.g., `10.0`s) and check `fadeOut` for a smooth transition instead of instant deletion.
- **Scene Binding:** Place on any non-essential physics objects.

========================================

<div style='page-break-before: always;'></div>

# Physics and Cable Snapping (Assets/Scripts/zoltr/)
---

## Class / Script: `ZoltrCableDynamicInteractor`
- **Relative Path:** `Assets/Scripts/zoltr/ZoltrCableDynamicInteractor.cs`

### 1. Purpose and Role
Detects collisions with cables. Placed on fast-moving objects (like VR hands or thrown items). Performs optimized mathematical Sweep tests (sphere, capsule, box) against all active cables, preventing the hand from skipping through thin cables without a collision.

### 2. Inner Workings & Implementation
This component attaches to interactive objects and controllers. In the `Update` loop, it performs Sweep checks (using sphere or capsule shapes) against registered cable instances, transferring momentum directly to the intersected cable particles.

**Sweep Test Collision Calculation (`EvaluateCollision`):**
```csharp
public void EvaluateCollision(Vector3 point, float cableRadius, out Vector3 pushDir, out float penetration)
    {
        pushDir = Vector3.zero;
        penetration = 0f;

        Vector3 currentPos = transform.position;
        Quaternion currentRot = transform.rotation;

        if (shape == InteractorShape.Sphere)
        {
            Vector3 scale = transform.lossyScale;
            float maxScale = Mathf.Max(scale.x, Mathf.Max(scale.y, scale.z));
            float scaledRadius = sphereRadius * maxScale;
            // Exact mathematically swept sphere (Capsule trajectory)
            Vector3 centerOld = oldPosition + oldRotation * sphereOffset;
            Vector3 centerNew = currentPos + currentRot * sphereOffset;
            
            Vector3 movement = centerNew - centerOld;
            float magSqr = movement.sqrMagnitude;
            
            float t = 0f;
            if (magSqr > 0.000001f)
            {
                t = Mathf.Clamp01(Vector3.Dot(point - centerOld, movement) / magSqr);
            }
            
            Vector3 closestPointOnTrajectory = centerOld + movement * t;
            Vector3 diff = point - closestPointOnTrajectory;
            float distSqr = diff.sqrMagnitude;
            
            float combinedRadius = scaledRadius + cableRadius;
            if (distSqr < combinedRadius * combinedRadius && distSqr > 0.000001f)
            {
                float dist = Mathf.Sqrt(distSqr);
                pushDir = diff / dist;
                penetration = combinedRadius - dist;
            }
            return;
        }
```

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `shape` | `InteractorShape` | Shape format of cable interactor collision. |
| `momentumTransfer` | `float` | Momentum transfer multiplier on cable touch. |
| `sphereRadius` | `float` | Radius range of sphere interactor collision. |
| `sphereOffset` | `Vector3` | Position offset vector of sphere interactor. |
| `capsuleRadius` | `float` | Radius range of capsule interactor collision. |
| `capsuleHeight` | `float` | Height range of capsule interactor collision. |
| `capsuleDirection` | `int` | Alignment direction index of capsule interactor. |
| `capsuleOffset` | `Vector3` | Position offset vector of capsule interactor. |
| `boxOffset` | `Vector3` | Position offset vector of box interactor. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `EvaluateCollision` | `void` | `Vector3 point, float cableRadius, out Vector3 pushDir, out float penetration` | Calculates sphere trajectory intersections with cable particle segments. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Attach this component to controllers/hands of the player.
- **Scene Binding:** Registers itself automatically in the global list of cable collision interactors.

========================================

## Class / Script: `object_id`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_helpers.cs`

### 1. Purpose and Role
Enum defining unique identifiers for all PC components and cable connectors in the project.

### 2. Inner Workings & Implementation
Serves as the key for verifying compatibility tags when snapping items into sockets.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `dependencyItems` | `zoltr_socketItem[]` | Array of prerequisite hardware socket items. |
| `needsToBe` | `ItemRuleOption` | Prerequisite installation rule required for snapping. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `GetComponentKey` | `int` | `object_id component, int index = 0` | Returns unique integer identifier for hardware component. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Select the component ID matching the hardware item type.
- **Scene Binding:** Referenced project-wide by all socket and build progress systems.

========================================

## Class / Script: `zoltr_audioHelper`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_audioHelper.cs`

### 1. Purpose and Role
Audio helper for the socket and cable system. Contains and plays sounds for snaps, cable tension, and unsnapping.

### 2. Inner Workings & Implementation
A utility script that manages and triggers local audio clips for physical interactions. It listens for events from cables and socket systems and plays corresponding audio clips at specified spatial coordinates.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `itemCollisionSounds` | `AudioClip[]` | Audio clips array played on impacts. |
| `itemPickupSound` | `AudioClip` | Audio clip played when picking up. |
| `componentSnapSound` | `AudioClip` | Audio clip played when snaps motherboard. |
| `componentUnsnapSound` | `AudioClip` | Audio clip played when unsnaps motherboard. |
| `componentPullingSound` | `AudioClip` | Audio clip of cable tension pull. |
| `fanLoopSound` | `AudioClip` | Audio clip of spinning fan hum. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign suitable AudioClips for snaps, unsnaps, and tension pull sounds.
- **Scene Binding:** Called programmatically from socket and cable scripts.

========================================

## Class / Script: `zoltr_buildProgress`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_buildProgress.cs`

### 1. Purpose and Role
Tracks the overall PC building progress. Checks the state of required sockets and triggers the final learning scenario event upon completion.

### 2. Inner Workings & Implementation
The script monitors component insertion states across a list of target sockets. It periodically checks the array of sockets, recalculates the total assembly percentage, and pushes the updated string representation to text UI components.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `zsi` | `zoltr_socketItem[]` | Array of sockets tracked for completion. |
| `text` | `string` | UI text label template for percentage. |
| `allItems` | `progressItem[]` | Array of items tracked in build. |
| `buildProgress` | `float` | Percentage representation value of assembly progress. |
| `parentUiObject` | `GameObject` | Parent canvas GameObject of progress text. |
| `textPrefab` | `GameObject` | Text prefab template for progress display. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Place all target sockets that must be filled into the `requiredSockets` list.
- **Scene Binding:** Fires the registered `onBuildComplete` event upon final completion.

========================================

## Class / Script: `zoltr_cable`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_cable.cs`

### 1. Purpose and Role
An advanced physical cable simulator designed for VR. It uses Extended Position-Based Dynamics (XPBD) split into multiple physics substeps. It ensures realistic behavior (slack, bending stiffness, tension), supports collisions with the environment, end tangent locking (connector alignment), and two-way coupling with Rigidbodies (cable pulls on hanging objects). Renders using either a LineRenderer or bone deformations (Skinned Mesh Rigging) of a cable model.

### 2. Inner Workings & Implementation
An advanced physical simulator for flexible ropes. In its `FixedUpdate` method, it runs a loop of Verlet integration sub-steps applying length and bending constraints, then in `LateUpdate` translates the particle positions onto skinned mesh bones.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `startPoint` | `Transform` | Start attachment transform kotevnÃ­ point connector. |
| `endPoint` | `Transform` | End attachment transform kotevnÃ­ point connector. |
| `segmentCount` | `int` | Number of physics particles along cable. |
| `cableLength` | `float` | Physical length value of cable instance. |
| `allowUnpluggable` | `bool` | Enables detaching connector on extreme pull. |
| `unpluggableDistance` | `float` | Pull range limit triggering connector unplug. |
| `cableMaterial` | `Material` | Material used for drawing line renderer. |
| `startColor` | `Color` | Start color parameter of cable line. |
| `endColor` | `Color` | End color parameter of cable line. |
| `textureTiling` | `float` | Tiling multiplier parameter of cable material. |
| `substeps` | `int` | Solver calculation substeps per physics update. |
| `bendingStiffness` | `float` | Bending rigidity coefficient of simulated rope. |
| `anchorStiffness` | `float` | Stiffness alignment value of connector ends. |
| `motionDamping` | `float` | Restricting motion damping of simulated particles. |
| `enableCollisions` | `bool` | Enables environment collisions with rope particles. |
| `enableContinuousCollision` | `bool` | Enables continuous collision detection sweeps check. |
| `extraCollisionChecksPerSegment` | `int` | Collision subdivision check points per segment. |
| `cableRadius` | `float` | FyzikÃ¡lnÃ­ collision thickness radius of cable. |
| `collisionMask` | `LayerMask` | LayerMask defining objects cable collides with. |
| `collisionFriction` | `float` | Friction coefficient of cable contact collisions. |
| `collisionRestitution` | `float` | Bounciness factor of cable contact collisions. |
| `pullRigidbodies` | `bool` | Allows cable physics to drag connectors. |
| `positionPullMultiplier` | `float` | Force multiplier translating snapped items positions. |
| `rotationPullMultiplier` | `float` | Force multiplier rotating snapped items rotation. |
| `maxPullVelocity` | `float` | Velocity cap limiting rigidbody pull force. |
| `cableElasticity` | `float` | Elasticity stretching factor of cable line. |
| `enableVRSmoothing` | `bool` | Enables visual jitter smoothing for VR. |
| `visualSmoothing` | `float` | Smoothing factor filter for visual lines. |
| `lineSubdivisions` | `int` | Subdivisions count generating smooth visual line. |
| `boneForwardAxis` | `BoneForwardAxis` | Axis aligning bones of SkinnedMesh renderer. |
| `applyTwistOffset` | `bool` | Enables twisting offsets applied along bones. |
| `twistOffsetAngle` | `float` | Manual angle twist applied along bones. |
| `boneStartOffset` | `float` | Offset distance ignoring bones at start. |
| `boneEndOffset` | `float` | Offset distance ignoring bones at end. |
| `isStartGrabbed` | `bool` | Tracks if start connector is held. |
| `isEndGrabbed` | `bool` | Tracks if end connector is held. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `AutoAssignBones` | `void` | `` | Finds child bone transforms of SkinnedMesh automatically. |
| `CableStartLocked` | `void` | `bool grabbed` | Locks start segment position to connector transform. |
| `CableEndLocked` | `void` | `bool grabbed` | Locks end segment position to connector transform. |
| `SetSegmentCountFromRig` | `void` | `` | Updates physics segments count matching skeletons bone count. |
| `ResolveDynamicInteractor` | `void` | `ZoltrCableDynamicInteractor interactor, Vector3 objVelocity` | Applies velocity momentum updates to colliding cable segments. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** If the cable is jittery or stretches too much, increase `substeps` to 10 or 12.
- **Scene Binding:** Links a start and end connector (each of type zoltr_socketItem).

========================================

## Class / Script: `zoltr_itemHandle`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_itemHandle.cs`

### 1. Purpose and Role
Represents a grab handle on a component or cable connector, ensuring that the player's virtual hand aligns correctly when grabbing.

### 2. Inner Workings & Implementation
A class defining the grab point for cable connectors. During `Awake` and `Start`, it configures the XR Grab Interactable interaction layers to ensure correct alignment with the player's virtual hands.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `handleCollider` | `BoxCollider` | BoxCollider governing grab position of connector. |
| `interactionLayerName` | `string` | Unity interaction layer name for handle. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Align the handle collider shape precisely with the 3D mesh plug handles.
- **Scene Binding:** Acts as the target for hand grab detection in the scene.

========================================

## Class / Script: `zoltr_physicsAudio`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_physicsAudio.cs`

### 1. Purpose and Role
Generates realistic physical collision sounds when objects hit the environment. Sound pitch and volume scale dynamically based on relative impact velocity and object mass.

### 2. Inner Workings & Implementation
The script listens for Rigidbody collisions via the `OnCollisionEnter` method. It calculates the relative impact velocity and uses it to dynamically scale the volume and pitch of the instantiated collision audio clip.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `minImpactVelocity` | `float` | Minimum collision velocity playing impact sounds. |
| `maxImpactVelocity` | `float` | Maximum velocity scale for impact volume. |
| `velocityGrain` | `float` | Grain filter value of impact velocities. |
| `minVolume` | `float` | Minimum volume of collision audio clips. |
| `maxVolume` | `float` | Maximum volume of collision audio clips. |
| `pitchVariation` | `float` | Pitch random deviation offset on impacts. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `DisableAudio` | `void` | `` | Temporarily mutes collision sound generation on objects. |
| `EnableAudioAfter` | `void` | `float duration` | Re-enables collision sound generation after specified duration. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Assign collision audio clips for metal, plastic, etc.
- **Scene Binding:** Requires a Rigidbody on the same GameObject.

========================================

## Class / Script: `zoltr_socket`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_socket.cs`

### 1. Purpose and Role
A slot where components or cable connectors are plugged. Holds compatible type info (`socket_type`) and visualizes socket states (green box = free, red box = occupied) inside the Unity Editor.

### 2. Inner Workings & Implementation
A class representing a mounting slot in the workspace. During `Awake`, it registers pre-placed hardware components and uses collision trigger events to evaluate the compatibility of incoming zoltr_socketItem components.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `socket_type` | `object_id` | Component type category accepted by socket. |
| `used` | `bool` | Tracks if socket is currently occupied. |
| `snappedItemOnAwake` | `zoltr_socketItem` | Hardware item snapped in socket initially. |
| `usable` | `bool` | Tracks if socket accepts new items. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Select the correct `socket_type` matching the hardware (e.g. CPU_SOCKET).
- **Scene Binding:** Detects entry events of colliding zoltr_socketItem components.

========================================

## Class / Script: `zoltr_socketItem`
- **Relative Path:** `Assets/Scripts/zoltr/zoltr_socketItem.cs`

### 1. Purpose and Role
The core script for any pluggable component (GPU, CPU, cable connector). Handles snapping, compatibility checks, user pull-to-unsnap logic (requires overcoming a resistance `neededPullForceForUnsnap` which triggers a tension shake and creaking sounds), dependency rules (e.g., CPU cannot be removed while the cooler is attached), and holographic ghost mesh previews when near compatible sockets.

### 2. Inner Workings & Implementation
The core pluggable component script. In its `Update` loop, it calculates the hand's pull distance to trigger socket unsnapping and shakes the object, while using `LateUpdate` to interpolate holographic ghost mesh positions.

**Unsnapping & Pull Distance Calculations (`Update`):**
```csharp
private void Update()
    {
        // Check if the user is actively holding the item while it's in a socket
        if (attachedSocket != null && grabInteractable != null && grabInteractable.isSelected && currentInteractor != null)
        {
            if (neededPullForceForUnsnap <= 0f)
            {
                BreakFromSocket();
                return;
            }

            GetSnapWorldPose(attachedSocket, out Vector3 targetPos, out Quaternion targetRot);

            // Measure absolute distance between the controller and the target socket position
            float currentDistance = Vector3.Distance(currentInteractor.transform.position, targetPos);
            
            // Calculate how much further away the controller has traveled since grabbing it
            float pullDelta = currentDistance - initialPullDistance;

            if (pullDelta >= neededPullForceForUnsnap)
            {
                BreakFromSocket();
            }
            else
            {
                // Progress map from 0.0 (no pull change) to 1.0 (on the verge of snapping)
                float progress = Mathf.Clamp01(pullDelta / neededPullForceForUnsnap);
                progress *= progress;

                pullingAudioSource.volume = progress;
                pullingAudioSource.pitch = 1f + progress * 0.4f;

                // Generate random high-frequency procedural shake offsets scaling with progress
                Vector3 shakeOffset = Random.insideUnitSphere * maxShakeIntensity * progress;
                Quaternion shakeRot = Quaternion.Euler(
                    Random.Range(-1f, 1f) * maxShakeRotationIntensity * progress,
                    Random.Range(-1f, 1f) * maxShakeRotationIntensity * progress,
                    Random.Range(-1f, 1f) * maxShakeRotationIntensity * progress
                );

                // Apply target coordinates + visual tension jitter
                transform.SetPositionAndRotation(targetPos + shakeOffset, targetRot * shakeRot);
            }
        }
```

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `socket_type` | `object_id` | Hardware component category matching target sockets. |
| `snapAxis` | `SnapAxisDirection` | Forward direction vector aligning in socket. |
| `snapRotation` | `Vector3` | Rotation angle offset applied on snap. |
| `allowUnsnap` | `bool` | Enables manual unsnapping of the item. |
| `neededPullForceForUnsnap` | `float` | Hand pull distance required for unsnapping. |
| `canBeSnapped` | `bool` | Tracks if snapping is currently allowed. |
| `dependencyRules` | `ItemDependencyRule[]` | Assembly rules restricting component snap order. |
| `maxShakeIntensity` | `float` | Intensity multiplier of hand tension shake. |
| `maxShakeRotationIntensity` | `float` | Rotation intensity multiplier of tension shake. |
| `ghostMaterialValid` | `Material` | Material rendering green holographic valid preview. |
| `ghostMaterialInvalid` | `Material` | Material rendering red holographic invalid preview. |
| `highlightMaterial` | `Material` | Material applied for outline highlights glow. |
| `attachedSocket` | `zoltr_socket` | Reference of socket item is in. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `SnapToSocket` | `bool` | `zoltr_socket socket` | Locks component transform and rigids to target socket. |
| `BreakFromSocket` | `void` | `` | Restores standard rigidbody physics and detaches from socket. |
| `RecalculateDependencies` | `void` | `` | Re-evaluates snap state of required dependency items. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Set `neededPullForceForUnsnap` to a reasonable threshold (e.g. 0.2 meters pull) so it is not too easy or hard to detach.
- **Scene Binding:** Requires a Rigidbody and Collider on the item.

========================================

<div style='page-break-before: always;'></div>

# Editor Extensions and Localization (Assets/Scripts/Editor/ & Assets/Scripts/zoltr/Editor/)
---

## Class / Script: `MenuLocalizationHelper`
- **Relative Path:** `Assets/Scripts/Editor/MenuLocalizationHelper.cs`

### 1. Purpose and Role
Helper editor script for rapid testing and updating of localized fonts and strings directly in the Unity Editor without running the game.

### 2. Inner Workings & Implementation
Uses Unity editor APIs to traverse active text fields and simulate locale changes on UI elements.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ApplyFixes` | `void` | `` | Applies immediate localization string updates and font overrides across menu elements. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** This script runs strictly in the editor and is triggered via context menus.
- **Scene Binding:** Editor-only utility; not instantiated in the scene.

========================================

## Class / Script: `MissingMaterialFinder`
- **Relative Path:** `Assets/Scripts/Tools/MissingMaterialFinder/Editor/MissingMaterialFinder.cs`

### 1. Purpose and Role
Editor utility searching for missing (magenta) materials on renderers across the scene.

### 2. Inner Workings & Implementation
Scans MeshRenderers for empty material references and replaces them with a chosen fallback material.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `renderer` | `Renderer` | Renderer component containing missing material references. |
| `materialIndex` | `int` | Material index slot of renderer component. |
| `customReplacement` | `Material` | Replacement material applied to clear issue. |
| `path` | `string` | File path string of target material. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ShowWindow` | `void` | `` | Opens editor window utility listing missing materials. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Select a replacement material asset and hit scan in the window.
- **Scene Binding:** Crucial for cleaning up imported assets and placeholder materials.

========================================

## Class / Script: `PeripheralsQuizCreator`
- **Relative Path:** `Assets/Scripts/Editor/PeripheralsQuizCreator.cs`

### 1. Purpose and Role
Editor utility script for creating and managing quiz question assets focusing on PC peripherals.

### 2. Inner Workings & Implementation
Draws a custom editor window with form fields to input questions and answers, exporting them directly to JSON format.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `Setup` | `void` | `` | Instantiates and configures the peripheral quiz questions database and button layouts. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Accessed via the top menu bar under Tools in the Unity Editor.
- **Scene Binding:** Serves as a content creation tool for configuring quiz databases.

========================================

## Class / Script: `SceneDrawer`
- **Relative Path:** `Assets/Scripts/Editor/SceneDrawer.cs`

### 1. Purpose and Role
Custom property drawer for string variables annotated with the [Scene] attribute, replacing manual text entry with a safe dropdown.

### 2. Inner Workings & Implementation
Parses the active scenes list from Unity Build Settings and presents them as an enum-style selector in the Inspector.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Automatically modifies rendering of marked string fields in all scripts.
- **Scene Binding:** Used exclusively to simplify scene assignment workflows in editor.

========================================

## Class / Script: `SceneTransitionManagerEditor`
- **Relative Path:** `Assets/Scripts/Editor/SceneTransitionManagerEditor.cs`

### 1. Purpose and Role
Custom Inspector editor GUI for SceneTransitionManager, exposing test buttons to trigger fades and scene transitions directly in editor.

### 2. Inner Workings & Implementation
Overrides standard component inspector drawing to inject debug button layouts calling transition routines in play mode.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Debug buttons appear at the bottom of the inspector window during active play sessions.
- **Scene Binding:** Helps verify transition timing and visual fades during development.

========================================

## Class / Script: `ShowDescriptionObjectEditor`
- **Relative Path:** `Assets/Scripts/Editor/ShowDescriptionObjectEditor.cs`

### 1. Purpose and Role
Custom editor interface for configuring ShowDescriptionObject components.

### 2. Inner Workings & Implementation
Provides a clean interface layout to bind localization keys and audio assets.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Organizes localization table keys and previews directly in the component view.
- **Scene Binding:** Improves data entry workflows for hardware descriptions.

========================================

## Class / Script: `TranslationInjector`
- **Relative Path:** `Assets/Scripts/Editor/TranslationInjector.cs`

### 1. Purpose and Role
Editor utility script for batch-injecting localization events and keys to text elements across the active scene.

### 2. Inner Workings & Implementation
Scans active hierarchies for TextMeshPro components and attaches LocalizeStringEvent handlers populated with matching keys.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `InjectTranslations` | `void` | `` | Injects translated key-value pairs into active text components programmatically. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Triggered via context menus to translate entire UI canvas layouts in one click.
- **Scene Binding:** Accelerates translation workflows across UI scenes.

========================================

## Class / Script: `ZoltrCableDynamicInteractorEditor`
- **Relative Path:** `Assets/Scripts/zoltr/Editor/ZoltrCableDynamicInteractorEditor.cs`

### 1. Purpose and Role
Custom inspector UI for configuring ZoltrCableDynamicInteractor collision shapes.

### 2. Inner Workings & Implementation
Renders intuitive setting selectors and previews for sphere, capsule, and box bounds.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Simplifies adjusting the offset dimensions of interactive collision zones.
- **Scene Binding:** Used when setting up controllers and dynamic props.

========================================

## Class / Script: `zoltr_socketItemEditor`
- **Relative Path:** `Assets/Scripts/zoltr/Editor/zoltr_socketItemEditor.cs`

### 1. Purpose and Role
Custom editor for zoltr_socketItem, facilitating alignment and offset calculations.

### 2. Inner Workings & Implementation
Injects edit mode buttons to capture the current transform pose as snap values automatically.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Click 'Save Current Pose' to quickly capture local coordinates for snapped alignment.
- **Scene Binding:** Accelerates motherboard assembly setup and tweaking.

========================================

<div style='page-break-before: always;'></div>

# Utilities and Helper Classes (Assets/Scripts/Tools/ & Assets/Scripts/XR/)
---

## Class / Script: `FindMissingScripts`
- **Relative Path:** `Assets/Scripts/Tools/ChatGPTMissingScripts.cs`

### 1. Purpose and Role
Diagnostic tool searching for broken (Missing MonoScript) component references on scene GameObjects.

### 2. Inner Workings & Implementation
Iterates through scene hierarchies checking for null script references inside attached component lists.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Accessed via the editor tools menu bar at Tools -> Find Missing Scripts.
- **Scene Binding:** Improves project hygiene by identifying broken prefab link instances.

========================================

## Class / Script: `HapticFeedbackRunner`
- **Relative Path:** `Assets/Scripts/Tools/HapticFeedbackRunner.cs`

### 1. Purpose and Role
MonoBehaviour wrapper for HapticFeedbackHelper to trigger haptic impulses from UnityEvents (e.g., UI hover events).

### 2. Inner Workings & Implementation
Acts as a bridge exposing public methods to trigger haptic feedback via Unity UI Event system.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `StartFadingHaptic` | `void` | `object interactor, float startAmplitude, float endAmplitude, float duration, AnimationCurve curve = null` | Smoothly fades vibration amplitude on active controller. |
| `StartContinuous` | `void` | `int id, object interactor, float initialAmplitude, float maxDuration = -1f` | Starts continuous vibration loop on controller. |
| `SetContinuousAmplitude` | `void` | `int id, float newAmplitude` | Modifies amplitude of continuous haptic vibration. |
| `StopContinuous` | `void` | `int id` | Stops continuous haptic vibration loop. |
| `StartSequence` | `void` | `object interactor, float[] amplitudes, float[] durations, float[] gaps` | Plays array of haptic steps and gaps. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Adjust the amplitude and duration for specific UI buttons.
- **Scene Binding:** Can be linked to any UnityEvent inside the UI hierarchy.

========================================

## Class / Script: `HapticPattern`
- **Relative Path:** `Assets/Scripts/Tools/HapticFeedbackHelper.cs`

### 1. Purpose and Role
Represents a data structure defining vibration patterns (sequences of amplitudes and duration gaps) for VR controllers.

### 2. Inner Workings & Implementation
Stores arrays of vibration amplitudes and delay steps played sequentially by haptic runners.

### 3. Inspector Properties & Configuration
*This script has no public/serialized fields configured in the Inspector.*

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `TriggerHaptics` | `bool` | `PointerEventData eventData, float amplitude, float duration` | Sends a vibration impulse with amplitude and duration. |
| `TriggerHaptics` | `bool` | `XRNode node, float amplitude, float duration` | Sends a vibration impulse with amplitude and duration. |
| `TriggerHaptics` | `bool` | `InputDevice device, float amplitude, float duration` | Sends a vibration impulse with amplitude and duration. |
| `TriggerBaseHaptics` | `bool` | `object interactorOrController, float amplitude, float duration` | Calculates target controller node and triggers vibration. |
| `TriggerGlobalHaptics` | `void` | `float amplitude, float duration` | Triggers identical vibration impulses on both controllers. |
| `TriggerFadingHaptics` | `void` | `PointerEventData eventData, float startAmplitude, float endAmplitude, float duration, AnimationCurve curve = null` | Triggers a vibration fading smoothly over duration. |
| `TriggerFadingHaptics` | `void` | `XRNode node, float startAmplitude, float endAmplitude, float duration, AnimationCurve curve = null` | Triggers a vibration fading smoothly over duration. |
| `StartContinuousHaptics` | `int` | `PointerEventData eventData, float amplitude, float maxDuration = -1f` | Starts continuous vibration loop on target controller. |
| `StartContinuousHaptics` | `int` | `XRNode node, float amplitude, float maxDuration = -1f` | Starts continuous vibration loop on target controller. |
| `SetContinuousHapticsAmplitude` | `void` | `int id, float newAmplitude` | Updates amplitude of running continuous haptics loop. |
| `StopContinuousHaptics` | `void` | `int id` | Stops continuous vibration loop on target controller. |
| `TriggerHapticSequence` | `void` | `PointerEventData eventData, float[] amplitudes, float[] durations, float[] gaps = null` | Triggers sequence of vibration steps with delay gaps. |
| `TriggerHapticPattern` | `void` | `XRNode node, HapticPattern pattern` | Plays a predefined vibration pattern on controller. |
| `TriggerHapticPattern` | `void` | `PointerEventData eventData, HapticPattern pattern` | Plays a predefined vibration pattern on controller. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Configure custom feedback rhythms using float array properties directly.
- **Scene Binding:** Governed and executed by HapticFeedbackHelper routines.

========================================

## Class / Script: `MissingScriptWindow`
- **Relative Path:** `Assets/Scripts/Tools/Missing Scripts Tool/Scripts/MissingScriptWindow.cs`

### 1. Purpose and Role
Interactive editor window displaying an actionable list of all broken components in the project.

### 2. Inner Workings & Implementation
Renders an editor table with paths to errors, allowing rapid focus navigation on click.

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `Paths` | `List<string>` | Asset paths of scripts containing issues. |
| `ActiveIndex` | `int` | Selected item index of issues list. |
| `Kind` | `SourceKind` | Source type classification of script issue. |
| `AssetPath` | `string` | Asset path string of target script. |
| `ObjectPath` | `string` | Scene hierarchy path of target GameObject. |
| `Key` | `string` | Unique string key identifying script issue. |

### 4. Methods and Public API
| Method | Return Type | Parameters | Description |
|---|---|---|---|
| `ShowWindow` | `void` | `` | Opens editor window utility listing missing scripts. |

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Use search filters inside the window to isolate specific folder issues.
- **Scene Binding:** Used exclusively for developer diagnostics.

========================================

<div style='page-break-before: always;'></div>

# VR Player & Hand Animations (Assets/Scripts/VRPlayer/)
---

## Class / Script: `AnimateHandOnInput`
- **Relative Path:** `Assets/Scripts/VRPlayer/AnimateHandOnInput.cs`

### 1. Purpose and Role
Animates virtual hand fingers (Grip and Pinch) based on analog input actions from the VR controller, providing smooth clenching and pinching animations.

### 2. Inner Workings & Implementation
The script reads trigger and grip values from input actions. In the `Update` loop, it passes these float values directly to Animator parameters on the virtual hand to blend grip and pinch animations smoothly.

**Complete Input Hand Animation Loop:**
```csharp
using UnityEngine;
using UnityEngine.InputSystem;

public class AnimateHandOnInput : MonoBehaviour
{
    public InputActionProperty pinchAnimationAction;
    public InputActionProperty gripAnimationAction;
    public Animator handAnimator;

    void Update()
    {
        float pinchValue = pinchAnimationAction.action.ReadValue<float>();
        float gripValue = gripAnimationAction.action.ReadValue<float>();
        handAnimator.SetFloat("Trigger", pinchValue);
        handAnimator.SetFloat("Grip", gripValue);
    }
}
```

### 3. Inspector Properties & Configuration
| Field | Type | Configuration Description |
|---|---|---|
| `pinchAnimationAction` | `InputActionProperty` | Input action mapping trigger to pinch. |
| `gripAnimationAction` | `InputActionProperty` | Input action mapping grip to grab. |
| `handAnimator` | `Animator` | Animator component controlling hand finger animations. |

### 4. Methods and Public API
*This script does not expose public methods to other systems.*

### 5. Editing and Integration Guide
- **Inspector Tweaks:** Verify mapping of Input Actions from the Action Asset.
- **Scene Binding:** Attach this directly to the hand model containing an Animator component.

========================================

<div style='page-break-before: always;'></div>

# 3. Developer Playbook - Step-by-Step Guides
---

## 3.1 How to Add a New PC Component to the Assembly System
Let's say you want to add a **Sound Card** which players must snap into a PCI-E slot on the motherboard:
1. **Prepare the 3D Asset**: Import the sound card FBX model into Unity, set up materials, and create a Prefab.
2. **Add Physics Components**: Add a `Rigidbody` (mass: `0.2` kg, default gravity) and a `BoxCollider` matching the physical bounds. Keep the collider as non-Trigger.
3. **XR Grab Setup**: Add `XRGrabInteractable` to the root. Set `Movement Type` to `Instant` or `Kinematic`. Create a child transform `GrabPoint` and assign it to the `Attach Transform` field of the grab component to ensure it aligns nicely in the player's hand.
4. **Register the ID**: Open [zoltr_helpers.cs](file:///C:/Users/adamk/Erasmus-2026-06-11-11-53-25/Assets/Scripts/zoltr/zoltr_helpers.cs). Add `SOUND_CARD` to the `object_id` enum.
5. **Configure Snapping**: Add `zoltr_socketItem` to the sound card:
   - Set `socket_type` to `SOUND_CARD`.
   - Set `snapAxis` (usually `Forward` or `Down` depending on the insertion direction).
   - Tweak `snapOffset` and `snapRotation` so that it fits precisely into the PCI-E slot when snapped.
   - Enable `allowUnsnap = true` and set `neededPullForceForUnsnap` to `0.15` (requiring a 15cm hand pull to snap out).
6. **Create the Motherboard Socket**: On the Motherboard prefab, find the PCI-E slot and create an empty child GameObject `Socket_SoundCard`:
   - Add a `BoxCollider` configured as **Is Trigger** covering the slot entry.
   - Add the `zoltr_socket` component and set `socket_type` to `SOUND_CARD`.
7. **Define Dependencies**: To prevent the player from slotting the card before the motherboard is screwed into the PC case, open the sound card's `zoltr_socketItem` under `dependencyRules`:
   - Add a rule targeting the Motherboard item.
   - Set `needsToBe` to `SnappedIn`.

## 3.2 How to Create and Connect a New Cable
To create a custom cable (e.g., SATA data cable from motherboard to SSD):
1. **Create Base Object**: Create an empty GameObject `SataCable` in the scene and attach the `zoltr_cable` script.
2. **Create Connectors**: Create two child GameObjects: `ConnectorStart` and `ConnectorEnd`. These act as the plastic plug handles grabbed by the player.
   - Add `Rigidbody` (Kinematic), a `Collider`, and `XRGrabInteractable` to both connector objects.
   - Add the `zoltr_socketItem` script to both, setting the compatible socket type to `SATA_DATA`.
3. **Link to Cable**: Drag `ConnectorStart` into `startPoint` and `ConnectorEnd` into `endPoint` on the `zoltr_cable` script.
4. **Tweak Physics**: Set `cableLength` to `0.3`m, `segmentCount` to `10`, and `substeps` to `8`. Set `bendingStiffness` to `0.4` (for a semi-rigid cable profile) and `anchorStiffness` to `0.8` (ensures the cable leaves the plug straight before bending).
5. **Rendering**: If you have a rigged cable model with bones, map the joints to `cableBones` and use the context menu `Set Segment Count From Rig`. Otherwise, leave it empty â€“ the script automatically spawns and manages a `LineRenderer` to draw a smooth 3D tube.

## 3.3 How to Edit and Expand Quizzes
Quiz questions are dynamically loaded from JSON files, making them very easy to edit:
1. **Locate Files**: Look inside `Assets/Content/Quizzes/` (e.g., `ComputerQuiz.json`).
2. **JSON Format**: Ensure you follow this structure:
   ```json
   {
     "questions": [
       {
         "question": "What is the primary function of a CPU heatsink?",
         "answers": [
           "To dissipate heat and prevent thermal throttling",
           "To increase memory clock speeds",
           "To store permanent data",
           "To deliver power to the motherboard"
         ],
         "correctAnswerIndex": 0
       }
     ]
   }
   ```
3. **Add Questions**: Append your new question object inside the `questions` array. The quiz board will automatically parse and display it, sizing buttons dynamically.
4. **Narrator Audios**: Based on the player's success rate, the `Quiz` script plays narrator evaluations. You can replace these audio clips on the `Quiz` component inside the Inspector under the `Narrator Audio` section.

## 3.4 How the Localization System Works and How to Edit It (Unity Localization)
The game supports full localization of the user interface (UI) and texts (Czech and English languages) using the official **Unity Localization** package.
### How localization works under the hood:
1. **String Tables**: All localized texts are stored in String Tables. The default table in the project is named `LocalizationTable` (or as configured in the `stringTableName` parameter). Each entry in the table has a unique **Key** (e.g., `quiz_score`) and translations for the respective languages (Locales) â€“ Czech (`cs`) and English (`en`).
2. **Language Switching**: The active language is detected based on system settings or chosen by the player in the settings menu. The code switches the active Locale by setting `LocalizationSettings.SelectedLocale = locale;`.
3. **Dynamic Texts (Localize String Event)**: Components like `LearningScenarioWindowLabel` or the quiz systems subscribe to localization events. When the active language changes, the texts are updated automatically without restarting the scene.
### Guide: How to add a new translation or edit existing text:
To edit existing text (e.g., fix a typo) or add a new label:
1. **Open Tables**: In the Unity Editor, open the localization tables window from the top menu: **Window -> Asset Management -> Localization Tables**.
2. **Select Table**: In the dropdown menu, select the project's string table (e.g., `LocalizationTable`).
3. **Edit Text**: Find the target key (Key) in the list and edit the text directly in the `Czech (cs)` or `English (en)` column.
4. **Add New Entry**: Click the **Add New Entry** button at the bottom of the table, enter a unique key (e.g., `hud_welcome_message`), and fill in its Czech and English translations.
5. **Use in UI**: Add a `Localize String Event` component to your text UI element (TextMeshPro - Text). In the `String Reference` section, select your newly added key. The component will handle the translation updates automatically.
